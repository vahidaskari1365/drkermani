"use client";

import Link from "next/link";
import { cn } from "@/lib/utils";

export default function TicketsFilter({
  base,
  current,
  items,
}: {
  base: string;
  current: string;
  items: { key: string; label: string; count: number }[];
}) {
  return (
    <div className="flex flex-wrap gap-2" role="tablist" aria-label="فیلتر بلیط‌ها">
      {items.map((it) => {
        const active = current === it.key;
        return (
          <Link
            key={it.key}
            href={it.key === "all" ? base : `${base}?filter=${it.key}`}
            role="tab"
            aria-selected={active}
            className={cn(
              "clip-notch flex items-center gap-2 border px-4 py-2.5 text-[12.5px] font-semibold transition-all",
              active
                ? "border-cyan/45 bg-cyan/14 text-cyan-hot shadow-[0_0_22px_-10px_rgba(34,211,238,0.9)]"
                : "border-hairline bg-deep/50 text-ink-dim hover:border-hairline-strong hover:text-ink-soft",
            )}
          >
            {it.label}
            <span
              className={cn(
                "rounded-full px-1.5 py-0.5 font-num text-[10px] font-bold",
                active ? "bg-cyan/25 text-cyan-hot" : "bg-raised text-ink-dim",
              )}
            >
              {it.count}
            </span>
          </Link>
        );
      })}
    </div>
  );
}
