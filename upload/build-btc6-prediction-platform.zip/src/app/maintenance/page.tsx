import type { Metadata } from "next";
import { ButtonLink } from "@/components/ui";
import { Wrench, Clock, Bell } from "lucide-react";

export const metadata: Metadata = { title: "نگهداری سیستم" };

export default function MaintenancePage() {
  return (
    <div className="relative flex min-h-[100svh] items-center justify-center overflow-hidden px-4">
      <div className="pointer-events-none absolute inset-0 grid-floor opacity-25 [mask-image:radial-gradient(50%_50%_at_50%_50%,#000,transparent_75%)]" />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px animate-scan bg-[linear-gradient(90deg,transparent,rgba(247,147,26,0.6),transparent)]" />
      <div className="relative max-w-xl text-center">
        <div className="clip-notch mx-auto mb-7 inline-flex items-center gap-2.5 border border-orange/35 bg-orange/10 px-4 py-2">
          <Wrench size={15} className="text-orange-soft" />
          <span className="font-mono text-[10px] tracking-[0.24em] text-orange-soft">SCHEDULED MAINTENANCE</span>
        </div>

        <h1 className="text-[clamp(1.8rem,5vw,2.6rem)] font-black leading-tight text-ink">
          هسته BTC6 در حال ارتقا است
        </h1>
        <p className="mx-auto mt-5 max-w-lg text-[14px] leading-[2] text-ink-soft">
          برای افزودن قابلیت‌های جدید، سرویس موقتاً از دسترس خارج شده است. کشش‌های در جریان پس از بازگشت
          سرویس به‌صورت خودکار تسویه می‌شوند و موجودی و بلیط‌های شما کاملاً محفوظ است.
        </p>

        <div className="mx-auto mt-9 grid max-w-md grid-cols-2 gap-3">
          {[
            [Clock, "زمان تقریبی بازگشت", "۳۰ دقیقه"],
            [Bell, "وضعیت بلیط‌ها", "محفوظ و فعال"],
          ].map(([Icon, l, v]) => {
            const I = Icon as typeof Clock;
            return (
              <div key={l as string} className="clip-notch border border-hairline bg-deep/50 p-4 text-right">
                <I size={16} className="text-cyan-hot" />
                <p className="mt-3 font-mono text-[9px] tracking-[0.18em] text-ink-dim">{l as string}</p>
                <p className="mt-1 text-[14px] font-bold text-ink">{v as string}</p>
              </div>
            );
          })}
        </div>

        <div className="mt-9 flex flex-wrap justify-center gap-3">
          <ButtonLink href="/" variant="outline" size="lg">
            تلاش برای بازگشت
          </ButtonLink>
        </div>

        <p className="mt-10 font-mono text-[9.5px] leading-relaxed tracking-[0.18em] text-ink-dim/70">
          BTC6 · STATUS PAGE · ALL SYSTEMS MONITORED
        </p>
      </div>
    </div>
  );
}
