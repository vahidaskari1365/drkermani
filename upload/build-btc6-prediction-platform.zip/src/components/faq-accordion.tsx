"use client";

import { useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus } from "lucide-react";
import { cn } from "@/lib/utils";

export default function FaqAccordion({
  items,
}: {
  items: { q: string; a: string }[];
}) {
  const [open, setOpen] = useState<number | null>(0);
  const refs = useRef<(HTMLButtonElement | null)[]>([]);

  return (
    <div className="space-y-3">
      {items.map((item, i) => {
        const isOpen = open === i;
        return (
          <div
            key={item.q}
            className={cn(
              "clip-cyber border bg-[linear-gradient(180deg,rgba(17,28,48,0.6),rgba(8,13,24,0.8))] transition-colors",
              isOpen ? "border-cyan/30" : "border-hairline",
            )}
          >
            <h2>
              <button
                ref={(el) => {
                  refs.current[i] = el;
                }}
                onClick={() => setOpen(isOpen ? null : i)}
                aria-expanded={isOpen}
                aria-controls={`faq-panel-${i}`}
                className="flex w-full items-center gap-4 px-5 py-4 text-right"
              >
                <span className="font-num text-[11px] text-cyan/60">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <span className="flex-1 text-[14px] font-bold text-ink">{item.q}</span>
                <motion.span
                  animate={{ rotate: isOpen ? 45 : 0 }}
                  transition={{ duration: 0.3 }}
                  className={cn(
                    "grid h-7 w-7 shrink-0 place-items-center rounded-lg border",
                    isOpen ? "border-cyan/40 bg-cyan/12 text-cyan-hot" : "border-hairline text-ink-dim",
                  )}
                >
                  <Plus size={14} />
                </motion.span>
              </button>
            </h2>
            <AnimatePresence initial={false}>
              {isOpen && (
                <motion.div
                  id={`faq-panel-${i}`}
                  key="panel"
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
                  className="overflow-hidden"
                >
                  <p className="border-t border-hairline px-5 py-4 text-[13px] leading-[2.1] text-ink-soft">
                    {item.a}
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        );
      })}
    </div>
  );
}
