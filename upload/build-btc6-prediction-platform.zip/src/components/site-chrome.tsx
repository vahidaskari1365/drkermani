"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Menu, X, Ticket, Zap } from "lucide-react";
import { Btc6Logo } from "@/components/logo";
import { ButtonLink } from "@/components/ui";
import { cn, money } from "@/lib/utils";
import { useMarket, useCountdown } from "@/lib/useLive";

const LINKS = [
  { href: "/how-it-works", label: "چطور کار می‌کند" },
  { href: "/rules", label: "قوانین بازی" },
  { href: "/faq", label: "سوالات متداول" },
];

export function SiteHeader({ loggedIn }: { loggedIn: boolean }) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [solid, setSolid] = useState(false);
  const { market } = useMarket();
  const cd = useCountdown(market?.closeTime);

  useEffect(() => {
    const onScroll = () => setSolid(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => setOpen(false), [pathname]);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-300",
        solid ? "border-b border-hairline bg-abyss/85 backdrop-blur-xl" : "bg-transparent",
      )}
    >
      <div className="mx-auto flex h-16 w-full max-w-[1240px] items-center gap-6 px-4 sm:px-6">
        <Link href="/" aria-label="صفحه اصلی BTC6">
          <Btc6Logo />
        </Link>

        <nav aria-label="ناوبری سایت" className="hidden items-center gap-1 md:flex">
          {LINKS.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className={cn(
                "rounded-lg px-3 py-2 text-[13px] font-semibold transition-colors",
                pathname === l.href ? "text-cyan-hot" : "text-ink-dim hover:text-ink",
              )}
            >
              {l.label}
            </Link>
          ))}
        </nav>

        <div className="flex-1" />

        <div className="hidden items-center gap-3 rounded-xl border border-hairline bg-deep/60 px-3.5 py-1.5 lg:flex">
          <span className="font-mono text-[9px] tracking-[0.2em] text-ink-dim">BTC/USDT</span>
          <span className="font-num text-[13px] font-bold text-ink" dir="ltr">
            {market ? money(market.price) : "—"}
          </span>
          <span className="h-3.5 w-px bg-hairline" />
          <span className="font-num text-[12px] font-bold text-cyan-hot" dir="ltr">
            {cd.hours}:{cd.minutes}:{cd.seconds}
          </span>
        </div>

        {loggedIn ? (
          <ButtonLink href="/dashboard" size="md" className="hidden sm:inline-flex">
            <Zap size={15} />
            مرکز کنترل
          </ButtonLink>
        ) : (
          <>
            <ButtonLink href="/login" variant="ghost" size="md" className="hidden sm:inline-flex">
              ورود
            </ButtonLink>
            <ButtonLink href="/register" size="md" className="hidden sm:inline-flex">
              <Ticket size={15} />
              ساخت حساب
            </ButtonLink>
          </>
        )}

        <button
          onClick={() => setOpen((v) => !v)}
          aria-label="منو"
          aria-expanded={open}
          className="grid h-9 w-9 place-items-center rounded-lg border border-hairline text-ink-soft md:hidden"
        >
          {open ? <X size={17} /> : <Menu size={17} />}
        </button>
      </div>

      {open && (
        <div className="border-t border-hairline bg-abyss/97 px-4 py-4 backdrop-blur-xl md:hidden">
          <nav className="flex flex-col gap-1">
            {LINKS.map((l) => (
              <Link
                key={l.href}
                href={l.href}
                className="rounded-lg px-3 py-3 text-[14px] font-semibold text-ink-soft hover:bg-cyan/10 hover:text-cyan-hot"
              >
                {l.label}
              </Link>
            ))}
          </nav>
          <div className="mt-4 grid grid-cols-2 gap-3">
            <ButtonLink href={loggedIn ? "/dashboard" : "/login"} variant="outline" size="lg">
              {loggedIn ? "کنترل" : "ورود"}
            </ButtonLink>
            <ButtonLink href={loggedIn ? "/play" : "/register"} size="lg">
              {loggedIn ? "بازی" : "ثبت‌نام"}
            </ButtonLink>
          </div>
        </div>
      )}
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="relative border-t border-hairline bg-abyss/60">
      <div className="mx-auto grid w-full max-w-[1240px] gap-10 px-4 py-14 sm:px-6 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <Btc6Logo />
          <p className="mt-4 max-w-sm text-[12.5px] leading-relaxed text-ink-dim">
            BTC6 یک بازی پیش‌بینی روی کندل یک‌ساعته BTC/USDT است. هر بلیط یک قطعه دیجیتال از آینده بازار
            است — شش رقم و یک رنگ.
          </p>
          <p className="mt-5 font-mono text-[9.5px] leading-relaxed tracking-[0.16em] text-ink-dim/70">
            ۱۸+ · بازی مهارتی پیش‌بینی · مسئولیت کامل با کاربر
          </p>
        </div>
        <div>
          <p className="mb-4 font-mono text-[9.5px] tracking-[0.28em] text-cyan/80">NAVIGATE</p>
          <ul className="space-y-2.5 text-[12.5px] text-ink-dim">
            {[["/", "صفحه اصلی"], ["/how-it-works", "چطور کار می‌کند"], ["/rules", "قوانین بازی"], ["/faq", "سوالات متداول"]].map(
              ([href, label]) => (
                <li key={href}>
                  <Link href={href} className="transition-colors hover:text-cyan-hot">
                    {label}
                  </Link>
                </li>
              ),
            )}
          </ul>
        </div>
        <div>
          <p className="mb-4 font-mono text-[9.5px] tracking-[0.28em] text-cyan/80">LEGAL</p>
          <ul className="space-y-2.5 text-[12.5px] text-ink-dim">
            {[["/terms", "شرایط استفاده"], ["/privacy", "حریم خصوصی"], ["/login", "ورود"], ["/register", "ثبت‌نام"]].map(
              ([href, label]) => (
                <li key={href}>
                  <Link href={href} className="transition-colors hover:text-cyan-hot">
                    {label}
                  </Link>
                </li>
              ),
            )}
          </ul>
        </div>
      </div>
      <div className="border-t border-hairline">
        <div className="mx-auto flex w-full max-w-[1240px] flex-wrap items-center justify-between gap-3 px-4 py-5 sm:px-6">
          <p className="font-mono text-[9.5px] tracking-[0.2em] text-ink-dim/70">
            © {new Date().getFullYear()} BTC6 · ALL SIGNALS RESERVED
          </p>
          <p className="font-mono text-[9.5px] tracking-[0.2em] text-ink-dim/70" dir="ltr">
            BTC/USDT · 1H · VERIFIABLE DRAW
          </p>
        </div>
      </div>
    </footer>
  );
}
