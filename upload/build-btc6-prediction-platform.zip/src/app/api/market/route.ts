import { getFeed, roundNumberFromTime } from "@/lib/market";
import { settleDueRounds } from "@/lib/rounds";

export const dynamic = "force-dynamic";

const g = globalThis as typeof globalThis & { __btc6LastSettle?: number };

export async function GET() {
  try {
    if (!g.__btc6LastSettle || Date.now() - g.__btc6LastSettle > 20_000) {
      g.__btc6LastSettle = Date.now();
      await settleDueRounds();
    }
    const feed = await getFeed(24);
    const first = feed.closed[0];
    const changePct = first ? ((feed.live.close - first.close) / first.close) * 100 : 0;
    const start = roundNumberFromTime(feed.live.openTime) * 3_600_000;
    const end = start + 3_600_000;

    return Response.json({
      price: feed.live.close,
      open: feed.live.open,
      high: feed.live.high,
      low: feed.live.low,
      changePct: Math.round(changePct * 100) / 100,
      source: feed.source,
      roundNumber: feed.currentRound,
      openTime: new Date(start).toISOString(),
      closeTime: new Date(end).toISOString(),
      progress: Math.min(1, Math.max(0, (Date.now() - start) / 3_600_000)),
    });
  } catch {
    return Response.json({ error: "feed_unavailable" }, { status: 503 });
  }
}
