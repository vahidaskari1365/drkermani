/**
 * BTC6 demo seed — creates a demo player, settled rounds and tickets
 * so the interface is populated on first load. Safe to re-run.
 */
import { Client } from "pg";
import { randomBytes, scryptSync } from "node:crypto";

const url = process.env.DATABASE_URL ?? "postgresql://postgres:postgres@127.0.0.1:5432/app_db";
const HOUR = 3_600_000;
const PRICE = 10;

/* ---- mirror of src/lib/market.ts simulated candle ---- */
function hash32(n) {
  let x = n | 0;
  x = (x ^ 61) ^ (x >>> 16);
  x = x + (x << 3);
  x = x ^ (x >>> 4);
  x = Math.imul(x, 0x27d4eb2d);
  x = x ^ (x >>> 15);
  return x >>> 0;
}
function mulberry32(a) {
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function basePrice(round) {
  const rnd = mulberry32(hash32(round));
  let p = 84000;
  for (let i = 0; i < 6; i++) p += (rnd() - 0.5) * 2600;
  p += Math.sin(round / 37) * 4200 + Math.cos(round / 11) * 1500;
  return Math.max(12000, p);
}
function simulatedCandle(round) {
  const rnd = mulberry32(hash32(round + 977));
  const open = basePrice(round);
  const close = basePrice(round + 1) + (rnd() - 0.5) * 900;
  const span = 180 + rnd() * 1400;
  const high = Math.max(open, close) + span * (0.35 + rnd() * 0.65);
  const low = Math.min(open, close) - span * rnd() * 0.7;
  const r2 = (v) => Math.round(v * 100) / 100;
  return { open: r2(open), high: r2(high), low: r2(Math.max(1, low)), close: r2(close) };
}
const lastTwo = (p) => Math.abs(Math.round(p * 100) / 100).toFixed(2).slice(-2);
const colorOf = (o, c) => (c > o ? "GREEN" : c < o ? "RED" : "WHITE");
const digitScore = (a, b) => (a[0] === b[0] ? 1 : 0) + (a[1] === b[1] ? 1 : 0);
function mult(score, colorMatch) {
  if (score >= 6 && colorMatch) return 1000;
  if (score >= 6) return 200;
  if (score >= 5) return 50;
  if (score >= 4) return 12;
  if (score >= 3) return 3;
  if (score >= 2 && colorMatch) return 1.5;
  if (colorMatch) return 0.5;
  return 0;
}
const code = () => `BTC6-${randomBytes(4).toString("hex").toUpperCase().slice(0, 6)}`;

async function main() {
  const client = new Client({ connectionString: url });
  await client.connect();

  const currentRound = Math.floor(Date.now() / HOUR);
  const roundNumbers = Array.from({ length: 7 }, (_, i) => currentRound - 1 - i);

  // demo user
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync("demo1234", salt, 64).toString("hex");
  const existing = await client.query("select id from users where username = $1", ["demo"]);
  let userId;
  if (existing.rows.length) {
    userId = existing.rows[0].id;
  } else {
    const res = await client.query(
      `insert into users (email, username, password_hash, balance, avatar_seed)
       values ($1,$2,$3,$4,$5) returning id`,
      ["demo@btc6.io", "demo", `${salt}:${hash}`, "0", 3],
    );
    userId = res.rows[0].id;
  }

  await client.query("delete from tickets where user_id = $1", [userId]);
  await client.query("delete from transactions where user_id = $1", [userId]);
  await client.query("delete from notifications where user_id = $1", [userId]);

  // rounds
  const roundIds = {};
  for (const n of roundNumbers) {
    const c = simulatedCandle(n);
    const dOpen = lastTwo(c.open);
    const dHigh = lastTwo(c.high);
    const dClose = lastTwo(c.close);
    const col = colorOf(c.open, c.close);
    const res = await client.query(
      `insert into rounds (round_number, open_time, close_time, ticket_price, status,
        open_price, high_price, low_price, close_price, d_open, d_high, d_close, candle_color, source, settled_at)
       values ($1,$2,$3,$4,'settled',$5,$6,$7,$8,$9,$10,$11,$12,'simulated',$13)
       on conflict (round_number) do update set
         status='settled', open_price=$5, high_price=$6, low_price=$7, close_price=$8,
         d_open=$9, d_high=$10, d_close=$11, candle_color=$12, settled_at=$13
       returning id`,
      [
        n,
        new Date(n * HOUR),
        new Date((n + 1) * HOUR),
        String(PRICE),
        String(c.open),
        String(c.high),
        String(c.low),
        String(c.close),
        dOpen,
        dHigh,
        dClose,
        col,
        new Date((n + 1) * HOUR),
      ],
    );
    roundIds[n] = { id: res.rows[0].id, dOpen, dHigh, dClose, col };
  }

  // ticket plan: grand prize, four-digit prize, two losses, one colour-only refund
  const plan = [
    { r: roundNumbers[0], tier: "grand" },
    { r: roundNumbers[1], tier: "lost" },
    { r: roundNumbers[2], tier: "four" },
    { r: roundNumbers[3], tier: "lost" },
    { r: roundNumbers[4], tier: "color" },
  ];

  let balance = 0;
  const txs = [];
  const notifs = [];

  balance += 1000;
  txs.push({
    kind: "deposit",
    amount: 1000,
    note: "واریز اولیه به کیف پول BTC6",
    ref: `DEP-${randomBytes(3).toString("hex").toUpperCase()}`,
  });

  for (const item of plan) {
    const info = roundIds[item.r];
    let pOpen, pHigh, pClose, pColor;
    if (item.tier === "grand") {
      pOpen = info.dOpen;
      pHigh = info.dHigh;
      pClose = info.dClose;
      pColor = info.col;
    } else if (item.tier === "four") {
      pOpen = info.dOpen;
      pHigh = info.dHigh[0] + String((Number(info.dHigh[1]) + 4) % 10);
      pClose = info.dClose[0] + String((Number(info.dClose[1]) + 4) % 10);
      pColor = info.col === "GREEN" ? "RED" : "GREEN";
    } else if (item.tier === "color") {
      const bump = (s) => String((Number(s) + 37) % 100).padStart(2, "0");
      pOpen = bump(info.dOpen);
      pHigh = bump(info.dHigh);
      pClose = bump(info.dClose);
      pColor = info.col;
    } else {
      const bump = (s) => String((Number(s) + 17) % 100).padStart(2, "0");
      pOpen = bump(info.dOpen);
      pHigh = bump(info.dHigh);
      pClose = bump(info.dClose);
      pColor = info.col === "GREEN" ? "RED" : "GREEN";
    }
    const score =
      digitScore(pOpen, info.dOpen) + digitScore(pHigh, info.dHigh) + digitScore(pClose, info.dClose);
    const colorMatch = pColor === info.col;
    const m = mult(score, colorMatch);
    const payout = Math.round(PRICE * m * 100) / 100;
    const status = payout > 0 ? "won" : "lost";
    const c = code();

    balance -= PRICE;
    await client.query(
      `insert into tickets (code, user_id, round_id, p_open, p_high, p_close, p_color, price, status, matches, payout, created_at, settled_at)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)`,
      [
        c,
        userId,
        info.id,
        pOpen,
        pHigh,
        pClose,
        pColor,
        String(PRICE),
        status,
        score,
        String(payout),
        new Date(item.r * HOUR + 8 * 60_000),
        new Date((item.r + 1) * HOUR),
      ],
    );
    txs.push({
      kind: "ticket",
      amount: PRICE,
      note: `خرید بلیط ${c} برای کشش #${item.r}`,
      ref: `TXN-${randomBytes(3).toString("hex").toUpperCase()}`,
    });
    if (payout > 0) {
      balance += payout;
      txs.push({
        kind: "payout",
        amount: payout,
        note: `جایزه بلیط ${c}`,
        ref: `TXN-${randomBytes(3).toString("hex").toUpperCase()}`,
      });
      notifs.push({
        kind: "win",
        title: `برنده شدی! ${payout} USDT`,
        body: `بلیط ${c} با ${score} رقم درست برنده شد.`,
        href: "/tickets",
      });
    } else {
      notifs.push({
        kind: "loss",
        title: `بلیط ${c} برنده نشد`,
        body: `کاندل پایانی ${info.dOpen} / ${info.dHigh} / ${info.dClose} و رنگ ${info.col} بود.`,
        href: "/tickets",
      });
    }
  }

  balance = Math.round((balance + 350) * 100) / 100;
  txs.push({
    kind: "deposit",
    amount: 350,
    note: "واریز مکانی",
    ref: `DEP-${randomBytes(3).toString("hex").toUpperCase()}`,
  });

  let running = 0;
  for (const t of txs) {
    running = Math.round((running + (t.kind === "ticket" ? -t.amount : t.amount)) * 100) / 100;
    await client.query(
      `insert into transactions (user_id, kind, amount, status, reference, note, balance_after)
       values ($1,$2,$3,'completed',$4,$5,$6)`,
      [userId, t.kind, String(t.amount), t.ref, t.note, String(running)],
    );
  }

  await client.query("update users set balance = $1 where id = $2", [String(balance), userId]);

  notifs.push({
    kind: "system",
    title: "خوش آمدی به BTC6",
    body: "حساب نمایشی تو آماده است. برای کشش بعدی شش رقم و یک رنگ انتخاب کن.",
    href: "/play",
  });

  for (const n of notifs) {
    await client.query(
      `insert into notifications (user_id, kind, title, body, href, is_read)
       values ($1,$2,$3,$4,$5,false)`,
      [userId, n.kind, n.title, n.body, n.href],
    );
  }

  console.log(`seeded demo user #${userId} · balance ${balance} USDT · ${txs.length} txs`);
  await client.end();
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
