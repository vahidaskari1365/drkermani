"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { Save, Check, AlertCircle, Volume2, VolumeX, Bell, BellOff } from "lucide-react";
import { Button, Field, Input, Card, CardTitle, Alert } from "@/components/ui";
import { cn } from "@/lib/utils";

export default function ProfileForm({
  username,
  email,
  walletAddress,
  notifyLevel,
  soundEnabled,
}: {
  username: string;
  email: string;
  walletAddress: string | null;
  notifyLevel: number;
  soundEnabled: boolean;
}) {
  const router = useRouter();
  const [form, setForm] = useState({
    username,
    email,
    walletAddress: walletAddress ?? "",
  });
  const [level, setLevel] = useState(notifyLevel);
  const [sound, setSound] = useState(soundEnabled);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [saved, setSaved] = useState(false);

  async function save(patch: Record<string, unknown>) {
    setError("");
    setSaved(false);
    setLoading(true);
    try {
      const res = await fetch("/api/account", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(patch),
      });
      const json = (await res.json()) as { error?: string };
      if (!res.ok) {
        setError(json.error ?? "ذخیره نشد.");
        return;
      }
      setSaved(true);
      router.refresh();
      window.setTimeout(() => setSaved(false), 2600);
    } catch {
      setError("ارتباط با سرور برقرار نشد.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="grid gap-5 lg:grid-cols-[1.25fr_1fr]">
      <Card>
        <CardTitle kicker="ACCOUNT" icon={<Save size={16} />}>
          اطلاعات حساب
        </CardTitle>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void save(form);
          }}
          className="space-y-5"
        >
          {error && (
            <div role="alert" className="clip-notch flex items-start gap-2.5 border border-loss/40 bg-loss/10 px-3.5 py-3 text-[12px] text-loss">
              <AlertCircle size={15} className="mt-0.5 shrink-0" />
              {error}
            </div>
          )}
          {saved && <Alert tone="success" title="ذخیره شد">تغییرات با موفقیت ثبت شد.</Alert>}

          <Field label="نام کاربری" hint="a-z 0-9 _" htmlFor="pusername">
            <Input
              id="pusername"
              dir="ltr"
              value={form.username}
              onChange={(e) => setForm((f) => ({ ...f, username: e.target.value }))}
            />
          </Field>
          <Field label="ایمیل" htmlFor="pemail">
            <Input
              id="pemail"
              type="email"
              dir="ltr"
              value={form.email}
              onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
            />
          </Field>
          <Field label="آدرس کیف پول پیش‌فرض (TRC20)" hint="اختیاری" htmlFor="paddr">
            <Input
              id="paddr"
              dir="ltr"
              placeholder="T…"
              value={form.walletAddress}
              onChange={(e) => setForm((f) => ({ ...f, walletAddress: e.target.value }))}
            />
          </Field>
          <Button type="submit" size="lg" loading={loading} disabled={loading} className="w-full sm:w-auto">
            <Save size={16} />
            ذخیره تغییرات
          </Button>
        </form>
      </Card>

      <div className="space-y-5">
        <Card>
          <CardTitle kicker="PREFERENCES" icon={<Bell size={16} />}>
            اعلان‌ها
          </CardTitle>
          <div className="space-y-2.5">
            {[
              { v: 0, label: "خاموش", desc: "هیچ اعلانی دریافت نکن", icon: BellOff },
              { v: 1, label: "ضروری", desc: "فقط برد و تراکنش‌های مالی", icon: Bell },
              { v: 2, label: "همه", desc: "برد، باخت، تراکنش و پیام سیستمی", icon: Bell },
            ].map((o) => (
              <button
                key={o.v}
                onClick={() => {
                  setLevel(o.v);
                  void save({ notifyLevel: o.v });
                }}
                aria-pressed={level === o.v}
                className={cn(
                  "clip-notch flex w-full items-center gap-3 border px-4 py-3 text-right transition-all",
                  level === o.v
                    ? "border-cyan/45 bg-cyan/12"
                    : "border-hairline bg-deep/50 hover:border-hairline-strong",
                )}
              >
                <span
                  className={cn(
                    "grid h-8 w-8 shrink-0 place-items-center rounded-lg border",
                    level === o.v ? "border-cyan/40 text-cyan-hot" : "border-hairline text-ink-dim",
                  )}
                >
                  <o.icon size={15} />
                </span>
                <span className="min-w-0 flex-1">
                  <span className={cn("block text-[13px] font-bold", level === o.v ? "text-cyan-hot" : "text-ink")}>
                    {o.label}
                  </span>
                  <span className="mt-0.5 block text-[11.5px] text-ink-dim">{o.desc}</span>
                </span>
                {level === o.v && <Check size={15} className="shrink-0 text-cyan-hot" />}
              </button>
            ))}
          </div>
        </Card>

        <Card>
          <CardTitle kicker="SOUND" icon={sound ? <Volume2 size={16} /> : <VolumeX size={16} />}>
            افکت صوتی
          </CardTitle>
          <button
            onClick={() => {
              const next = !sound;
              setSound(next);
              void save({ soundEnabled: next });
            }}
            aria-pressed={sound}
            className={cn(
              "clip-notch flex w-full items-center justify-between border px-4 py-3.5 transition-all",
              sound ? "border-cyan/45 bg-cyan/12" : "border-hairline bg-deep/50",
            )}
          >
            <span className="flex items-center gap-3">
              <motion.span
                animate={{ scale: sound ? [1, 1.15, 1] : 1 }}
                transition={{ duration: 1.6, repeat: sound ? Infinity : 0 }}
                className={cn("grid h-8 w-8 place-items-center rounded-lg border", sound ? "border-cyan/40 text-cyan-hot" : "border-hairline text-ink-dim")}
              >
                {sound ? <Volume2 size={15} /> : <VolumeX size={15} />}
              </motion.span>
              <span className={cn("text-[13px] font-bold", sound ? "text-cyan-hot" : "text-ink")}>
                {sound ? "صدا فعال است" : "صدا خاموش است"}
              </span>
            </span>
            <span
              className={cn(
                "relative h-6 w-11 rounded-full transition-colors",
                sound ? "bg-cyan/70" : "bg-raised",
              )}
            >
              <motion.span
                animate={{ x: sound ? -20 : 0 }}
                transition={{ type: "spring", stiffness: 400, damping: 26 }}
                className="absolute right-0 top-0.5 h-5 w-5 rounded-full bg-void shadow"
              />
            </span>
          </button>
          <p className="mt-3 text-[11.5px] leading-relaxed text-ink-dim">
            افکت صوتی برای اعلام نتیجه بلیط و رویدادهای کیف پول.
          </p>
        </Card>
      </div>
    </div>
  );
}
