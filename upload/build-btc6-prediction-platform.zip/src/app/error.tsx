"use client";

import { useEffect } from "react";
import Link from "next/link";
import { Button, ButtonLink } from "@/components/ui";
import { AlertTriangle, RotateCcw, Home } from "lucide-react";

export default function ErrorBoundary({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("BTC6 error boundary:", error);
  }, [error]);

  return (
    <div className="relative flex min-h-[100svh] items-center justify-center overflow-hidden px-4">
      <div className="pointer-events-none absolute inset-0 grid-floor opacity-25 [mask-image:radial-gradient(50%_50%_at_50%_50%,#000,transparent_75%)]" />
      <div className="relative max-w-lg text-center">
        <div className="clip-notch mx-auto mb-6 inline-flex items-center gap-2.5 border border-loss/35 bg-loss/10 px-4 py-2">
          <AlertTriangle size={15} className="text-loss" />
          <span className="font-mono text-[10px] tracking-[0.24em] text-loss">SYSTEM FAULT · 500</span>
        </div>
        <h1 className="text-[24px] font-extrabold text-ink">خطای غیرمنتظره رخ داد</h1>
        <p className="mx-auto mt-4 max-w-md text-[13.5px] leading-[2] text-ink-soft">
          ارتباط با هسته BTC6 برای لحظه‌ای قطع شد. موجودی و بلیط‌های شما کاملاً محفوظ هستند. لطفاً دوباره
          تلاش کن.
        </p>
        {error.digest && (
          <p className="mt-4 font-mono text-[10px] tracking-[0.16em] text-ink-dim" dir="ltr">
            REF: {error.digest}
          </p>
        )}
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Button size="lg" onClick={reset}>
            <RotateCcw size={16} />
            تلاش مجدد
          </Button>
          <ButtonLink href="/" variant="outline" size="lg">
            <Home size={16} />
            صفحه اصلی
          </ButtonLink>
        </div>
        <p className="mt-10 font-mono text-[10px] tracking-[0.18em] text-ink-dim">
          اگر خطا ادامه داشت،{" "}
          <Link href="/faq" className="text-cyan-hot hover:text-ink">
            بخش سوالات متداول
          </Link>{" "}
          را ببین.
        </p>
      </div>
    </div>
  );
}
