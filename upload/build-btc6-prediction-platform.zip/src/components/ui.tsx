import Link from "next/link";
import type { ComponentProps, ReactNode } from "react";
import { cn } from "@/lib/utils";

/* ============================== BUTTON ============================== */
type Variant = "primary" | "orange" | "ghost" | "outline" | "danger" | "success" | "subtle";
type Size = "sm" | "md" | "lg" | "xl";

const variants: Record<Variant, string> = {
  primary:
    "bg-gradient-to-b from-cyan-hot to-cyan text-void font-extrabold shadow-[0_0_28px_-8px_rgba(34,211,238,0.75)] hover:from-white hover:to-cyan-hot hover:shadow-[0_0_38px_-6px_rgba(34,211,238,0.95)]",
  orange:
    "bg-gradient-to-b from-orange-soft to-orange text-[#241300] font-extrabold shadow-[0_0_28px_-8px_rgba(247,147,26,0.7)] hover:from-white hover:to-orange",
  ghost: "bg-transparent text-ink-soft hover:bg-cyan/10 hover:text-cyan-hot border border-hairline",
  outline: "bg-panel/60 text-ink border border-cyan/35 hover:border-cyan-hot hover:bg-cyan/10",
  danger:
    "bg-gradient-to-b from-[#ff5c78] to-loss text-white font-bold shadow-[0_0_26px_-10px_rgba(255,59,92,0.8)] hover:brightness-110",
  success:
    "bg-gradient-to-b from-[#3cf0b4] to-win text-[#00291b] font-extrabold shadow-[0_0_28px_-8px_rgba(22,227,154,0.7)] hover:brightness-110",
  subtle: "bg-raised/80 text-ink-soft border border-hairline hover:text-ink hover:border-hairline-strong",
};

const sizes: Record<Size, string> = {
  sm: "h-9 px-3.5 text-[12px] gap-1.5",
  md: "h-11 px-5 text-[13px] gap-2",
  lg: "h-13 px-7 text-[14px] gap-2.5",
  xl: "h-15 px-9 text-[15px] gap-3",
};

const base =
  "clip-notch relative inline-flex items-center justify-center font-semibold tracking-tight transition-all duration-200 active:scale-[0.985] disabled:pointer-events-none disabled:opacity-40 disabled:shadow-none";

export function Button({
  variant = "primary",
  size = "md",
  className,
  loading,
  children,
  ...props
}: ComponentProps<"button"> & { variant?: Variant; size?: Size; loading?: boolean }) {
  return (
    <button className={cn(base, variants[variant], sizes[size], className)} {...props}>
      {loading && (
        <span className="h-3.5 w-3.5 animate-spin rounded-full border-[2px] border-current border-t-transparent" />
      )}
      {children}
    </button>
  );
}

export function ButtonLink({
  variant = "primary",
  size = "md",
  className,
  children,
  ...props
}: ComponentProps<typeof Link> & { variant?: Variant; size?: Size }) {
  return (
    <Link className={cn(base, variants[variant], sizes[size], className)} {...props}>
      {children}
    </Link>
  );
}

/* ============================== INPUTS ============================== */
export function Field({
  label,
  hint,
  error,
  children,
  htmlFor,
}: {
  label: string;
  hint?: string;
  error?: string;
  children: ReactNode;
  htmlFor?: string;
}) {
  return (
    <div className="space-y-2">
      <label htmlFor={htmlFor} className="flex items-center justify-between text-[12.5px] font-semibold text-ink-soft">
        <span>{label}</span>
        {hint && <span className="font-mono text-[10px] tracking-wide text-ink-dim">{hint}</span>}
      </label>
      {children}
      {error && (
        <p role="alert" className="text-[11.5px] font-medium text-loss">
          {error}
        </p>
      )}
    </div>
  );
}

export const inputClass =
  "clip-notch h-12 w-full bg-abyss/85 px-4 font-mono text-[14px] tracking-wider text-ink placeholder:text-ink-dim/60 border border-hairline transition-colors focus:border-cyan-hot focus:bg-deep/90 outline-none";

export function Input({ className, ...props }: ComponentProps<"input">) {
  return <input className={cn(inputClass, className)} {...props} />;
}

/* ============================== CARD ============================== */
export function Card({
  className,
  children,
  glow,
  ...props
}: ComponentProps<"div"> & { glow?: "cyan" | "orange" | "win" }) {
  return (
    <div
      className={cn(
        "surface clip-cyber relative overflow-hidden p-5",
        glow === "cyan" && "glow-cyan",
        glow === "orange" && "glow-orange",
        glow === "win" && "glow-win",
        className,
      )}
      {...props}
    >
      {children}
    </div>
  );
}

export function CardTitle({
  children,
  kicker,
  action,
  icon,
}: {
  children: ReactNode;
  kicker?: string;
  action?: ReactNode;
  icon?: ReactNode;
}) {
  return (
    <div className="mb-4 flex items-start justify-between gap-3">
      <div className="flex items-center gap-3">
        {icon && (
          <span className="grid h-9 w-9 place-items-center rounded-lg border border-hairline bg-cyan/8 text-cyan-hot">
            {icon}
          </span>
        )}
        <div>
          {kicker && (
            <div className="font-mono text-[9.5px] tracking-[0.28em] text-cyan/80">{kicker}</div>
          )}
          <h3 className="text-[15px] font-bold text-ink">{children}</h3>
        </div>
      </div>
      {action}
    </div>
  );
}

/* ============================== BADGE ============================== */
const badgeTone: Record<string, string> = {
  active: "border-cyan/40 bg-cyan/12 text-cyan-hot",
  live: "border-cyan/40 bg-cyan/12 text-cyan-hot",
  won: "border-win/45 bg-win/12 text-win",
  win: "border-win/45 bg-win/12 text-win",
  completed: "border-win/40 bg-win/10 text-win",
  lost: "border-loss/40 bg-loss/12 text-loss",
  failed: "border-loss/40 bg-loss/12 text-loss",
  pending: "border-orange/45 bg-orange/12 text-orange-soft",
  refunded: "border-orange/40 bg-orange/10 text-orange-soft",
  neutral: "border-hairline bg-raised/70 text-ink-dim",
};

export function StatusBadge({
  status,
  label,
  dot = true,
  className,
}: {
  status: string;
  label: string;
  dot?: boolean;
  className?: string;
}) {
  const tone = badgeTone[status] ?? badgeTone.neutral;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 font-mono text-[10px] font-bold tracking-[0.12em]",
        tone,
        className,
      )}
    >
      {dot && (
        <span
          className={cn(
            "h-1.5 w-1.5 rounded-full bg-current",
            (status === "live" || status === "active" || status === "pending") && "animate-pulse",
          )}
        />
      )}
      {label}
    </span>
  );
}

/* ============================== TABLE ============================== */
export function Table({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className={cn("-mx-1 overflow-x-auto px-1", className)}>
      <table className="w-full min-w-[520px] border-collapse text-right">{children}</table>
    </div>
  );
}

export function Th({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <th
      scope="col"
      className={cn(
        "border-b border-hairline px-3 pb-3 font-mono text-[10px] font-semibold tracking-[0.18em] text-ink-dim",
        className,
      )}
    >
      {children}
    </th>
  );
}

export function Td({ children, className }: { children: ReactNode; className?: string }) {
  return <td className={cn("border-b border-hairline/60 px-3 py-3.5 text-[13px] text-ink-soft", className)}>{children}</td>;
}

/* ============================== MISC ============================== */
export function Empty({ icon, title, body, action }: { icon?: ReactNode; title: string; body?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-xl border border-dashed border-hairline px-6 py-14 text-center">
      <span className="grid h-14 w-14 place-items-center rounded-full border border-hairline bg-raised/50 text-ink-dim">
        {icon}
      </span>
      <p className="text-[14px] font-bold text-ink">{title}</p>
      {body && <p className="max-w-sm text-[12.5px] leading-relaxed text-ink-dim">{body}</p>}
      {action}
    </div>
  );
}

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn("animate-pulse rounded-md bg-raised/70", className)} />;
}

export function PageHeading({
  kicker,
  title,
  desc,
  action,
}: {
  kicker: string;
  title: string;
  desc?: string;
  action?: ReactNode;
}) {
  return (
    <header className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div>
        <div className="mb-2 flex items-center gap-2 font-mono text-[10px] tracking-[0.3em] text-cyan/80">
          <span className="h-px w-6 bg-cyan/50" />
          {kicker}
        </div>
        <h1 className="text-2xl font-extrabold text-ink sm:text-[30px]">{title}</h1>
        {desc && <p className="mt-2 max-w-xl text-[13px] leading-relaxed text-ink-dim">{desc}</p>}
      </div>
      {action}
    </header>
  );
}

export function Alert({
  tone = "info",
  title,
  children,
}: {
  tone?: "info" | "warn" | "error" | "success";
  title?: string;
  children: ReactNode;
}) {
  const map = {
    info: "border-cyan/30 bg-cyan/8 text-cyan-hot",
    warn: "border-orange/35 bg-orange/8 text-orange-soft",
    error: "border-loss/35 bg-loss/8 text-loss",
    success: "border-win/35 bg-win/8 text-win",
  };
  return (
    <div role="status" className={cn("clip-notch border px-4 py-3 text-[12.5px] leading-relaxed", map[tone])}>
      {title && <p className="mb-1 font-bold">{title}</p>}
      <div className="text-ink-soft">{children}</div>
    </div>
  );
}
