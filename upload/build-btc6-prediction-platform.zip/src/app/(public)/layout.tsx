import type { ReactNode } from "react";
import { currentUser } from "@/lib/auth";
import { SiteFooter, SiteHeader } from "@/components/site-chrome";

export const dynamic = "force-dynamic";

export default async function PublicLayout({ children }: { children: ReactNode }) {
  const user = await currentUser().catch(() => null);
  return (
    <>
      <SiteHeader loggedIn={!!user} />
      <main className="pt-16">{children}</main>
      <SiteFooter />
    </>
  );
}
