"use client";

import { useEffect, useRef, useState } from "react";

export type MarketSnapshot = {
  price: number;
  open: number;
  high: number;
  low: number;
  changePct: number;
  source: string;
  roundNumber: number;
  openTime: string;
  closeTime: string;
  progress: number;
};

export function useMarket(initial?: MarketSnapshot | null) {
  const [data, setData] = useState<MarketSnapshot | null>(initial ?? null);
  const [error, setError] = useState(false);

  useEffect(() => {
    let alive = true;
    const load = async () => {
      try {
        const res = await fetch("/api/market", { cache: "no-store" });
        if (!res.ok) throw new Error();
        const json = (await res.json()) as MarketSnapshot;
        if (alive) {
          setData(json);
          setError(false);
        }
      } catch {
        if (alive) setError(true);
      }
    };
    void load();
    const id = window.setInterval(load, 15_000);
    return () => {
      alive = false;
      window.clearInterval(id);
    };
  }, []);

  return { market: data, error };
}

export function useCountdown(target: string | null | undefined) {
  const [left, setLeft] = useState(() => msLeft(target));
  useEffect(() => {
    setLeft(msLeft(target));
    const id = window.setInterval(() => setLeft(msLeft(target)), 1000);
    return () => window.clearInterval(id);
  }, [target]);
  const total = Math.max(0, left);
  return {
    total,
    hours: pad(Math.floor(total / 3_600_000)),
    minutes: pad(Math.floor((total % 3_600_000) / 60_000)),
    seconds: pad(Math.floor((total % 60_000) / 1000)),
    done: total <= 0,
  };
}

function msLeft(target: string | null | undefined): number {
  if (!target) return 0;
  const t = new Date(target).getTime();
  if (Number.isNaN(t)) return 0;
  return t - Date.now();
}

function pad(n: number): string {
  return String(Math.max(0, n)).padStart(2, "0");
}

/** number tween for the price readout */
export function useTween(value: number, duration = 700) {
  const [display, setDisplay] = useState(value);
  const from = useRef(value);
  const start = useRef(0);

  useEffect(() => {
    from.current = display;
    start.current = performance.now();
    let raf = 0;
    const step = (now: number) => {
      const p = Math.min(1, (now - start.current) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setDisplay(from.current + (value - from.current) * eased);
      if (p < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value, duration]);

  return display;
}
