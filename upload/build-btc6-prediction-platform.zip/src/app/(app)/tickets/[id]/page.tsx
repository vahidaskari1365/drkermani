import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { tickets, rounds } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { settleDueRounds } from "@/lib/rounds";
import { digitScore, STATUS_FA } from "@/lib/game";
import { money, faDate } from "@/lib/utils";
import { PageHeading, Card, CardTitle, StatusBadge, ButtonLink, Alert } from "@/components/ui";
import Reveal from "@/components/reveal";
import DigitalTicket from "@/components/game/digital-ticket";
import TicketResult, { RefreshResult } from "@/components/ticket-result";
import { ChevronRight, TrendingUp, Ticket as TicketIcon } from "lucide-react";

export const metadata: Metadata = { title: "جزئیات بلیط" };
export const dynamic = "force-dynamic";

export default async function TicketDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await requireUser();
  const { id } = await params;
  const ticketId = Number(id);
  if (!Number.isInteger(ticketId)) notFound();

  await settleDueRounds().catch(() => 0);

  const rows = await db
    .select({
      t: tickets,
      r: rounds,
    })
    .from(tickets)
    .innerJoin(rounds, eq(rounds.id, tickets.roundId))
    .where(and(eq(tickets.id, ticketId), eq(tickets.userId, user.id)))
    .limit(1);

  if (!rows.length) notFound();
  const { t, r } = rows[0];

  const settled = t.status === "won" || t.status === "lost";
  const matches = settled
    ? digitScore(t.pOpen, r.dOpen ?? "--") +
      digitScore(t.pHigh, r.dHigh ?? "--") +
      digitScore(t.pClose, r.dClose ?? "--")
    : null;
  const colorMatch = settled ? t.pColor === r.candleColor : false;

  return (
    <>
      <PageHeading
        kicker={`TICKET · ${t.code}`}
        title={settled ? "نتیجه بلیط" : "بلیط در انتظار کشش"}
        desc={`کشش #${r.roundNumber} · بسته‌شدن کندل: ${faDate(r.closeTime)}`}
        action={
          <div className="flex flex-wrap items-center gap-3">
            <StatusBadge status={t.status} label={STATUS_FA[t.status] ?? t.status} />
            <ButtonLink href="/tickets" variant="ghost" size="md">
              <ChevronRight size={15} />
              همه بلیط‌ها
            </ButtonLink>
          </div>
        }
      />

      <div className="grid gap-5 lg:grid-cols-[1.4fr_1fr]">
        <div className="space-y-5">
          <Reveal>
            <TicketResult
              status={t.status}
              prediction={{ open: t.pOpen, high: t.pHigh, close: t.pClose, color: t.pColor }}
              result={
                settled
                  ? { open: r.dOpen ?? "--", high: r.dHigh ?? "--", close: r.dClose ?? "--", color: r.candleColor ?? "WHITE" }
                  : null
              }
              payout={Number(t.payout)}
              matches={matches}
              colorMatch={colorMatch}
            />
          </Reveal>

          <Reveal delay={0.06}>
            <DigitalTicket
              ticket={{
                code: t.code,
                roundNumber: r.roundNumber,
                open: t.pOpen,
                high: t.pHigh,
                close: t.pClose,
                color: t.pColor,
                price: t.price,
                status: t.status,
                payout: t.payout,
                matches,
                result: settled
                  ? { open: r.dOpen ?? "--", high: r.dHigh ?? "--", close: r.dClose ?? "--", color: r.candleColor ?? "WHITE" }
                  : null,
              }}
            />
          </Reveal>

          {!settled && (
            <Reveal delay={0.1}>
              <Alert tone="info" title="نتیجه هنوز اعلام نشده">
                این بلیط برای کشش #{r.roundNumber} صادر شده است. با بسته‌شدن کندل، نتیجه به‌صورت خودکار
                محاسبه و جایزه (در صورت برد) به کیف پول واریز می‌شود.
              </Alert>
            </Reveal>
          )}
        </div>

        <div className="space-y-5">
          <Reveal delay={0.08}>
            <Card>
              <CardTitle kicker="DRAW DATA" icon={<TrendingUp size={16} />}>
                داده‌های کشش
              </CardTitle>
              <dl className="space-y-2.5">
                {[
                  ["شماره کشش", `#${r.roundNumber}`],
                  ["زمان بازشدن کندل", faDate(r.openTime)],
                  ["زمان بسته‌شدن کندل", faDate(r.closeTime)],
                  ["قیمت بازشدن (OPEN)", r.openPrice ? money(r.openPrice) : "در حال تشکیل"],
                  ["بالاترین قیمت (HIGH)", r.highPrice ? money(r.highPrice) : "در حال تشکیل"],
                  ["قیمت بسته‌شدن (CLOSE)", r.closePrice ? money(r.closePrice) : "در حال تشکیل"],
                  ["رنگ کندل", r.candleColor ?? "—"],
                  ["منبع داده", r.source === "binance" ? "Binance" : "BTC6 SIM"],
                ].map(([k, v]) => (
                  <div key={k} className="flex items-center justify-between gap-3 border-b border-hairline/60 pb-2.5 last:border-0">
                    <dt className="text-[12px] text-ink-dim">{k}</dt>
                    <dd className="font-num text-[12.5px] font-bold text-ink" dir="ltr">
                      {v}
                    </dd>
                  </div>
                ))}
              </dl>
            </Card>
          </Reveal>

          <Reveal delay={0.12}>
            <Card>
              <CardTitle kicker="TICKET DATA" icon={<TicketIcon size={16} />}>
                اطلاعات بلیط
              </CardTitle>
              <dl className="space-y-2.5">
                {[
                  ["شناسه بلیط", `#${t.code}`],
                  ["زمان صدور", faDate(t.createdAt)],
                  ["مبلغ بلیط", `${money(t.price)} USDT`],
                  ["ارقام درست", `${matches ?? 0} از 6`],
                  ["جایزه", `${money(t.payout)} USDT`],
                ].map(([k, v]) => (
                  <div key={k} className="flex items-center justify-between gap-3 border-b border-hairline/60 pb-2.5 last:border-0">
                    <dt className="text-[12px] text-ink-dim">{k}</dt>
                    <dd className="font-num text-[12.5px] font-bold text-ink" dir="ltr">
                      {v}
                    </dd>
                  </div>
                ))}
              </dl>
              <div className="mt-4 flex flex-wrap gap-3">
                <RefreshResult />
                <Link
                  href="/play"
                  className="clip-notch inline-flex h-11 items-center gap-2 border border-cyan/35 bg-cyan/10 px-5 text-[13px] font-semibold text-cyan-hot transition-colors hover:bg-cyan/20"
                >
                  بلیط جدید
                </Link>
              </div>
            </Card>
          </Reveal>
        </div>
      </div>
    </>
  );
}
