import { eq, sql, and } from "drizzle-orm";
import { db } from "@/db";
import { users, tickets, transactions, notifications } from "@/db/schema";
import { currentUser } from "@/lib/auth";
import { getCurrentRound, settleDueRounds } from "@/lib/rounds";
import { COLOR_OPTIONS, TICKET_PRICE, digitScore, multiplierFor } from "@/lib/game";
import { txReference } from "@/lib/utils";

export const dynamic = "force-dynamic";

const DIGITS = /^([0-9]{2})$/;

export async function POST(req: Request) {
  const user = await currentUser();
  if (!user) return Response.json({ error: "UNAUTHORIZED" }, { status: 401 });

  try {
    await settleDueRounds();
    const body = (await req.json()) as {
      pOpen?: string;
      pHigh?: string;
      pClose?: string;
      pColor?: string;
    };

    const pOpen = (body.pOpen ?? "").trim();
    const pHigh = (body.pHigh ?? "").trim();
    const pClose = (body.pClose ?? "").trim();
    const pColor = (body.pColor ?? "").trim().toUpperCase();

    const bad = [
      !DIGITS.test(pOpen) && "OPEN",
      !DIGITS.test(pHigh) && "HIGH",
      !DIGITS.test(pClose) && "CLOSE",
    ].filter(Boolean);
    if (bad.length) {
      return Response.json({ error: `برای ${bad.join(" و ")} باید دقیقاً دو رقم انتخاب کنی.` }, { status: 400 });
    }
    if (!COLOR_OPTIONS.includes(pColor as (typeof COLOR_OPTIONS)[number])) {
      return Response.json({ error: "رنگ کندل را انتخاب کن." }, { status: 400 });
    }

    const state = await getCurrentRound();
    if (new Date(state.closeTime).getTime() - Date.now() < 45_000) {
      return Response.json(
        { error: "زمان این کشش تقریباً تمام شده. چند لحظه صبر کن تا کندل بعدی باز شود." },
        { status: 409 },
      );
    }

    const price = Number(state.round.ticketPrice) || TICKET_PRICE;
    if (Number(user.balance) < price) {
      return Response.json(
        { error: "موجودی کافی نیست. ابتدا کیف پول را شارژ کن.", code: "INSUFFICIENT" },
        { status: 402 },
      );
    }

    // one active ticket per round per user keeps the draw legible
    const existing = await db
      .select({ id: tickets.id })
      .from(tickets)
      .where(and(eq(tickets.userId, user.id), eq(tickets.roundId, state.round.id), eq(tickets.status, "active")))
      .limit(1);
    if (existing.length) {
      return Response.json(
        { error: "برای این کشش یک بلیط فعال داری. ابتدا نتیجه را ببین.", code: "DUPLICATE" },
        { status: 409 },
      );
    }

    const created = await db
      .insert(tickets)
      .values({
        code: `BTC6-${Math.random().toString(36).slice(2, 8).toUpperCase()}`,
        userId: user.id,
        roundId: state.round.id,
        pOpen,
        pHigh,
        pClose,
        pColor,
        price: String(price),
        status: "active",
      })
      .returning();
    const ticket = created[0];

    const updated = await db
      .update(users)
      .set({ balance: sql`${users.balance} - ${price}` })
      .where(eq(users.id, user.id))
      .returning({ balance: users.balance });

    await db.insert(transactions).values({
      userId: user.id,
      kind: "ticket",
      amount: String(-price),
      status: "completed",
      reference: txReference("ticket", ticket.id),
      note: `خرید بلیط ${ticket.code} برای کشش #${state.roundNumber}`,
      balanceAfter: updated[0]?.balance ?? null,
    });

    await db.insert(notifications).values({
      userId: user.id,
      kind: "info",
      title: `بلیط ${ticket.code} ثبت شد`,
      body: `پیش‌بینی OPEN ${pOpen} / HIGH ${pHigh} / CLOSE ${pClose} / رنگ ${pColor} برای کشش #${state.roundNumber}.`,
      href: `/tickets/${ticket.id}`,
    });

    // preview of what a perfect score would look like (for the confirm modal)
    const score =
      digitScore(pOpen, state.dOpen) + digitScore(pHigh, state.dHigh) + digitScore(pClose, state.dClose);
    const { multiplier } = multiplierFor(score, pColor === "GREEN" ? false : false);

    return Response.json({
      ok: true,
      ticket: {
        id: ticket.id,
        code: ticket.code,
        roundNumber: state.roundNumber,
        open: pOpen,
        high: pHigh,
        close: pClose,
        color: pColor,
        price,
        status: "active",
        closeTime: state.closeTime,
      },
      balance: updated[0]?.balance,
      previewMultiplier: multiplier,
    });
  } catch {
    return Response.json({ error: "خطا در ثبت بلیط. دوباره تلاش کن." }, { status: 500 });
  }
}
