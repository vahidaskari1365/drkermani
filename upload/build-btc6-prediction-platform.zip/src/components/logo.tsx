import { cn } from "@/lib/utils";

export function Btc6Logo({ className, compact = false }: { className?: string; compact?: boolean }) {
  return (
    <span className={cn("flex items-center gap-2.5 select-none", className)}>
      <span className="relative grid h-9 w-9 shrink-0 place-items-center">
        <svg viewBox="0 0 40 40" className="h-9 w-9" aria-hidden>
          <defs>
            <linearGradient id="lg" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#5fe9ff" />
              <stop offset="100%" stopColor="#0e7490" />
            </linearGradient>
          </defs>
          <path
            d="M8 2h24a6 6 0 0 1 6 6v24a6 6 0 0 1-6 6H8a6 6 0 0 1-6-6V8a6 6 0 0 1 6-6Z"
            fill="#060b14"
            stroke="url(#lg)"
            strokeWidth="1.4"
          />
          {/* candle glyph */}
          <rect x="17.2" y="9" width="1.6" height="22" fill="rgba(94,233,255,0.35)" />
          <rect x="11.5" y="15" width="1.6" height="11" fill="rgba(247,147,26,0.5)" />
          <rect x="26.5" y="12" width="1.6" height="14" fill="rgba(22,227,154,0.5)" />
          <rect x="13.5" y="17.5" width="9" height="6" rx="1" fill="url(#lg)" />
          <rect x="24" y="20" width="4" height="4" rx="1" fill="#f7931a" />
        </svg>
        <span className="absolute inset-0 rounded-[10px] ring-1 ring-inset ring-cyan/20" />
      </span>
      {!compact && (
        <span className="flex flex-col leading-none">
          <span className="font-disp text-[19px] font-bold tracking-[0.16em] text-ink">BTC<span className="text-cyan-hot text-glow-cyan">6</span></span>
          <span className="mt-1 font-mono text-[8px] tracking-[0.34em] text-ink-dim">CANDLE·LOTTO</span>
        </span>
      )}
    </span>
  );
}
