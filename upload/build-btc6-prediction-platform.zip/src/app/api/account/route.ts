import { and, eq, ne } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { currentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const user = await currentUser();
  if (!user) return Response.json({ error: "UNAUTHORIZED" }, { status: 401 });
  try {
    const body = (await req.json()) as {
      username?: string;
      email?: string;
      walletAddress?: string;
      notifyLevel?: number;
      soundEnabled?: boolean;
    };

    const patch: Record<string, unknown> = {};

    if (body.username !== undefined) {
      const username = body.username.trim();
      if (!/^[a-zA-Z0-9_]{3,24}$/.test(username)) {
        return Response.json({ error: "نام کاربری باید ۳ تا ۲۴ کاراکتر انگلیسی، عدد یا _ باشد." }, { status: 400 });
      }
      const clash = await db
        .select({ id: users.id })
        .from(users)
        .where(and(eq(users.username, username), ne(users.id, user.id)))
        .limit(1);
      if (clash.length) return Response.json({ error: "این نام کاربری قبلاً گرفته شده است." }, { status: 409 });
      patch.username = username;
    }

    if (body.email !== undefined) {
      const email = body.email.trim().toLowerCase();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) {
        return Response.json({ error: "ایمیل معتبر نیست." }, { status: 400 });
      }
      patch.email = email;
    }

    if (body.walletAddress !== undefined) patch.walletAddress = body.walletAddress.trim() || null;
    if (body.notifyLevel !== undefined) patch.notifyLevel = Math.min(2, Math.max(0, Number(body.notifyLevel)));
    if (body.soundEnabled !== undefined) patch.soundEnabled = Boolean(body.soundEnabled);

    if (!Object.keys(patch).length) return Response.json({ error: "تغییری ارسال نشد." }, { status: 400 });

    await db.update(users).set(patch).where(eq(users.id, user.id));
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "خطا در ذخیره تنظیمات." }, { status: 500 });
  }
}
