import type { Metadata } from "next";
import Reveal, { DocHero } from "@/components/reveal";
import { Card, CardTitle, Alert } from "@/components/ui";
import { PRIZE_TIERS } from "@/lib/game";
import { Scale, Hash, Palette, Timer, Ban, ShieldCheck } from "lucide-react";

export const metadata: Metadata = { title: "قوانین بازی" };

const COLOR_RULES = [
  { key: "GREEN", fa: "سبز", cond: "CLOSE بزرگ‌تر از OPEN باشد.", cls: "text-win border-win/40 bg-win/10" },
  { key: "RED", fa: "قرمز", cond: "CLOSE کوچک‌تر از OPEN باشد.", cls: "text-loss border-loss/40 bg-loss/10" },
  { key: "WHITE", fa: "سفید", cond: "CLOSE دقیقاً برابر OPEN باشد (دودوجی).", cls: "text-ink border-ink/30 bg-ink/8" },
];

export default function RulesPage() {
  return (
    <>
      <DocHero
        kicker="PROTOCOL / 02"
        title="قوانین رسمی بازی BTC6"
        desc="قوانین بازی به‌گونه‌ای نوشته شده‌اند که هیچ ابهامی در محاسبه نتیجه باقی نماند."
      />

      <section className="py-16 sm:py-24">
        <div className="mx-auto w-full max-w-[1000px] space-y-6 px-4 sm:px-6">
          <Reveal>
            <Card>
              <CardTitle kicker="RULE 01" icon={<Hash size={16} />}>
                چه چیزی را پیش‌بینی می‌کنی؟
              </CardTitle>
              <p className="text-[13.5px] leading-[2] text-ink-soft">
                برای هر کشش، سه جفت رقم (مجموعاً شش رقم) و یک رنگ انتخاب می‌کنی:
              </p>
              <div className="mt-4 grid gap-3 sm:grid-cols-3">
                {[
                  ["OPEN", "دو رقم آخر قیمت بازشدن کندل"],
                  ["HIGH", "دو رقم آخر بالاترین قیمت کندل"],
                  ["CLOSE", "دو رقم آخر قیمت بسته‌شدن کندل"],
                ].map(([k, v]) => (
                  <div key={k} className="clip-notch border border-hairline bg-void/40 p-4">
                    <p className="font-mono text-[13px] font-bold text-cyan-hot" dir="ltr">
                      {k}
                    </p>
                    <p className="mt-1.5 text-[12px] leading-relaxed text-ink-dim">{v}</p>
                  </div>
                ))}
              </div>
              <Alert tone="info" title="نکته مهم">
                قیمت‌ها با دو رقم اعشار محاسبه می‌شوند. مثلاً اگر OPEN واقعی ۸۴٬۲۱۹٫۴۷ باشد، دو رقم آخر
                آن <span className="font-mono text-cyan-hot">۴۷</span> است.
              </Alert>
            </Card>
          </Reveal>

          <Reveal delay={0.06}>
            <Card>
              <CardTitle kicker="RULE 02" icon={<Palette size={16} />}>
                رنگ کندل
              </CardTitle>
              <div className="space-y-2.5">
                {COLOR_RULES.map((c) => (
                  <div
                    key={c.key}
                    className={`clip-notch flex flex-wrap items-center gap-3 border px-4 py-3 ${c.cls}`}
                  >
                    <span className="font-mono text-[12px] font-bold tracking-wider" dir="ltr">
                      {c.key}
                    </span>
                    <span className="text-[13px] font-bold text-ink">{c.fa}</span>
                    <span className="text-[12.5px] text-ink-soft">{c.cond}</span>
                  </div>
                ))}
              </div>
            </Card>
          </Reveal>

          <Reveal delay={0.12}>
            <Card>
              <CardTitle kicker="RULE 03" icon={<Scale size={16} />}>
                جدول جوایز
              </CardTitle>
              <div className="overflow-x-auto">
                <table className="w-full min-w-[440px] text-right">
                  <thead>
                    <tr className="font-mono text-[9.5px] tracking-[0.18em] text-ink-dim">
                      <th className="border-b border-hairline px-3 pb-3">سطح</th>
                      <th className="border-b border-hairline px-3 pb-3">شرط</th>
                      <th className="border-b border-hairline px-3 pb-3">ضریب</th>
                      <th className="border-b border-hairline px-3 pb-3">جایزه (بلیط ۱۰ USDT)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {PRIZE_TIERS.map((t, i) => (
                      <tr key={t.key} className="transition-colors hover:bg-cyan/6">
                        <td className="border-b border-hairline/60 px-3 py-3.5 text-[13px] font-bold text-ink">
                          {t.label}
                        </td>
                        <td className="border-b border-hairline/60 px-3 py-3.5 text-[12.5px] text-ink-soft">
                          {t.digits}
                          {t.color ? " + رنگ درست" : ""}
                        </td>
                        <td className="border-b border-hairline/60 px-3 py-3.5 font-num text-[13px] text-cyan-hot" dir="ltr">
                          ×{t.multiplier}
                        </td>
                        <td
                          className={`border-b border-hairline/60 px-3 py-3.5 font-num text-[13px] font-bold ${
                            i === 0 ? "text-win" : "text-ink"
                          }`}
                          dir="ltr"
                        >
                          {(t.multiplier * 10).toLocaleString("en-US")} USDT
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <p className="mt-4 text-[12.5px] leading-[2] text-ink-dim">
                ارقام به‌صورت جایگاهی بررسی می‌شوند؛ یعنی رقم اول پیش‌بینی با رقم اول نتیجه و رقم دوم با
                رقم دوم مقایسه می‌شود.
              </p>
            </Card>
          </Reveal>

          <div className="grid gap-6 md:grid-cols-2">
            <Reveal delay={0.16}>
              <Card className="h-full">
                <CardTitle kicker="RULE 04" icon={<Timer size={16} />}>
                  زمان‌بندی
                </CardTitle>
                <ul className="space-y-3 text-[13px] leading-[1.9] text-ink-soft">
                  <li>• هر کشش معادل یک کندل یک‌ساعته است.</li>
                  <li>• خرید بلیط تا ۴۵ ثانیه مانده به پایان کندل باز است.</li>
                  <li>• برای هر کشش فقط یک بلیط فعال می‌توانی داشته باشی.</li>
                  <li>• نتیجه بلافاصله پس از بسته‌شدن کندل محاسبه می‌شود.</li>
                </ul>
              </Card>
            </Reveal>
            <Reveal delay={0.2}>
              <Card className="h-full">
                <CardTitle kicker="RULE 05" icon={<Ban size={16} />}>
                  محدودیت‌ها
                </CardTitle>
                <ul className="space-y-3 text-[13px] leading-[1.9] text-ink-soft">
                  <li>• پیش‌بینی پس از ثبت قابل ویرایش یا حذف نیست.</li>
                  <li>• حداقل واریز ۱۰ USDT و حداقل برداشت ۲۰ USDT است.</li>
                  <li>• استفاده از حساب چندگانه ممنوع است.</li>
                  <li>• سن مجاز: ۱۸ سال و بالاتر.</li>
                </ul>
              </Card>
            </Reveal>
          </div>

          <Reveal delay={0.24}>
            <Alert tone="warn" title="سلب مسئولیت">
              BTC6 یک بازی مهارتی پیش‌بینی است. نتیجه کاملاً وابسته به حرکت واقعی بازار بیت‌کوین است و
              هیچ‌گونه تضمین سودی وجود ندارد. فقط با مبلغی بازی کن که از دست دادنش برایت قابل تحمل است.
            </Alert>
          </Reveal>

          <Reveal delay={0.28}>
            <div className="flex items-center gap-3 border-t border-hairline pt-6 text-[12px] text-ink-dim">
              <ShieldCheck size={16} className="shrink-0 text-cyan/70" />
              تمام کشش‌ها با شناسه یکتا و زمان دقیق ثبت می‌شوند و در تاریخچه بلیط قابل بررسی هستند.
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
