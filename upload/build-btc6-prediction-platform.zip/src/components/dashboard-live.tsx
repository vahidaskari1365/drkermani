"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Zap, Ticket as TicketIcon, ChevronLeft, Wifi } from "lucide-react";
import CandleChart from "@/components/game/candle-chart";
import { ButtonLink } from "@/components/ui";
import { money, cn } from "@/lib/utils";
import { useMarket, useCountdown } from "@/lib/useLive";
import type { Candle } from "@/lib/market";

export default function DashboardLive({
  roundNumber,
  closeTime,
  candles,
  price,
  username,
  hasActive,
  activeTicketId,
}: {
  roundNumber: number;
  closeTime: string;
  candles: Candle[];
  price: number;
  username: string;
  hasActive: boolean;
  activeTicketId: number | null;
}) {
  const { market } = useMarket({
    price,
    open: candles.at(-1)?.open ?? price,
    high: candles.at(-1)?.high ?? price,
    low: candles.at(-1)?.low ?? price,
    changePct: 0,
    source: "binance",
    roundNumber,
    openTime: new Date(new Date(closeTime).getTime() - 3_600_000).toISOString(),
    closeTime,
    progress: 0,
  });
  const cd = useCountdown(market?.closeTime);
  const up = (market?.changePct ?? 0) >= 0;
  const pct = Math.round((market?.progress ?? 0) * 100);

  return (
    <section className="surface clip-cyber relative overflow-hidden p-5 sm:p-6">
      <span aria-hidden className="absolute inset-x-0 top-0 h-px shimmer-line" />
      <div className="pointer-events-none absolute -left-24 -top-24 h-72 w-72 rounded-full bg-[radial-gradient(circle,rgba(34,211,238,0.16),transparent_70%)] blur-xl" />

      <div className="relative flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="font-mono text-[9.5px] tracking-[0.28em] text-cyan/80">CYBER CONTROL CENTER</p>
          <h1 className="mt-1.5 text-[22px] font-extrabold text-ink sm:text-[26px]">
            سلام {username}، کشش بعدی آماده است
          </h1>
        </div>
        <div className="flex items-center gap-2">
          <span className="clip-notch flex items-center gap-2 border border-hairline bg-void/50 px-3 py-2">
            <Wifi size={12} className="text-win" />
            <span className="font-mono text-[9.5px] tracking-[0.16em] text-ink-dim">
              {market?.source === "binance" ? "BINANCE FEED" : "BTC6 SIM FEED"}
            </span>
          </span>
          <span className="clip-notch border border-cyan/30 bg-cyan/10 px-3 py-2 font-mono text-[9.5px] tracking-[0.16em] text-cyan-hot" dir="ltr">
            ROUND #{market?.roundNumber ?? roundNumber}
          </span>
        </div>
      </div>

      <div className="relative mt-6 grid gap-5 lg:grid-cols-[1fr_1.25fr]">
        {/* countdown block */}
        <div className="clip-notch border border-hairline bg-void/45 p-5">
          <p className="font-mono text-[9px] tracking-[0.22em] text-ink-dim">CANDLE CLOSES IN</p>
          <div className="mt-2 flex items-baseline gap-1.5" dir="ltr">
            {[
              [cd.hours, "HH"],
              [cd.minutes, "MM"],
              [cd.seconds, "SS"],
            ].map(([v, l], i) => (
              <span key={i} className="flex items-baseline gap-1.5">
                {i > 0 && <span className="font-num text-[24px] text-cyan/40">:</span>}
                <span className="font-num text-[40px] font-bold leading-none text-cyan-hot text-glow-cyan">
                  {v as string}
                </span>
                <span className="font-mono text-[8.5px] text-ink-dim">{l as string}</span>
              </span>
            ))}
          </div>

          <div className="mt-4 h-1.5 overflow-hidden rounded-full bg-raised">
            <motion.div
              className="h-full rounded-full bg-gradient-to-l from-cyan-hot to-cyan"
              animate={{ width: `${pct}%` }}
              transition={{ duration: 1 }}
            />
          </div>
          <p className="mt-2 font-mono text-[9.5px] text-ink-dim">{pct}% از کندل فعلی تشکیل شده</p>

          <div className="mt-5 grid grid-cols-2 gap-2.5">
            {[
              ["LIVE", market ? money(market.price) : "—"],
              ["OPEN", market ? money(market.open) : "—"],
              ["HIGH", market ? money(market.high) : "—"],
              ["LOW", market ? money(market.low) : "—"],
            ].map(([l, v]) => (
              <div key={l} className="rounded-lg border border-hairline bg-deep/60 px-3 py-2">
                <p className="font-mono text-[8.5px] tracking-[0.18em] text-ink-dim">{l}</p>
                <p className="mt-0.5 font-num text-[12.5px] font-bold text-ink" dir="ltr">
                  {v}
                </p>
              </div>
            ))}
          </div>

          <p
            className={cn("mt-3 font-num text-[12px] font-bold", up ? "text-win" : "text-loss")}
            dir="ltr"
          >
            {market ? `${up ? "▲" : "▼"} ${Math.abs(market.changePct).toFixed(2)}% (24H)` : "—"}
          </p>

          <div className="mt-5 flex flex-wrap gap-2.5">
            {hasActive ? (
              <ButtonLink href={`/tickets/${activeTicketId}`} variant="outline" size="md">
                <TicketIcon size={15} />
                مشاهده بلیط فعال
              </ButtonLink>
            ) : (
              <ButtonLink href="/play" size="md">
                <Zap size={15} />
                ثبت پیش‌بینی
              </ButtonLink>
            )}
            <Link
              href="/wallet"
              className="inline-flex items-center gap-1.5 px-2 py-2 font-mono text-[10px] tracking-[0.16em] text-ink-dim transition-colors hover:text-cyan-hot"
            >
              کیف پول
              <ChevronLeft size={12} />
            </Link>
          </div>
        </div>

        {/* chart */}
        <div className="clip-notch border border-hairline bg-void/45 p-4">
          <div className="mb-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-win" />
              <span className="font-mono text-[10px] tracking-[0.18em] text-ink-soft">BTC/USDT · 1H</span>
            </div>
            <span className="font-mono text-[9px] tracking-[0.16em] text-ink-dim">LIVE CHART</span>
          </div>
          <CandleChart candles={candles.slice(-40)} height={230} />
          <div className="mt-3 flex flex-wrap gap-x-5 gap-y-1.5 border-t border-hairline pt-3 font-mono text-[9px] tracking-[0.14em] text-ink-dim">
            <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-sm bg-win/60" /> BULL</span>
            <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-sm bg-loss/60" /> BEAR</span>
            <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-sm border border-cyan-hot" /> FORMING</span>
          </div>
        </div>
      </div>
    </section>
  );
}
