import type { Metadata } from "next";
import Link from "next/link";
import { desc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { tickets, rounds } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { getCurrentRound, getChartSeries, getRecentSettled, settleDueRounds } from "@/lib/rounds";
import { STATUS_FA, TX_FA } from "@/lib/game";
import { money, faDate, toNum } from "@/lib/utils";
import { Card, CardTitle, StatusBadge, ButtonLink, Empty, Table, Th, Td } from "@/components/ui";
import Reveal from "@/components/reveal";
import DashboardLive from "@/components/dashboard-live";
import DigitalTicket from "@/components/game/digital-ticket";
import { Wallet, Ticket, Trophy, Percent, Zap, History, Bell, ChevronLeft } from "lucide-react";

export const metadata: Metadata = { title: "مرکز کنترل" };
export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const user = await requireUser();
  await settleDueRounds().catch(() => 0);

  const [state, chart, settled, myTickets] = await Promise.all([
    getCurrentRound(),
    getChartSeries(48),
    getRecentSettled(8),
    db
      .select({
        id: tickets.id,
        code: tickets.code,
        pOpen: tickets.pOpen,
        pHigh: tickets.pHigh,
        pClose: tickets.pClose,
        pColor: tickets.pColor,
        price: tickets.price,
        status: tickets.status,
        payout: tickets.payout,
        matches: tickets.matches,
        roundNumber: rounds.roundNumber,
        dOpen: rounds.dOpen,
        dHigh: rounds.dHigh,
        dClose: rounds.dClose,
        candleColor: rounds.candleColor,
      })
      .from(tickets)
      .innerJoin(rounds, eq(rounds.id, tickets.roundId))
      .where(eq(tickets.userId, user.id))
      .orderBy(desc(tickets.id))
      .limit(6),
  ]);

  const all = myTickets;
  const total = all.length;
  const wins = all.filter((t) => t.status === "won").length;
  const won = all.reduce((s, t) => s + toNum(t.payout), 0);
  const spent = all.reduce((s, t) => s + toNum(t.price), 0);
  const active = all.filter((t) => t.status === "active").length;
  const winRate = total ? Math.round((wins / total) * 100) : 0;

  const activeTicket = all.find((t) => t.status === "active");

  const stats = [
    { icon: Wallet, label: "موجودی کیف پول", value: money(user.balance), unit: "USDT", tone: "orange" },
    { icon: Ticket, label: "بلیط فعال", value: String(active), unit: "تیکت", tone: "cyan" },
    { icon: Trophy, label: "مجموع جوایز", value: money(won), unit: "USDT", tone: "win" },
    { icon: Percent, label: "نرخ برد", value: String(winRate), unit: "درصد", tone: "cyan" },
  ] as const;

  return (
    <>
      <Reveal>
        <DashboardLive
          roundNumber={state.roundNumber}
          closeTime={state.closeTime}
          candles={chart.candles}
          price={state.candle.close}
          username={user.username}
          hasActive={!!activeTicket}
          activeTicketId={activeTicket?.id ?? null}
        />
      </Reveal>

      {/* stat grid */}
      <div className="mt-5 grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map((s, i) => (
          <Reveal key={s.label} delay={i * 0.07}>
            <Card className="p-4 sm:p-5">
              <div className="flex items-start justify-between">
                <s.icon
                  size={18}
                  className={
                    s.tone === "orange"
                      ? "text-orange-soft"
                      : s.tone === "win"
                        ? "text-win"
                        : "text-cyan-hot"
                  }
                />
                <span className="font-mono text-[8.5px] tracking-[0.2em] text-ink-dim">
                  {String(i + 1).padStart(2, "0")}
                </span>
              </div>
              <p className="mt-4 font-mono text-[9px] tracking-[0.2em] text-ink-dim">{s.label}</p>
              <p className="mt-1.5 font-num text-[22px] font-bold leading-none text-ink" dir="ltr">
                {s.value} <span className="text-[10px] text-ink-dim">{s.unit}</span>
              </p>
            </Card>
          </Reveal>
        ))}
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-[1.35fr_1fr]">
        {/* my recent tickets */}
        <Reveal delay={0.05}>
          <Card className="h-full">
            <CardTitle kicker="MY TICKETS" icon={<Ticket size={16} />} action={
              <Link href="/tickets" className="flex items-center gap-1 font-mono text-[10px] text-cyan-hot hover:text-ink">
                همه <ChevronLeft size={12} />
              </Link>
            }>
              بلیط‌های اخیر
            </CardTitle>
            {all.length === 0 ? (
              <Empty
                icon={<Ticket size={22} />}
                title="هنوز بلیطی نداری"
                body="اولین پیش‌بینی خودت را برای کشش بعدی ثبت کن و بلیط دیجیتال BTC6 بگیر."
                action={<ButtonLink href="/play" size="md" className="mt-2">ورود به بازی</ButtonLink>}
              />
            ) : (
              <div className="space-y-3">
                {all.slice(0, 3).map((t) => (
                  <Link
                    key={t.id}
                    href={`/tickets/${t.id}`}
                    className="clip-notch block border border-hairline bg-void/40 p-3.5 transition-colors hover:border-cyan/35"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <span className="font-mono text-[10px] text-ink-dim" dir="ltr">#{t.code}</span>
                        <StatusBadge status={t.status} label={STATUS_FA[t.status] ?? t.status} />
                      </div>
                      <span className="font-num text-[13px] font-bold text-ink" dir="ltr">
                        {t.pOpen}·{t.pHigh}·{t.pClose}
                        <span className={`mr-2 text-[10px] ${t.pColor === "GREEN" ? "text-win" : t.pColor === "RED" ? "text-loss" : "text-ink-soft"}`}>
                          {t.pColor}
                        </span>
                      </span>
                    </div>
                    {t.status !== "active" && (
                      <div className="mt-2.5 flex items-center justify-between border-t border-hairline pt-2.5">
                        <span className="font-num text-[11px] text-ink-dim" dir="ltr">
                          RESULT: {t.dOpen}·{t.dHigh}·{t.dClose}
                        </span>
                        <span className={`font-num text-[12px] font-bold ${t.status === "won" ? "text-win" : "text-loss/70"}`} dir="ltr">
                          {t.status === "won" ? `+${money(t.payout)}` : "0.00"} USDT
                        </span>
                      </div>
                    )}
                  </Link>
                ))}
              </div>
            )}
          </Card>
        </Reveal>

        {/* last draws */}
        <Reveal delay={0.1}>
          <Card className="h-full">
            <CardTitle kicker="LAST DRAWS" icon={<History size={16} />}>
              نتایج کشش‌های اخیر
            </CardTitle>
            <Table>
              <thead>
                <tr>
                  <Th>کشش</Th>
                  <Th>O · H · C</Th>
                  <Th className="text-left">رنگ</Th>
                </tr>
              </thead>
              <tbody>
                {settled.map((r) => (
                  <tr key={r.id} className="transition-colors hover:bg-cyan/5">
                    <Td className="font-num text-[12px] text-ink" >
                      <span dir="ltr">#{r.roundNumber}</span>
                    </Td>
                    <Td className="font-num text-[12.5px] text-cyan-hot">
                      <span dir="ltr">{r.dOpen}·{r.dHigh}·{r.dClose}</span>
                    </Td>
                    <Td className="text-left">
                      <span
                        className={`font-mono text-[10px] font-bold ${
                          r.candleColor === "GREEN"
                            ? "text-win"
                            : r.candleColor === "RED"
                              ? "text-loss"
                              : "text-ink-soft"
                        }`}
                        dir="ltr"
                      >
                        {r.candleColor ?? "—"}
                      </span>
                    </Td>
                  </tr>
                ))}
              </tbody>
            </Table>
            <p className="mt-4 border-t border-hairline pt-3 font-mono text-[9.5px] leading-relaxed text-ink-dim">
              منبع داده: {state.source === "binance" ? "Binance Public API" : "شبیه‌ساز داخلی BTC6"}
            </p>
          </Card>
        </Reveal>
      </div>

      {activeTicket && (
        <Reveal delay={0.12}>
          <div className="mt-5">
            <div className="mb-3 flex items-center gap-2 font-mono text-[10px] tracking-[0.24em] text-cyan/80">
              <Bell size={12} />
              ACTIVE TICKET
            </div>
            <DigitalTicket
              ticket={{
                code: activeTicket.code,
                roundNumber: activeTicket.roundNumber,
                open: activeTicket.pOpen,
                high: activeTicket.pHigh,
                close: activeTicket.pClose,
                color: activeTicket.pColor,
                price: activeTicket.price,
                status: "active",
                closeTime: state.closeTime,
              }}
            />
          </div>
        </Reveal>
      )}

      <Reveal delay={0.16}>
        <div className="mt-5 grid gap-4 sm:grid-cols-3">
          {[
            { href: "/play", icon: Zap, t: "ثبت پیش‌بینی جدید", d: "شش رقم و یک رنگ برای کشش بعدی" },
            { href: "/wallet/deposit", icon: Wallet, t: "شارژ کیف پول", d: `موجودی فعلی ${money(user.balance)} USDT` },
            { href: "/wallet/transactions", icon: History, t: "تاریخچه تراکنش", d: `${TX_FA.deposit}، ${TX_FA.withdraw} و جوایز` },
          ].map((a) => (
            <Link
              key={a.href}
              href={a.href}
              className="surface clip-cyber group flex items-center gap-4 p-4 transition-all hover:border-cyan/35"
            >
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl border border-cyan/25 bg-cyan/10 text-cyan-hot transition-all group-hover:shadow-[0_0_22px_-6px_rgba(34,211,238,0.85)]">
                <a.icon size={19} />
              </span>
              <div className="min-w-0">
                <p className="text-[13.5px] font-bold text-ink">{a.t}</p>
                <p className="mt-0.5 truncate text-[11.5px] text-ink-dim">{a.d}</p>
              </div>
              <ChevronLeft size={16} className="ms-auto shrink-0 text-ink-dim transition-transform group-hover:-translate-x-1" />
            </Link>
          ))}
        </div>
      </Reveal>

      <p className="mt-8 text-center font-mono text-[9.5px] tracking-[0.2em] text-ink-dim/60">
        LAST SYNC · {faDate(new Date())}
      </p>
    </>
  );
}
