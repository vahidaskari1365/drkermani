import { eq, or } from "drizzle-orm";
import { db } from "@/db";
import { users, transactions, notifications } from "@/db/schema";
import { hashPassword, createSession, stableSeed, DEMO_START_BALANCE } from "@/lib/auth";
import { txReference } from "@/lib/utils";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as {
      username?: string;
      email?: string;
      password?: string;
    };
    const username = (body.username ?? "").trim();
    const email = (body.email ?? "").trim().toLowerCase();
    const password = body.password ?? "";

    if (!/^[a-zA-Z0-9_]{3,24}$/.test(username)) {
      return Response.json({ error: "نام کاربری باید ۳ تا ۲۴ کاراکتر انگلیسی، عدد یا _ باشد." }, { status: 400 });
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) {
      return Response.json({ error: "ایمیل معتبر نیست." }, { status: 400 });
    }
    if (password.length < 8) {
      return Response.json({ error: "رمز عبور باید حداقل ۸ کاراکتر باشد." }, { status: 400 });
    }

    const clash = await db
      .select({ id: users.id, email: users.email })
      .from(users)
      .where(or(eq(users.email, email), eq(users.username, username)))
      .limit(1);
    if (clash.length) {
      return Response.json(
        {
          error:
            clash[0].email === email
              ? "این ایمیل قبلاً ثبت شده است."
              : "این نام کاربری قبلاً گرفته شده است.",
        },
        { status: 409 },
      );
    }

    const seed = stableSeed(email + username);
    const created = await db
      .insert(users)
      .values({
        email,
        username,
        passwordHash: hashPassword(password),
        balance: String(DEMO_START_BALANCE),
        avatarSeed: seed % 6,
      })
      .returning();

    const user = created[0];
    await db.insert(transactions).values({
      userId: user.id,
      kind: "deposit",
      amount: String(DEMO_START_BALANCE),
      status: "completed",
      reference: txReference("deposit", seed),
      note: "اعتبار خوش‌آمدگویی BTC6",
      balanceAfter: String(DEMO_START_BALANCE),
    });
    await db.insert(notifications).values({
      userId: user.id,
      kind: "system",
      title: `خوش آمدی ${user.username}!`,
      body: `${DEMO_START_BALANCE} USDT اعتبار نمایشی به کیف پولت اضافه شد. اولین بلیط BTC6 را بخر و شانس خودت را امتحان کن.`,
      href: "/play",
    });

    await createSession(user.id);
    return Response.json({ ok: true, redirect: "/play" });
  } catch {
    return Response.json({ error: "خطای غیرمنتظره در سرور. دوباره تلاش کن." }, { status: 500 });
  }
}
