import { eq, or } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { verifyPassword, createSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { identifier?: string; password?: string };
    const identifier = (body.identifier ?? "").trim().toLowerCase();
    const password = body.password ?? "";
    if (!identifier || !password) {
      return Response.json({ error: "نام کاربری/ایمیل و رمز عبور را وارد کن." }, { status: 400 });
    }
    const rows = await db
      .select()
      .from(users)
      .where(or(eq(users.email, identifier), eq(users.username, identifier)))
      .limit(1);
    if (!rows.length || !verifyPassword(password, rows[0].passwordHash)) {
      return Response.json({ error: "اطلاعات ورود نادرست است." }, { status: 401 });
    }
    await createSession(rows[0].id);
    return Response.json({ ok: true, redirect: "/dashboard" });
  } catch {
    return Response.json({ error: "خطای غیرمنتظره در سرور. دوباره تلاش کن." }, { status: 500 });
  }
}
