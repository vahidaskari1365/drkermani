"use client";

import { useEffect, useRef } from "react";

/**
 * BTC6 ambient scene — present on every page.
 * Pure CSS transforms (GPU friendly), pointer-parallax disabled for
 * reduced-motion users and on touch devices.
 */
export default function CyberBackground() {
  const orbA = useRef<HTMLDivElement>(null);
  const orbB = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const coarse = window.matchMedia("(pointer: coarse)").matches;
    if (reduce || coarse) return;

    let raf = 0;
    let tx = 0;
    let ty = 0;
    let cx = 0;
    let cy = 0;

    const onMove = (e: PointerEvent) => {
      tx = (e.clientX / window.innerWidth - 0.5) * 2;
      ty = (e.clientY / window.innerHeight - 0.5) * 2;
    };
    const loop = () => {
      cx += (tx - cx) * 0.045;
      cy += (ty - cy) * 0.045;
      if (orbA.current) orbA.current.style.transform = `translate3d(${cx * 42}px, ${cy * 34}px, 0)`;
      if (orbB.current) orbB.current.style.transform = `translate3d(${cx * -58}px, ${cy * -40}px, 0)`;
      raf = requestAnimationFrame(loop);
    };
    window.addEventListener("pointermove", onMove, { passive: true });
    raf = requestAnimationFrame(loop);
    return () => {
      window.removeEventListener("pointermove", onMove);
      cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden bg-void">
      {/* base atmosphere */}
      <div className="absolute inset-0 bg-[radial-gradient(120%_80%_at_50%_-10%,#0b1a2e_0%,#050a14_45%,#03050a_100%)]" />

      {/* perspective grid floor */}
      <div className="absolute inset-x-0 bottom-0 h-[62vh] [perspective:520px]">
        <div className="grid-floor absolute inset-0 origin-bottom [transform:rotateX(74deg)_scale(2.6)] opacity-70" />
        <div className="absolute inset-0 bg-gradient-to-t from-void via-void/70 to-transparent" />
      </div>

      {/* vertical hairlines */}
      <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(94,233,255,0.045)_1px,transparent_1px)] bg-[size:220px_100%]" />

      {/* signal orbs — cyan is rationed, orange is a counter-hue */}
      <div
        ref={orbA}
        className="absolute -top-[18vh] right-[6vw] h-[46vw] w-[46vw] max-h-[620px] max-w-[620px] rounded-full bg-[radial-gradient(circle,rgba(34,211,238,0.20)_0%,rgba(34,211,238,0.05)_42%,transparent_70%)] blur-[8px] animate-drift"
      />
      <div
        ref={orbB}
        className="absolute bottom-[-14vh] left-[-8vw] h-[40vw] w-[40vw] max-h-[560px] max-w-[560px] rounded-full bg-[radial-gradient(circle,rgba(247,147,26,0.14)_0%,rgba(247,147,26,0.03)_45%,transparent_70%)] blur-[10px] animate-drift [animation-delay:-9s]"
      />

      {/* scan sweep */}
      <div className="absolute inset-x-0 top-0 h-px animate-scan bg-[linear-gradient(90deg,transparent,rgba(94,233,255,0.55),transparent)]" />

      {/* corner brackets — terminal frame */}
      <svg className="absolute inset-0 h-full w-full opacity-[0.5]" preserveAspectRatio="none">
        <defs>
          <linearGradient id="edge" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="rgba(94,233,255,0.35)" />
            <stop offset="100%" stopColor="rgba(94,233,255,0)" />
          </linearGradient>
        </defs>
        <path d="M0,64 L0,8 Q0,0 8,0 L64,0" fill="none" stroke="url(#edge)" strokeWidth="1" />
        <path d="M0,64 L0,8 Q0,0 8,0 L64,0" fill="none" stroke="url(#edge)" strokeWidth="1" transform="scale(-1,1) translate(-100%,0)" />
        <path d="M0,64 L0,8 Q0,0 8,0 L64,0" fill="none" stroke="url(#edge)" strokeWidth="1" transform="scale(1,-1) translate(0,-100%)" />
        <path d="M0,64 L0,8 Q0,0 8,0 L64,0" fill="none" stroke="url(#edge)" strokeWidth="1" transform="scale(-1,-1) translate(-100%,-100%)" />
      </svg>

      {/* film grain */}
      <div className="noise absolute inset-0" />
    </div>
  );
}
