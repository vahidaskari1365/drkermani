import { eq, sql, and } from "drizzle-orm";
import { db } from "@/db";
import { users, transactions, notifications } from "@/db/schema";
import { currentUser } from "@/lib/auth";
import { txReference, money } from "@/lib/utils";

export const dynamic = "force-dynamic";

async function adjust(
  userId: number,
  delta: number,
  kind: "deposit" | "withdraw",
  note: string,
) {
  const updated = await db
    .update(users)
    .set({ balance: sql`${users.balance} + ${delta}` })
    .where(eq(users.id, userId))
    .returning({ balance: users.balance });
  const tx = await db
    .insert(transactions)
    .values({
      userId,
      kind,
      amount: String(Math.abs(delta)),
      status: "completed",
      reference: txReference(kind, userId + Date.now() % 100000),
      note,
      balanceAfter: updated[0]?.balance ?? null,
    })
    .returning();
  return { balance: updated[0]?.balance, tx: tx[0] };
}

export async function POST(req: Request) {
  const user = await currentUser();
  if (!user) return Response.json({ error: "UNAUTHORIZED" }, { status: 401 });

  try {
    const body = (await req.json()) as {
      action?: string;
      amount?: number;
      address?: string;
    };
    const action = body.action;

    if (action === "deposit") {
      const amount = Number(body.amount);
      if (!Number.isFinite(amount) || amount < 10) {
        return Response.json({ error: "حداقل مبلغ واریز ۱۰ USDT است." }, { status: 400 });
      }
      if (amount > 100000) {
        return Response.json({ error: "حداکثر مبلغ واریز در هر تراکنش ۱۰۰٬۰۰۰ USDT است." }, { status: 400 });
      }
      const res = await adjust(user.id, amount, "deposit", "واریز به کیف پول BTC6");
      await db.insert(notifications).values({
        userId: user.id,
        kind: "wallet",
        title: `واریز ${money(amount)} USDT تأیید شد`,
        body: "موجودی کیف پول تو به‌روزرسانی شد.",
        href: "/wallet/transactions",
      });
      return Response.json({ ok: true, ...res });
    }

    if (action === "withdraw") {
      const amount = Number(body.amount);
      const address = (body.address ?? user.walletAddress ?? "").trim();
      if (!Number.isFinite(amount) || amount < 20) {
        return Response.json({ error: "حداقل مبلغ برداشت ۲۰ USDT است." }, { status: 400 });
      }
      if (Number(user.balance) < amount) {
        return Response.json({ error: "موجودی کافی نیست.", code: "INSUFFICIENT" }, { status: 402 });
      }
      if (address.length < 12) {
        return Response.json({ error: "آدرس کیف پول (TRC20) معتبر نیست." }, { status: 400 });
      }
      await db.update(users).set({ walletAddress: address }).where(eq(users.id, user.id));
      const res = await adjust(user.id, -amount, "withdraw", `برداشت به ${address.slice(0, 10)}…`);
      await db.insert(notifications).values({
        userId: user.id,
        kind: "wallet",
        title: `برداشت ${money(amount)} USDT ثبت شد`,
        body: "درخواست در صف پردازش شبکه قرار گرفت (معمولاً کمتر از ۱۵ دقیقه).",
        href: "/wallet/transactions",
      });
      return Response.json({ ok: true, ...res });
    }

    if (action === "mark-read") {
      if (body.amount === 1) {
        await db
          .update(notifications)
          .set({ isRead: true })
          .where(and(eq(notifications.userId, user.id), eq(notifications.isRead, false)));
      }
      return Response.json({ ok: true });
    }

    return Response.json({ error: "درخواست نامعتبر." }, { status: 400 });
  } catch {
    return Response.json({ error: "خطای غیرمنتظره در کیف پول." }, { status: 500 });
  }
}
