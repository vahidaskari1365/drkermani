"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import {
  Zap, Ticket, RotateCcw, Dices, ChevronUp, ChevronDown, Check,
  AlertCircle, Clock, TrendingUp, ShieldCheck, X, Sparkles,
} from "lucide-react";
import Modal from "@/components/modal";
import DigitalTicket from "@/components/game/digital-ticket";
import { Button, Card, CardTitle, Alert, StatusBadge } from "@/components/ui";
import CandleChart from "@/components/game/candle-chart";
import { PRIZE_TIERS, COLOR_OPTIONS } from "@/lib/game";
import { cn, money } from "@/lib/utils";
import { useMarket, useCountdown } from "@/lib/useLive";
import type { Candle } from "@/lib/market";

type Group = "open" | "high" | "close";
const GROUPS: { key: Group; label: string; fa: string }[] = [
  { key: "open", label: "OPEN", fa: "قیمت بازشدن" },
  { key: "high", label: "HIGH", fa: "بالاترین قیمت" },
  { key: "close", label: "CLOSE", fa: "قیمت بسته‌شدن" },
];

const COLOR_STYLE: Record<string, { cls: string; fa: string }> = {
  GREEN: { cls: "border-win/60 bg-win/15 text-win shadow-[0_0_26px_-8px_rgba(22,227,154,0.9)]", fa: "سبز" },
  RED: { cls: "border-loss/60 bg-loss/15 text-loss shadow-[0_0_26px_-8px_rgba(255,59,92,0.9)]", fa: "قرمز" },
  WHITE: { cls: "border-ink/50 bg-ink/12 text-ink shadow-[0_0_26px_-8px_rgba(233,243,255,0.7)]", fa: "سفید" },
};

export type ActiveTicket = {
  id: number;
  code: string;
  roundNumber: number;
  open: string;
  high: string;
  close: string;
  color: string;
  price: string | number;
  status: string;
  result: { open: string; high: string; close: string; color: string } | null;
  payout?: string | number | null;
} | null;

export default function PlayConsole({
  roundNumber,
  closeTime,
  openTime,
  candles,
  price,
  ticketPrice,
  balance,
  activeTicket,
  lastDraws,
}: {
  roundNumber: number;
  closeTime: string;
  openTime: string;
  candles: Candle[];
  price: number;
  ticketPrice: number;
  balance: string;
  activeTicket: ActiveTicket;
  lastDraws: { roundNumber: number; dOpen: string; dHigh: string; dClose: string; candleColor: string | null }[];
}) {
  const router = useRouter();
  const { market } = useMarket({
    price,
    open: candles.at(-1)?.open ?? price,
    high: candles.at(-1)?.high ?? price,
    low: candles.at(-1)?.low ?? price,
    changePct: 0,
    source: "binance",
    roundNumber,
    openTime,
    closeTime,
    progress: 0,
  });
  const cd = useCountdown(market?.closeTime);

  const [digits, setDigits] = useState<Record<Group, [string, string]>>({
    open: ["", ""],
    high: ["", ""],
    close: ["", ""],
  });
  const [color, setColor] = useState<string>("");
  const [focus, setFocus] = useState<{ group: Group; idx: number } | null>(null);
  const [confirming, setConfirming] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [issued, setIssued] = useState<NonNullable<ActiveTicket> | null>(null);
  const [insufficient, setInsufficient] = useState(false);

  const complete = useMemo(
    () =>
      GROUPS.every((g) => digits[g.key][0] !== "" && digits[g.key][1] !== "") && color !== "",
    [digits, color],
  );

  const locked = !!activeTicket || !!issued;
  const secondsLeft = cd.total / 1000;
  const windowClosed = secondsLeft < 45;
  const canBuy = complete && !locked && !windowClosed;

  const prediction = issued ?? activeTicket;

  function pickDigit(d: string) {
    if (!focus || locked) return;
    setDigits((prev) => {
      const g = prev[focus.group];
      const next: [string, string] = [g[0], g[1]];
      next[focus.idx] = d;
      // auto-advance
      const nextIdx = focus.idx === 0 ? 1 : 0;
      const order: Group[] = ["open", "high", "close"];
      const gi = order.indexOf(focus.group);
      let target = { group: focus.group, idx: nextIdx } as { group: Group; idx: number };
      if (focus.idx === 1) {
        if (gi < 2) target = { group: order[gi + 1], idx: 0 };
        else target = { group: "close", idx: 1 };
      }
      setFocus(target);
      return { ...prev, [focus.group]: next };
    });
  }

  function nudge(group: Group, idx: number, dir: 1 | -1) {
    if (locked) return;
    setFocus({ group, idx });
    setDigits((prev) => {
      const cur = prev[group][idx];
      const n = cur === "" ? (dir === 1 ? 0 : 9) : (Number(cur) + dir + 10) % 10;
      const next: [string, string] = [prev[group][0], prev[group][1]];
      next[idx] = String(n);
      return { ...prev, [group]: next };
    });
  }

  function randomize() {
    if (locked) return;
    const r = () => String(Math.floor(Math.random() * 10));
    setDigits({
      open: [r(), r()],
      high: [r(), r()],
      close: [r(), r()],
    });
    setColor(COLOR_OPTIONS[Math.floor(Math.random() * COLOR_OPTIONS.length)]);
    setError("");
  }

  function reset() {
    if (locked) return;
    setDigits({ open: ["", ""], high: ["", ""], close: ["", ""] });
    setColor("");
    setFocus(null);
    setError("");
  }

  async function buy() {
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/tickets", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          pOpen: digits.open.join(""),
          pHigh: digits.high.join(""),
          pClose: digits.close.join(""),
          pColor: color,
        }),
      });
      const json = (await res.json()) as {
        error?: string;
        code?: string;
        ticket?: { id: number; code: string; roundNumber: number; price: number };
      };
      if (!res.ok) {
        if (json.code === "INSUFFICIENT") setInsufficient(true);
        setError(json.error ?? "خطا در ثبت بلیط.");
        setConfirming(false);
        return;
      }
      setIssued({
        id: json.ticket!.id,
        code: json.ticket!.code,
        roundNumber: json.ticket!.roundNumber,
        open: digits.open.join(""),
        high: digits.high.join(""),
        close: digits.close.join(""),
        color,
        price: json.ticket!.price,
        status: "active",
        result: null,
      });
      setConfirming(false);
      router.refresh();
    } catch {
      setError("ارتباط با سرور برقرار نشد.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      {/* ================= HEADER ================= */}
      <div className="mb-5 flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="mb-2 flex items-center gap-2 font-mono text-[10px] tracking-[0.3em] text-cyan/80">
            <span className="h-px w-6 bg-cyan/50" />
            PLAY · BUY TICKET
          </div>
          <h1 className="text-2xl font-extrabold text-ink sm:text-[30px]">پیش‌بینی کندل بعدی</h1>
          <p className="mt-2 text-[13px] text-ink-dim">
            دو رقم آخر OPEN و HIGH و CLOSE و رنگ کندل یک‌ساعته BTC/USDT را انتخاب کن.
          </p>
        </div>
        <div className="flex items-center gap-2.5">
          <span className="clip-notch border border-cyan/30 bg-cyan/10 px-3 py-2 font-mono text-[10px] tracking-[0.16em] text-cyan-hot" dir="ltr">
            ROUND #{market?.roundNumber ?? roundNumber}
          </span>
          <StatusBadge status={windowClosed ? "pending" : "live"} label={windowClosed ? "قفل فروش" : "در حال تشکیل"} />
        </div>
      </div>

      <div className="grid gap-5 xl:grid-cols-[1.3fr_1fr]">
        {/* ================= LEFT: CONSOLE ================= */}
        <div className="space-y-5">
          {/* live strip */}
          <Card className="p-4 sm:p-5">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <span className="h-2 w-2 animate-pulse rounded-full bg-win" />
                <span className="font-mono text-[10px] tracking-[0.18em] text-ink-soft">BTC/USDT · 1H</span>
                <span className="font-num text-[19px] font-bold text-ink text-glow-cyan" dir="ltr">
                  {market ? money(market.price) : "—"}
                </span>
                <span
                  className={cn(
                    "font-num text-[12px] font-bold",
                    (market?.changePct ?? 0) >= 0 ? "text-win" : "text-loss",
                  )}
                  dir="ltr"
                >
                  {market ? `${market.changePct >= 0 ? "▲" : "▼"} ${Math.abs(market.changePct).toFixed(2)}%` : "—"}
                </span>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-left">
                  <p className="font-mono text-[8.5px] tracking-[0.2em] text-ink-dim">TIME LEFT</p>
                  <p className="font-num text-[22px] font-bold leading-none text-cyan-hot" dir="ltr">
                    {cd.hours}:{cd.minutes}:{cd.seconds}
                  </p>
                </div>
                <div className="relative h-12 w-12">
                  <svg viewBox="0 0 40 40" className="h-12 w-12 -rotate-90">
                    <circle cx="20" cy="20" r="17" fill="none" stroke="rgba(94,233,255,0.12)" strokeWidth="3" />
                    <circle
                      cx="20" cy="20" r="17" fill="none" stroke="#5fe9ff" strokeWidth="3" strokeLinecap="round"
                      strokeDasharray={`${Math.round((market?.progress ?? 0) * 107)} 107`}
                    />
                  </svg>
                </div>
              </div>
            </div>
            <div className="mt-3 grid grid-cols-3 gap-2.5 border-t border-hairline pt-3">
              {[
                ["OPEN", market ? money(market.open) : "—"],
                ["HIGH", market ? money(market.high) : "—"],
                ["LOW", market ? money(market.low) : "—"],
              ].map(([l, v]) => (
                <div key={l} className="rounded-lg border border-hairline bg-void/40 px-3 py-2">
                  <p className="font-mono text-[8.5px] tracking-[0.18em] text-ink-dim">{l}</p>
                  <p className="mt-0.5 font-num text-[12.5px] font-bold text-ink-soft" dir="ltr">{v}</p>
                </div>
              ))}
            </div>
          </Card>

          {/* the console */}
          <Card className={cn("relative p-5 sm:p-6", locked && "opacity-95")} glow={complete && !locked ? "cyan" : undefined}>
            <div className="mb-5 flex flex-wrap items-center justify-between gap-3 border-b border-hairline pb-4">
              <div className="flex items-center gap-3">
                <span className="grid h-9 w-9 place-items-center rounded-lg border border-cyan/25 bg-cyan/10 text-cyan-hot">
                  <Ticket size={16} />
                </span>
                <div>
                  <p className="font-mono text-[9px] tracking-[0.26em] text-cyan/80">PREDICTION CONSOLE</p>
                  <p className="text-[14px] font-bold text-ink">شش رقم و یک رنگ</p>
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="subtle" size="sm" onClick={randomize} disabled={locked}>
                  <Dices size={14} />
                  تصادفی
                </Button>
                <Button variant="subtle" size="sm" onClick={reset} disabled={locked}>
                  <RotateCcw size={14} />
                  پاک‌کردن
                </Button>
              </div>
            </div>

            {locked ? (
              <div className="space-y-4">
                <Alert tone="success" title="پیش‌بینی این کشش ثبت شده است">
                  بلیط فعال شما برای کشش #{prediction?.roundNumber} در انتظار نتیجه است. با بسته‌شدن کندل،
                  نتیجه اینجا نمایش داده می‌شود.
                </Alert>
                {prediction && (
                  <DigitalTicket
                    ticket={{
                      ...prediction,
                      result: prediction.result ?? null,
                    }}
                  />
                )}
                <div className="flex flex-wrap gap-3">
                  <Link
                    href={`/tickets/${prediction?.id}`}
                    className="clip-notch inline-flex h-11 items-center gap-2 border border-cyan/35 bg-cyan/10 px-5 text-[13px] font-semibold text-cyan-hot transition-colors hover:bg-cyan/20"
                  >
                    مشاهده بلیط
                    <Ticket size={15} />
                  </Link>
                  <Button variant="ghost" size="lg" onClick={() => router.refresh()}>
                    بروزرسانی وضعیت
                  </Button>
                </div>
              </div>
            ) : (
              <>
                <div className="grid gap-5 sm:grid-cols-3">
                  {GROUPS.map((g) => (
                    <div key={g.key}>
                      <div className="mb-3 flex items-center justify-between">
                        <div>
                          <p className="font-mono text-[10px] tracking-[0.24em] text-cyan/85">{g.label}</p>
                          <p className="text-[11px] text-ink-dim">{g.fa}</p>
                        </div>
                        <span
                          className={cn(
                            "font-mono text-[9px] tracking-[0.16em]",
                            digits[g.key][0] && digits[g.key][1] ? "text-win" : "text-ink-dim/60",
                          )}
                        >
                          {digits[g.key][0] && digits[g.key][1] ? "READY" : "···"}
                        </span>
                      </div>
                      <div className="flex gap-2.5">
                        {[0, 1].map((idx) => {
                          const isFocus = focus?.group === g.key && focus.idx === idx;
                          const val = digits[g.key][idx];
                          return (
                            <div key={idx} className="flex-1">
                              <motion.button
                                whileTap={{ scale: 0.94 }}
                                onClick={() => setFocus({ group: g.key, idx })}
                                aria-label={`${g.label} رقم ${idx + 1}`}
                                className={cn(
                                  "relative grid h-[74px] w-full place-items-center rounded-xl border font-num text-[30px] font-bold transition-all",
                                  isFocus
                                    ? "border-cyan-hot bg-cyan/14 text-cyan-hot shadow-[0_0_30px_-6px_rgba(34,211,238,0.9)]"
                                    : val
                                      ? "border-cyan/30 bg-deep/70 text-ink"
                                      : "border-hairline bg-abyss/70 text-ink-dim",
                                )}
                              >
                                {val || "·"}
                                {isFocus && (
                                  <motion.span
                                    layoutId="cursor"
                                    className="absolute bottom-2.5 h-0.5 w-6 rounded-full bg-cyan-hot"
                                  />
                                )}
                              </motion.button>
                              <div className="mt-1.5 flex gap-1.5">
                                <button
                                  onClick={() => nudge(g.key, idx, 1)}
                                  aria-label={`افزایش رقم ${idx + 1} ${g.label}`}
                                  className="grid h-7 flex-1 place-items-center rounded-md border border-hairline bg-raised/60 text-ink-dim transition-colors hover:border-cyan/40 hover:text-cyan-hot"
                                >
                                  <ChevronUp size={13} />
                                </button>
                                <button
                                  onClick={() => nudge(g.key, idx, -1)}
                                  aria-label={`کاهش رقم ${idx + 1} ${g.label}`}
                                  className="grid h-7 flex-1 place-items-center rounded-md border border-hairline bg-raised/60 text-ink-dim transition-colors hover:border-cyan/40 hover:text-cyan-hot"
                                >
                                  <ChevronDown size={13} />
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>

                {/* color */}
                <div className="mt-6">
                  <div className="mb-3 flex items-center justify-between">
                    <div>
                      <p className="font-mono text-[10px] tracking-[0.24em] text-cyan/85">COLOR</p>
                      <p className="text-[11px] text-ink-dim">رنگ کندل یک‌ساعته</p>
                    </div>
                    <span className="font-mono text-[9px] tracking-[0.16em] text-ink-dim/60">
                      {color ? "SELECTED" : "···"}
                    </span>
                  </div>
                  <div className="grid grid-cols-3 gap-2.5">
                    {COLOR_OPTIONS.map((c) => {
                      const active = color === c;
                      const st = COLOR_STYLE[c];
                      return (
                        <motion.button
                          key={c}
                          whileTap={{ scale: 0.97 }}
                          onClick={() => setColor(c)}
                          aria-pressed={active}
                          className={cn(
                            "flex h-14 items-center justify-center gap-2 rounded-xl border font-mono text-[11.5px] font-bold tracking-wider transition-all",
                            active ? st.cls : "border-hairline bg-abyss/70 text-ink-dim hover:border-hairline-strong",
                          )}
                          dir="ltr"
                        >
                          <span className="h-2 w-2 rounded-full bg-current" />
                          {c}
                          <span className="text-[10px] opacity-70">{st.fa}</span>
                        </motion.button>
                      );
                    })}
                  </div>
                </div>

                {/* digit pad */}
                <AnimatePresence>
                  {focus && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: 0.28 }}
                      className="overflow-hidden"
                    >
                      <div className="mt-5 clip-notch border border-hairline bg-void/50 p-3">
                        <div className="mb-2.5 flex items-center justify-between">
                          <span className="font-mono text-[9.5px] tracking-[0.2em] text-cyan/80">
                            {focus.group.toUpperCase()} · DIGIT {focus.idx + 1}
                          </span>
                          <button
                            onClick={() => setFocus(null)}
                            className="grid h-6 w-6 place-items-center rounded-md text-ink-dim hover:text-loss"
                            aria-label="بستن"
                          >
                            <X size={13} />
                          </button>
                        </div>
                        <div className="grid grid-cols-10 gap-1.5 sm:gap-2">
                          {Array.from({ length: 10 }, (_, d) => (
                            <button
                              key={d}
                              onClick={() => pickDigit(String(d))}
                              className="grid h-10 place-items-center rounded-lg border border-hairline bg-deep/70 font-num text-[15px] font-bold text-ink-soft transition-all hover:border-cyan-hot hover:bg-cyan/12 hover:text-cyan-hot"
                            >
                              {d}
                            </button>
                          ))}
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {error && (
                  <div role="alert" className="mt-5 clip-notch flex items-start gap-2.5 border border-loss/40 bg-loss/10 px-3.5 py-3 text-[12px] text-loss">
                    <AlertCircle size={15} className="mt-0.5 shrink-0" />
                    {error}
                  </div>
                )}

                {windowClosed && (
                  <div className="mt-5">
                    <Alert tone="warn" title="ثبت بلیط برای این کشش بسته است">
                      کمتر از ۴۵ ثانیه به پایان کندل باقی مانده. تا باز‌شدن کشش بعدی صبر کن.
                    </Alert>
                  </div>
                )}

                {/* summary */}
                <div className="mt-6 flex flex-wrap items-center justify-between gap-4 border-t border-hairline pt-5">
                  <div className="flex flex-wrap items-center gap-6">
                    <div>
                      <p className="font-mono text-[8.5px] tracking-[0.2em] text-ink-dim">TICKET PRICE</p>
                      <p className="mt-1 font-num text-[20px] font-bold text-orange-soft" dir="ltr">
                        {money(ticketPrice)} <span className="text-[10px]">USDT</span>
                      </p>
                    </div>
                    <div>
                      <p className="font-mono text-[8.5px] tracking-[0.2em] text-ink-dim">MAX PRIZE</p>
                      <p className="mt-1 font-num text-[20px] font-bold text-win" dir="ltr">
                        {money(ticketPrice * 1000)} <span className="text-[10px]">USDT</span>
                      </p>
                    </div>
                    <div>
                      <p className="font-mono text-[8.5px] tracking-[0.2em] text-ink-dim">BALANCE</p>
                      <p className="mt-1 font-num text-[16px] font-bold text-ink" dir="ltr">
                        {money(balance)}
                      </p>
                    </div>
                  </div>
                  <Button
                    size="xl"
                    disabled={!canBuy}
                    onClick={() => setConfirming(true)}
                    className="min-w-[210px]"
                  >
                    <Zap size={17} />
                    تأیید پیش‌بینی
                  </Button>
                </div>
                {!complete && !locked && (
                  <p className="mt-3 font-mono text-[9.5px] tracking-[0.16em] text-ink-dim/70">
                    برای فعال‌شدن دکمه، هر شش رقم و رنگ را انتخاب کن.
                  </p>
                )}
              </>
            )}
          </Card>

          {/* issued ticket success */}
          <AnimatePresence>
            {issued && (
              <motion.div
                initial={{ opacity: 0, y: 30, scale: 0.97 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
              >
                <Card className="p-5 sm:p-6" glow="win">
                  <div className="mb-4 flex items-center gap-3">
                    <motion.span
                      initial={{ scale: 0, rotate: -40 }}
                      animate={{ scale: 1, rotate: 0 }}
                      transition={{ type: "spring", stiffness: 260, damping: 16 }}
                      className="grid h-11 w-11 place-items-center rounded-full border border-win/50 bg-win/15 text-win"
                    >
                      <Check size={20} />
                    </motion.span>
                    <div>
                      <p className="font-mono text-[9.5px] tracking-[0.26em] text-win">TICKET ISSUED</p>
                      <p className="text-[15px] font-extrabold text-ink">بلیط دیجیتال تو صادر شد</p>
                    </div>
                  </div>
                  <DigitalTicket ticket={issued} />
                  <p className="mt-4 flex items-center gap-2 text-[12px] text-ink-dim">
                    <Clock size={13} className="shrink-0 text-cyan/70" />
                    نتیجه این بلیط با بسته‌شدن کندل یک‌ساعته مشخص می‌شود.
                  </p>
                </Card>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* ================= RIGHT: CONTEXT ================= */}
        <div className="space-y-5">
          <Card className="p-4 sm:p-5">
            <CardTitle kicker="LIVE CHART" icon={<TrendingUp size={16} />}>
              کندل‌های اخیر
            </CardTitle>
            <CandleChart candles={candles.slice(-36)} height={190} />
          </Card>

          <Card className="p-4 sm:p-5">
            <CardTitle kicker="LAST DRAWS" icon={<Clock size={16} />}>
              کشش‌های گذشته
            </CardTitle>
            <div className="space-y-2">
              {lastDraws.slice(0, 5).map((d) => (
                <div key={d.roundNumber} className="flex items-center justify-between rounded-lg border border-hairline bg-void/40 px-3 py-2.5">
                  <span className="font-num text-[11px] text-ink-dim" dir="ltr">#{d.roundNumber}</span>
                  <span className="font-num text-[13px] font-bold text-cyan-hot" dir="ltr">
                    {d.dOpen}·{d.dHigh}·{d.dClose}
                  </span>
                  <span
                    className={cn(
                      "font-mono text-[10px] font-bold",
                      d.candleColor === "GREEN" ? "text-win" : d.candleColor === "RED" ? "text-loss" : "text-ink-soft",
                    )}
                    dir="ltr"
                  >
                    {d.candleColor ?? "—"}
                  </span>
                </div>
              ))}
              {!lastDraws.length && (
                <p className="py-6 text-center text-[12px] text-ink-dim">هنوز کششی ثبت نشده است.</p>
              )}
            </div>
          </Card>

          <Card className="p-4 sm:p-5">
            <CardTitle kicker="PAYOUT" icon={<Sparkles size={16} />}>
              جدول جوایز
            </CardTitle>
            <div className="space-y-1.5">
              {PRIZE_TIERS.map((t, i) => (
                <div
                  key={t.key}
                  className="flex items-center justify-between rounded-lg px-2.5 py-2 transition-colors hover:bg-cyan/6"
                >
                  <span className="text-[12px] text-ink-soft">
                    {t.digits}
                    {t.color ? " + رنگ" : ""}
                  </span>
                  <span
                    className={cn(
                      "font-num text-[13px] font-bold",
                      i === 0 ? "text-win" : i === 1 ? "text-cyan-hot" : "text-ink",
                    )}
                    dir="ltr"
                  >
                    ×{t.multiplier}
                  </span>
                </div>
              ))}
            </div>
            <Link
              href="/rules"
              className="mt-3 flex items-center gap-1.5 border-t border-hairline pt-3 font-mono text-[10px] text-cyan-hot hover:text-ink"
            >
              قوانین کامل
            </Link>
          </Card>

          <Card className="p-4 sm:p-5">
            <div className="flex items-start gap-3">
              <ShieldCheck size={18} className="mt-0.5 shrink-0 text-cyan/70" />
              <p className="text-[12px] leading-[1.9] text-ink-dim">
                نتیجه هر کشش مستقیماً از کندل واقعی BTC/USDT استخراج می‌شود و پس از ثبت، پیش‌بینی قابل تغییر
                نیست. هیچ عدد تصادفی در کار نیست.
              </p>
            </div>
          </Card>
        </div>
      </div>

      {/* ================= CONFIRM MODAL ================= */}
      <Modal
        open={confirming}
        onClose={() => setConfirming(false)}
        kicker="CONFIRM PREDICTION"
        title="تأیید پیش‌بینی و خرید بلیط"
        size="md"
        footer={
          <>
            <Button variant="ghost" size="lg" onClick={() => setConfirming(false)} disabled={loading}>
              انصراف
            </Button>
            <Button variant="success" size="lg" onClick={buy} loading={loading} disabled={loading}>
              <Check size={16} />
              خرید و صدور بلیط
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <div className="clip-notch border border-cyan/25 bg-cyan/6 p-4">
            <div className="grid grid-cols-3 gap-3">
              {GROUPS.map((g) => (
                <div key={g.key}>
                  <p className="mb-1.5 font-mono text-[9px] tracking-[0.2em] text-ink-dim">{g.label}</p>
                  <div className="flex gap-1.5" dir="ltr">
                    {[0, 1].map((i) => (
                      <span
                        key={i}
                        className="grid h-10 w-8 place-items-center rounded-md border border-cyan/35 bg-cyan/12 font-num text-[17px] font-bold text-cyan-hot"
                      >
                        {digits[g.key][i] || "·"}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-3 flex items-center justify-between border-t border-hairline pt-3">
              <span className="font-mono text-[9px] tracking-[0.2em] text-ink-dim">COLOR</span>
              <span
                className={cn(
                  "font-mono text-[12px] font-bold",
                  color === "GREEN" ? "text-win" : color === "RED" ? "text-loss" : "text-ink",
                )}
                dir="ltr"
              >
                {color}
              </span>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-[12.5px] text-ink-soft">مبلغ بلیط</span>
            <span className="font-num text-[15px] font-bold text-orange-soft" dir="ltr">
              {money(ticketPrice)} USDT
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-[12.5px] text-ink-soft">موجودی پس از خرید</span>
            <span className="font-num text-[13px] text-ink" dir="ltr">
              {money(Math.max(0, Number(balance) - ticketPrice))} USDT
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-[12.5px] text-ink-soft">بیشترین جایزه ممکن</span>
            <span className="font-num text-[13px] font-bold text-win" dir="ltr">
              {money(ticketPrice * 1000)} USDT
            </span>
          </div>

          <div className="border-t border-hairline pt-3">
            <p className="flex items-start gap-2 text-[11.5px] leading-relaxed text-ink-dim">
              <AlertCircle size={13} className="mt-0.5 shrink-0 text-orange-soft" />
              با تأیید، پیش‌بینی قفل می‌شود و قابل تغییر یا حذف نیست. نتیجه با بسته‌شدن کندل
              {" "}#{market?.roundNumber ?? roundNumber} مشخص می‌شود.
            </p>
          </div>
        </div>
      </Modal>

      {/* insufficient balance */}
      <Modal
        open={insufficient}
        onClose={() => setInsufficient(false)}
        kicker="WALLET"
        title="موجودی کافی نیست"
        size="sm"
        footer={
          <>
            <Button variant="ghost" size="md" onClick={() => setInsufficient(false)}>
              بعداً
            </Button>
            <Link
              href="/wallet/deposit"
              className="clip-notch inline-flex h-11 items-center gap-2 bg-gradient-to-b from-cyan-hot to-cyan px-5 text-[13px] font-bold text-void"
            >
              واریز
            </Link>
          </>
        }
      >
        برای خرید این بلیط به {money(ticketPrice)} USDT موجودی نیاز داری. کیف پول خود را شارژ کن.
      </Modal>
    </>
  );
}
