"use client";

import { useMemo } from "react";
import type { Candle } from "@/lib/market";
import { cn } from "@/lib/utils";

export default function CandleChart({
  candles,
  className,
  height = 220,
  animate = true,
}: {
  candles: Candle[];
  className?: string;
  height?: number;
  animate?: boolean;
}) {
  const view = useMemo(() => {
    if (!candles.length) return null;
    const w = 1000;
    const pad = 12;
    const highs = Math.max(...candles.map((c) => c.high));
    const lows = Math.min(...candles.map((c) => c.low));
    const span = Math.max(1, highs - lows);
    const step = (w - pad * 2) / candles.length;
    const body = step * 0.52;
    const y = (v: number) => pad + (1 - (v - lows) / span) * (height - pad * 2);
    const items = candles.map((c, i) => {
      const x = pad + i * step + step / 2;
      const up = c.close >= c.open;
      return {
        x,
        up,
        body,
        yHigh: y(c.high),
        yLow: y(c.low),
        yOpen: y(c.open),
        yClose: y(c.close),
        last: i === candles.length - 1,
        price: c.close,
      };
    });
    const line = items.map((it, i) => `${i === 0 ? "M" : "L"}${it.x.toFixed(1)},${it.yClose.toFixed(1)}`).join(" ");
    return { items, line, w, step };
  }, [candles, height]);

  if (!view) return <div className={cn("h-[220px] animate-pulse rounded-xl bg-raised/40", className)} />;

  return (
    <svg
      viewBox={`0 0 1000 ${height}`}
      className={cn("w-full", className)}
      preserveAspectRatio="none"
      role="img"
      aria-label="نمودار کندل یک‌ساعته بیت‌کوین"
    >
      <defs>
        <linearGradient id="areaFade" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="rgba(34,211,238,0.22)" />
          <stop offset="100%" stopColor="rgba(34,211,238,0)" />
        </linearGradient>
      </defs>

      {[0.25, 0.5, 0.75].map((p) => (
        <line
          key={p}
          x1="0"
          x2="1000"
          y1={height * p}
          y2={height * p}
          stroke="rgba(94,233,255,0.07)"
          strokeDasharray="3 7"
        />
      ))}

      <path d={`${view.line} L1000,${height} L0,${height} Z`} fill="url(#areaFade)" opacity="0.6" />

      {view.items.map((it, i) => {
        const color = it.last ? "#5fe9ff" : it.up ? "#16e39a" : "#ff3b5c";
        const top = Math.min(it.yOpen, it.yClose);
        const h = Math.max(2, Math.abs(it.yClose - it.yOpen));
        return (
          <g key={i} opacity={it.last ? 1 : 0.85}>
            <line
              x1={it.x}
              x2={it.x}
              y1={it.yHigh}
              y2={it.yLow}
              stroke={color}
              strokeWidth={it.last ? 1.6 : 1}
              opacity={0.55}
              strokeDasharray={animate && it.last ? "4 4" : undefined}
              className={animate && it.last ? "[animation:dashFlow_6s_linear_infinite]" : undefined}
            />
            <rect
              x={it.x - it.body / 2}
              y={top}
              width={it.body}
              height={h}
              rx="1.5"
              fill={it.up ? "rgba(22,227,154,0.28)" : "rgba(255,59,92,0.28)"}
              stroke={color}
              strokeWidth={it.last ? 1.5 : 0.9}
              style={
                animate
                  ? { transformOrigin: `${it.x}px ${top + h / 2}px`, animation: `riseIn .5s ${i * 0.014}s both` }
                  : undefined
              }
            />
          </g>
        );
      })}

      <line
        x1="0"
        x2="1000"
        y1={view.items[view.items.length - 1].yClose}
        y2={view.items[view.items.length - 1].yClose}
        stroke="rgba(94,233,255,0.5)"
        strokeWidth="1"
        strokeDasharray="6 6"
      />
    </svg>
  );
}
