"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { CheckCheck } from "lucide-react";
import { Button } from "@/components/ui";

export default function MarkAllRead({ count }: { count: number }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  return (
    <Button
      variant="outline"
      size="md"
      loading={loading}
      disabled={loading}
      onClick={async () => {
        setLoading(true);
        await fetch("/api/notifications", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ all: true }),
        });
        router.refresh();
        setLoading(false);
      }}
    >
      <CheckCheck size={15} />
      خواندن همه ({count})
    </Button>
  );
}
