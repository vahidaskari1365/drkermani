import type { Metadata } from "next";
import { requireUser } from "@/lib/auth";
import { PageHeading, Alert } from "@/components/ui";
import Reveal from "@/components/reveal";
import { WithdrawForm } from "@/components/wallet-forms";
import { Clock } from "lucide-react";

export const metadata: Metadata = { title: "برداشت" };
export const dynamic = "force-dynamic";

export default async function WithdrawPage() {
  const user = await requireUser();
  return (
    <>
      <PageHeading kicker="WALLET / WITHDRAW" title="برداشت از کیف پول" desc="برداشت تتر روی شبکه TRC20 به کیف پول دلخواه تو." />
      <Reveal>
        <WithdrawForm balance={user.balance} address={user.walletAddress} />
      </Reveal>
      <Reveal delay={0.08}>
        <div className="mt-5">
          <Alert tone="warn" title="زمان پردازش">
            <span className="flex items-start gap-2">
              <Clock size={14} className="mt-0.5 shrink-0" />
              درخواست‌های برداشت معمولاً در کمتر از ۱۵ دقیقه پردازش می‌شوند. برای مبالغ بالا ممکن است بررسی
              امنیتی اضافه انجام شود.
            </span>
          </Alert>
        </div>
      </Reveal>
    </>
  );
}
