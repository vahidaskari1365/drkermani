"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Trophy, XCircle, Clock, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui";
import { cn, money } from "@/lib/utils";

const COLS = [
  { key: "open", label: "OPEN" },
  { key: "high", label: "HIGH" },
  { key: "close", label: "CLOSE" },
] as const;

/** Cinematic result reveal — scan, decode, verdict. No confetti, no slot machine. */
export default function TicketResult({
  status,
  prediction,
  result,
  payout,
  matches,
  colorMatch,
}: {
  status: string;
  prediction: { open: string; high: string; close: string; color: string };
  result: { open: string; high: string; close: string; color: string } | null;
  payout: number;
  matches: number | null;
  colorMatch: boolean;
}) {
  const [phase, setPhase] = useState<"scanning" | "decoded" | "verdict">(status === "active" ? "scanning" : "verdict");

  useEffect(() => {
    if (status === "active") {
      const id = window.setInterval(() => setPhase("scanning"), 100);
      return () => window.clearInterval(id);
    }
    const t1 = window.setTimeout(() => setPhase("decoded"), 200);
    const t2 = window.setTimeout(() => setPhase("verdict"), 1400);
    return () => {
      window.clearTimeout(t1);
      window.clearTimeout(t2);
    };
  }, [status]);

  if (status === "active") {
    return (
      <div className="clip-cyber relative overflow-hidden border border-cyan/25 bg-[linear-gradient(135deg,#0a1424,#060b14)] p-6">
        <motion.span
          aria-hidden
          className="absolute inset-y-0 w-24 bg-[linear-gradient(90deg,transparent,rgba(94,233,255,0.14),transparent)]"
          animate={{ x: ["-20%", "420%"] }}
          transition={{ duration: 2.6, repeat: Infinity, ease: "linear" }}
        />
        <div className="relative flex items-center gap-4">
          <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl border border-cyan/30 bg-cyan/10 text-cyan-hot">
            <Clock size={20} />
          </span>
          <div>
            <p className="font-mono text-[9.5px] tracking-[0.26em] text-cyan/80">AWAITING CANDLE CLOSE</p>
            <p className="mt-1 text-[15px] font-extrabold text-ink">در انتظار کشش</p>
            <p className="mt-1 text-[12px] text-ink-dim">
              با بسته‌شدن کندل یک‌ساعته، نتیجه این بلیط به‌صورت خودکار محاسبه می‌شود.
            </p>
          </div>
        </div>
        <div className="relative mt-5 grid grid-cols-3 gap-3">
          {COLS.map((c) => (
            <div key={c.key} className="clip-notch border border-hairline bg-void/50 p-3">
              <p className="font-mono text-[9px] tracking-[0.2em] text-ink-dim">{c.label}</p>
              <p className="mt-1.5 font-num text-[17px] font-bold text-ink-dim" dir="ltr">
                {prediction[c.key]}
              </p>
            </div>
          ))}
        </div>
      </div>
    );
  }

  const won = status === "won";

  return (
    <div
      className={cn(
        "clip-cyber relative overflow-hidden border p-6",
        won
          ? "border-win/45 bg-[linear-gradient(135deg,#04150f,#050a14)] glow-win"
          : "border-loss/30 bg-[linear-gradient(135deg,#170609,#050a14)]",
      )}
    >
      {won && (
        <motion.div
          aria-hidden
          className="pointer-events-none absolute inset-0"
          animate={{ opacity: [0.25, 0.55, 0.25] }}
          transition={{ duration: 3, repeat: Infinity }}
          style={{
            background:
              "radial-gradient(70% 55% at 50% 0%, rgba(22,227,154,0.18), transparent 70%)",
          }}
        />
      )}
      <motion.span
        aria-hidden
        className="absolute inset-x-0 top-0 h-px"
        style={{ background: won ? "rgba(22,227,154,0.7)" : "rgba(255,59,92,0.5)" }}
        animate={{ opacity: [0.2, 1, 0.2] }}
        transition={{ duration: 2.2, repeat: Infinity }}
      />

      <div className="relative flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <motion.span
            initial={{ scale: 0.5, rotate: -25, opacity: 0 }}
            animate={{ scale: 1, rotate: 0, opacity: 1 }}
            transition={{ type: "spring", stiffness: 240, damping: 15, delay: phase === "verdict" ? 0 : 1.4 }}
            className={cn(
              "grid h-12 w-12 place-items-center rounded-xl border",
              won ? "border-win/50 bg-win/15 text-win" : "border-loss/40 bg-loss/12 text-loss",
            )}
          >
            {won ? <Trophy size={21} /> : <XCircle size={21} />}
          </motion.span>
          <div>
            <p
              className={cn(
                "font-mono text-[9.5px] tracking-[0.26em]",
                won ? "text-win/90" : "text-loss/80",
              )}
            >
              {won ? "CYBER VICTORY" : "NO MATCH"}
            </p>
            <p className={cn("mt-1 text-[19px] font-black", won ? "text-win" : "text-ink")}>
              {won ? "بلیط برنده شد!" : "این بلیط برنده نشد"}
            </p>
          </div>
        </div>

        <div className="text-left">
          <p className="font-mono text-[9px] tracking-[0.2em] text-ink-dim">PRIZE</p>
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.5 }}
            className={cn("font-num text-[26px] font-bold", won ? "text-win" : "text-loss/60")}
            dir="ltr"
          >
            {won ? `+${money(payout)}` : "0.00"} <span className="text-[11px]">USDT</span>
          </motion.p>
        </div>
      </div>

      {/* decode grid */}
      <div className="relative mt-6 grid gap-3 sm:grid-cols-3">
        {COLS.map((c, ci) => (
          <div key={c.key} className="clip-notch border border-hairline bg-void/50 p-3.5">
            <p className="mb-2.5 font-mono text-[9px] tracking-[0.2em] text-ink-dim">{c.label}</p>
            <div className="flex items-end justify-between gap-2">
              <div className="flex gap-1.5" dir="ltr">
                {[0, 1].map((i) => {
                  const p = prediction[c.key][i];
                  const r = result?.[c.key][i] ?? "?";
                  const hit = p === r;
                  return (
                    <div key={i} className="flex flex-col items-center gap-1">
                      <span className="font-mono text-[8px] text-ink-dim">P</span>
                      <span className="grid h-8 w-7 place-items-center rounded border border-cyan/25 bg-cyan/8 font-num text-[13px] font-bold text-cyan-hot">
                        {p}
                      </span>
                    </div>
                  );
                })}
              </div>
              <span className="font-mono text-[10px] text-ink-dim">→</span>
              <div className="flex gap-1.5" dir="ltr">
                {[0, 1].map((i) => {
                  const p = prediction[c.key][i];
                  const r = result?.[c.key][i] ?? "?";
                  const hit = p === r;
                  return (
                    <motion.span
                      key={i}
                      initial={{ opacity: 0, scale: 0.6, filter: "blur(6px)" }}
                      animate={
                        phase === "scanning"
                          ? { opacity: 0.3, scale: 0.9, filter: "blur(4px)" }
                          : { opacity: 1, scale: 1, filter: "blur(0px)" }
                      }
                      transition={{ delay: phase === "scanning" ? 0 : 0.15 + ci * 0.12 + i * 0.06 }}
                      className={cn(
                        "grid h-8 w-7 place-items-center rounded border font-num text-[13px] font-bold",
                        phase === "scanning"
                          ? "border-hairline text-ink-dim"
                          : hit
                            ? "border-win/60 bg-win/18 text-win shadow-[0_0_16px_-4px_rgba(22,227,154,0.85)]"
                            : "border-loss/35 bg-loss/10 text-loss/80",
                      )}
                    >
                      {phase === "scanning" ? "?" : r}
                    </motion.span>
                  );
                })}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="relative mt-3 grid gap-3 sm:grid-cols-2">
        <div className="clip-notch flex items-center justify-between border border-hairline bg-void/50 px-3.5 py-3">
          <span className="font-mono text-[9px] tracking-[0.2em] text-ink-dim">COLOR</span>
          <span className="flex items-center gap-2 font-mono text-[11.5px] font-bold" dir="ltr">
            <span
              className={cn(
                "rounded px-1.5 py-0.5",
                prediction.color === "GREEN"
                  ? "bg-win/15 text-win"
                  : prediction.color === "RED"
                    ? "bg-loss/15 text-loss"
                    : "bg-ink/10 text-ink",
              )}
            >
              {prediction.color}
            </span>
            <span className="text-ink-dim">→</span>
            <span
              className={cn(
                "rounded px-1.5 py-0.5",
                result?.color === "GREEN"
                  ? "bg-win/15 text-win"
                  : result?.color === "RED"
                    ? "bg-loss/15 text-loss"
                    : "bg-ink/10 text-ink",
              )}
            >
              {result?.color ?? "?"}
            </span>
          </span>
        </div>
        <div className="clip-notch flex items-center justify-between border border-hairline bg-void/50 px-3.5 py-3">
          <span className="font-mono text-[9px] tracking-[0.2em] text-ink-dim">MATCHED DIGITS</span>
          <span className="font-num text-[13px] font-bold text-ink" dir="ltr">
            {matches ?? 0} / 6
            <span className={cn("ms-2 text-[10px]", colorMatch ? "text-win" : "text-loss/60")}>
              {colorMatch ? "COLOR ✓" : "COLOR ✕"}
            </span>
          </span>
        </div>
      </div>
    </div>
  );
}

export function RefreshResult() {
  const [loading, setLoading] = useState(false);
  return (
    <Button
      variant="subtle"
      size="md"
      loading={loading}
      onClick={async () => {
        setLoading(true);
        window.location.reload();
      }}
    >
      <RefreshCw size={14} />
      بروزرسانی نتیجه
    </Button>
  );
}
