import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import CyberBackground from "@/components/cyber-background";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "BTC6 · لاتاری دیجیتال کندل بیت‌کوین",
    template: "%s · BTC6",
  },
  description:
    "BTC6 یک بازی پیش‌بینی روی کندل یک‌ساعته بیت‌کوین است. دو رقم آخر OPEN و HIGH و CLOSE و رنگ کندل را پیش‌بینی کن و بلیط دیجیتال بگیر.",
  keywords: ["BTC6", "بیت‌کوین", "پیش‌بینی", "کندل", "بلیط دیجیتال", "لاتاری"],
};

export const viewport: Viewport = {
  themeColor: "#03050a",
  colorScheme: "dark",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800;900&family=Space+Grotesk:wght@500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap"
        />
      </head>
      <body className="antialiased">
        <CyberBackground />
        {children}
      </body>
    </html>
  );
}
