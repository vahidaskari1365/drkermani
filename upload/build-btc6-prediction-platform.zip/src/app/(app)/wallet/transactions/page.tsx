import type { Metadata } from "next";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { transactions } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { STATUS_FA, TX_FA } from "@/lib/game";
import { money, faDate, toNum } from "@/lib/utils";
import { PageHeading, Card, StatusBadge, Empty, ButtonLink, Table, Th, Td } from "@/components/ui";
import Reveal from "@/components/reveal";
import TicketsFilter from "@/components/tickets-filter";
import { History, ArrowDownToLine } from "lucide-react";

export const metadata: Metadata = { title: "تاریخچه تراکنش" };
export const dynamic = "force-dynamic";

export default async function TransactionsPage({
  searchParams,
}: {
  searchParams: Promise<{ filter?: string }>;
}) {
  const user = await requireUser();
  const { filter } = await searchParams;

  const rows = await db
    .select()
    .from(transactions)
    .where(eq(transactions.userId, user.id))
    .orderBy(desc(transactions.id))
    .limit(80);

  const kinds = ["deposit", "withdraw", "ticket", "payout"];
  const shown = filter && filter !== "all" ? rows.filter((r) => r.kind === filter) : rows;

  const totalIn = rows.filter((r) => r.kind === "deposit" || r.kind === "payout").reduce((s, r) => s + toNum(r.amount), 0);
  const totalOut = rows.filter((r) => r.kind === "withdraw" || r.kind === "ticket").reduce((s, r) => s + toNum(r.amount), 0);

  return (
    <>
      <PageHeading
        kicker="WALLET / HISTORY"
        title="تاریخچه تراکنش"
        desc="تمام واریزها، برداشت‌ها، خرید بلیط‌ها و جوایز دریافت‌شده."
      />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {[
          ["مجموع ورودی", `+${money(totalIn)}`, "text-win"],
          ["مجموع خروجی", `−${money(totalOut)}`, "text-loss"],
          ["تعداد تراکنش", String(rows.length), "text-ink"],
          ["تراکنش موفق", String(rows.filter((r) => r.status === "completed").length), "text-cyan-hot"],
        ].map(([l, v, cls], i) => (
          <Reveal key={l} delay={i * 0.06}>
            <Card className="p-4">
              <p className="font-mono text-[9px] tracking-[0.2em] text-ink-dim">{l}</p>
              <p className={`mt-2 font-num text-[20px] font-bold ${cls}`} dir="ltr">
                {v}
              </p>
            </Card>
          </Reveal>
        ))}
      </div>

      <Reveal delay={0.1}>
        <div className="mt-5">
          <TicketsFilter
            base="/wallet/transactions"
            current={filter ?? "all"}
            items={[
              { key: "all", label: "همه", count: rows.length },
              ...kinds
                .filter((k) => rows.some((r) => r.kind === k))
                .map((k) => ({ key: k, label: TX_FA[k], count: rows.filter((r) => r.kind === k).length })),
            ]}
          />
        </div>
      </Reveal>

      <Reveal delay={0.14}>
        <Card className="mt-4">
          {shown.length === 0 ? (
            <Empty
              icon={<History size={22} />}
              title="تراکنشی یافت نشد"
              body="با اولین واریز، خرید بلیط یا دریافت جایزه، تاریخچه اینجا ساخته می‌شود."
              action={
                <ButtonLink href="/wallet/deposit" size="md" className="mt-2">
                  <ArrowDownToLine size={15} />
                  واریز
                </ButtonLink>
              }
            />
          ) : (
            <Table>
              <thead>
                <tr>
                  <Th>شناسه</Th>
                  <Th>نوع</Th>
                  <Th>مبلغ</Th>
                  <Th>موجودی پس از</Th>
                  <Th>وضعیت</Th>
                  <Th className="text-left">زمان</Th>
                </tr>
              </thead>
              <tbody>
                {shown.map((t) => {
                  const negative = t.kind === "withdraw" || t.kind === "ticket";
                  return (
                    <tr key={t.id} className="transition-colors hover:bg-cyan/5">
                      <Td className="font-mono text-[10.5px] text-ink-dim" >
                        <span dir="ltr">{t.reference}</span>
                      </Td>
                      <Td className="font-semibold text-ink">
                        {TX_FA[t.kind] ?? t.kind}
                        {t.note && <span className="mt-0.5 block text-[10.5px] font-normal text-ink-dim">{t.note}</span>}
                      </Td>
                      <Td>
                        <span className={`font-num text-[13px] font-bold ${negative ? "text-loss" : "text-win"}`} dir="ltr">
                          {negative ? "−" : "+"}
                          {money(t.amount)}
                        </span>
                      </Td>
                      <Td className="font-num text-[12px] text-ink-soft">
                        <span dir="ltr">{t.balanceAfter ? money(t.balanceAfter) : "—"}</span>
                      </Td>
                      <Td>
                        <StatusBadge status={t.status} label={STATUS_FA[t.status] ?? t.status} dot={false} />
                      </Td>
                      <Td className="text-left font-mono text-[10.5px] text-ink-dim">{faDate(t.createdAt)}</Td>
                    </tr>
                  );
                })}
              </tbody>
            </Table>
          )}
        </Card>
      </Reveal>
    </>
  );
}
