import type { Metadata } from "next";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { tickets } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { money, faDate, toNum } from "@/lib/utils";
import { PageHeading, Card, CardTitle } from "@/components/ui";
import Reveal from "@/components/reveal";
import ProfileForm from "@/components/profile-form";
import { User, CalendarDays, Ticket, Trophy, Hash } from "lucide-react";

export const metadata: Metadata = { title: "پروفایل و تنظیمات" };
export const dynamic = "force-dynamic";

export default async function ProfilePage() {
  const user = await requireUser();
  const rows = await db
    .select({ status: tickets.status, price: tickets.price, payout: tickets.payout })
    .from(tickets)
    .where(eq(tickets.userId, user.id))
    .orderBy(desc(tickets.id))
    .limit(200);

  const wins = rows.filter((r) => r.status === "won").length;
  const totalWon = rows.reduce((s, r) => s + toNum(r.payout), 0);
  const totalSpent = rows.reduce((s, r) => s + toNum(r.price), 0);
  const net = totalWon - totalSpent;

  return (
    <>
      <PageHeading
        kicker="PROFILE / SETTINGS"
        title="پروفایل و تنظیمات"
        desc="اطلاعات حساب، ترجیحات اعلان و تنظیمات کیف پول."
      />

      <Reveal>
        <Card className="mb-5 flex flex-wrap items-center gap-5 p-5">
          <span className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-cyan-hot to-cyan-deep font-disp text-[24px] font-bold text-void">
            {user.username.slice(0, 1).toUpperCase()}
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-[18px] font-extrabold text-ink">{user.username}</p>
            <p className="font-mono text-[11px] text-ink-dim" dir="ltr">
              {user.email}
            </p>
            <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1.5 font-mono text-[9.5px] tracking-[0.14em] text-ink-dim">
              <span className="flex items-center gap-1.5">
                <CalendarDays size={11} />
                عضویت: {faDate(user.createdAt)}
              </span>
              <span className="flex items-center gap-1.5">
                <Hash size={11} />
                شناسه: {user.id}
              </span>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            {[
              ["موجودی", money(user.balance), "text-ink"],
              ["بلیط", String(rows.length), "text-cyan-hot"],
              ["برد", String(wins), "text-win"],
              ["سود/زیان", (net >= 0 ? "+" : "") + money(net), net >= 0 ? "text-win" : "text-loss"],
            ].map(([l, v, cls]) => (
              <div key={l} className="clip-notch border border-hairline bg-void/40 px-3.5 py-2.5">
                <p className="font-mono text-[8.5px] tracking-[0.18em] text-ink-dim">{l}</p>
                <p className={`mt-1 font-num text-[15px] font-bold ${cls}`} dir="ltr">
                  {v}
                </p>
              </div>
            ))}
          </div>
        </Card>
      </Reveal>

      <Reveal delay={0.08}>
        <ProfileForm
          username={user.username}
          email={user.email}
          walletAddress={user.walletAddress}
          notifyLevel={user.notifyLevel}
          soundEnabled={user.soundEnabled}
        />
      </Reveal>

      <Reveal delay={0.14}>
        <Card className="mt-5">
          <CardTitle kicker="STATISTICS" icon={<Trophy size={16} />}>
            آمار بازی
          </CardTitle>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {[
              ["مجموع بلیط‌ها", String(rows.length), <Ticket key="a" size={15} className="text-cyan-hot" />],
              ["بلیط‌های برنده", String(wins), <Trophy key="b" size={15} className="text-win" />],
              ["مجموع هزینه", money(totalSpent), <User key="c" size={15} className="text-ink-dim" />],
              ["مجموع جوایز", money(totalWon), <Trophy key="d" size={15} className="text-orange-soft" />],
            ].map(([l, v, icon]) => (
              <div key={l as string} className="clip-notch border border-hairline bg-void/40 p-4">
                {icon as React.ReactNode}
                <p className="mt-3 font-mono text-[9px] tracking-[0.18em] text-ink-dim">{l as string}</p>
                <p className="mt-1 font-num text-[19px] font-bold text-ink" dir="ltr">
                  {v as string}
                </p>
              </div>
            ))}
          </div>
        </Card>
      </Reveal>
    </>
  );
}
