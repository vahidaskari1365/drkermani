"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { Ticket, LogIn, Eye, EyeOff, AlertCircle, Zap } from "lucide-react";
import { Button, Field, Input, Alert } from "@/components/ui";
import { Btc6Logo } from "@/components/logo";

export default function AuthForm({ mode }: { mode: "login" | "register" }) {
  const router = useRouter();
  const isLogin = mode === "login";
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState({ identifier: "", username: "", email: "", password: "" });

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await fetch(isLogin ? "/api/auth/login" : "/api/auth/register", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(
          isLogin
            ? { identifier: form.identifier, password: form.password }
            : { username: form.username, email: form.email, password: form.password },
        ),
      });
      const json = (await res.json()) as { error?: string; redirect?: string };
      if (!res.ok) {
        setError(json.error ?? "خطایی رخ داد.");
        setLoading(false);
        return;
      }
      router.push(json.redirect ?? "/dashboard");
      router.refresh();
    } catch {
      setError("ارتباط با سرور برقرار نشد.");
      setLoading(false);
    }
  }

  return (
    <div className="relative flex min-h-[100svh] items-center justify-center overflow-hidden px-4 py-16">
      <div className="pointer-events-none absolute inset-0 grid-floor opacity-30 [mask-image:radial-gradient(55%_55%_at_50%_45%,#000,transparent_75%)]" />
      <motion.div
        initial={{ opacity: 0, y: 26, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
        className="relative w-full max-w-[430px]"
      >
        <div className="mb-7 flex flex-col items-center gap-4 text-center">
          <Link href="/" aria-label="BTC6">
            <Btc6Logo />
          </Link>
          <div>
            <h1 className="text-[22px] font-extrabold text-ink">
              {isLogin ? "ورود به حساب BTC6" : "ساخت حساب جدید"}
            </h1>
            <p className="mt-2 text-[12.5px] text-ink-dim">
              {isLogin
                ? "نام کاربری یا ایمیل و رمز عبور خود را وارد کن."
                : "در کمتر از یک دقیقه ثبت‌نام کن و اولین بلیط را بگیر."}
            </p>
          </div>
        </div>

        <form onSubmit={submit} noValidate className="surface clip-cyber space-y-5 p-6 glow-cyan">
          <span className="absolute inset-x-0 top-0 h-px shimmer-line" />

          {error && (
            <div role="alert" className="clip-notch flex items-start gap-2.5 border border-loss/40 bg-loss/10 px-3.5 py-3 text-[12px] text-loss">
              <AlertCircle size={15} className="mt-0.5 shrink-0" />
              {error}
            </div>
          )}

          {isLogin ? (
            <Field label="نام کاربری یا ایمیل" htmlFor="identifier">
              <Input
                id="identifier"
                name="identifier"
                autoComplete="username"
                required
                dir="ltr"
                placeholder="player or you@mail.com"
                value={form.identifier}
                onChange={set("identifier")}
              />
            </Field>
          ) : (
            <>
              <Field label="نام کاربری" hint="a-z 0-9 _" htmlFor="username">
                <Input
                  id="username"
                  name="username"
                  autoComplete="username"
                  required
                  dir="ltr"
                  placeholder="player_one"
                  value={form.username}
                  onChange={set("username")}
                />
              </Field>
              <Field label="ایمیل" htmlFor="email">
                <Input
                  id="email"
                  name="email"
                  type="email"
                  autoComplete="email"
                  required
                  dir="ltr"
                  placeholder="you@mail.com"
                  value={form.email}
                  onChange={set("email")}
                />
              </Field>
            </>
          )}

          <Field label="رمز عبور" hint={isLogin ? undefined : "حداقل ۸ کاراکتر"} htmlFor="password">
            <div className="relative">
              <Input
                id="password"
                name="password"
                type={show ? "text" : "password"}
                autoComplete={isLogin ? "current-password" : "new-password"}
                required
                dir="ltr"
                placeholder="••••••••"
                value={form.password}
                onChange={set("password")}
                className="pl-12"
              />
              <button
                type="button"
                onClick={() => setShow((v) => !v)}
                aria-label={show ? "پنهان‌کردن رمز" : "نمایش رمز"}
                className="absolute left-3 top-1/2 grid h-7 w-7 -translate-y-1/2 place-items-center rounded-md text-ink-dim hover:text-cyan-hot"
              >
                {show ? <EyeOff size={15} /> : <Eye size={15} />}
              </button>
            </div>
          </Field>

          <Button type="submit" size="lg" loading={loading} disabled={loading} className="w-full">
            {isLogin ? <LogIn size={16} /> : <Ticket size={16} />}
            {isLogin ? "ورود به حساب" : "ساخت حساب و شروع"}
          </Button>

          {!isLogin && (
            <Alert tone="info">
              با ساخت حساب، <Link href="/terms" className="text-cyan-hot underline">شرایط استفاده</Link> و{" "}
              <Link href="/privacy" className="text-cyan-hot underline">حریم خصوصی</Link> را می‌پذیری.
            </Alert>
          )}

          {isLogin && (
            <button
              type="button"
              onClick={() => setForm((f) => ({ ...f, identifier: "demo", password: "demo1234" }))}
              className="clip-notch flex w-full items-center justify-between gap-3 border border-orange/30 bg-orange/8 px-3.5 py-3 text-right transition-colors hover:border-orange/60"
            >
              <span className="min-w-0">
                <span className="block font-mono text-[9px] tracking-[0.2em] text-orange-soft">
                  DEMO ACCOUNT
                </span>
                <span className="mt-0.5 block font-mono text-[11.5px] text-ink-soft" dir="ltr">
                  demo / demo1234
                </span>
              </span>
              <span className="shrink-0 font-mono text-[10px] text-orange-soft">پر‌کردن ←</span>
            </button>
          )}

          <div className="border-t border-hairline pt-5 text-center text-[12.5px] text-ink-dim">
            {isLogin ? "حساب نداری؟ " : "قبلاً ثبت‌نام کرده‌ای؟ "}
            <Link
              href={isLogin ? "/register" : "/login"}
              className="font-bold text-cyan-hot transition-colors hover:text-ink"
            >
              {isLogin ? "ساخت حساب جدید" : "ورود به حساب"}
            </Link>
          </div>
        </form>

        <div className="mt-6 text-center">
          <Link
            href="/"
            className="inline-flex items-center gap-1.5 font-mono text-[10px] tracking-[0.2em] text-ink-dim transition-colors hover:text-cyan-hot"
          >
            <Zap size={12} />
            بازگشت به صفحه اصلی
          </Link>
        </div>
      </motion.div>
    </div>
  );
}
