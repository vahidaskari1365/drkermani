import {
  pgTable,
  serial,
  text,
  varchar,
  timestamp,
  numeric,
  integer,
  boolean,
  index,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/* ============================ USERS ============================ */
export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    email: varchar("email", { length: 190 }).notNull(),
    username: varchar("username", { length: 64 }).notNull(),
    passwordHash: text("password_hash").notNull(),
    balance: numeric("balance", { precision: 18, scale: 2 }).notNull().default("0"),
    // currency label for display only
    currency: varchar("currency", { length: 8 }).notNull().default("USDT"),
    // TRC20 wallet used for withdrawals
    walletAddress: varchar("wallet_address", { length: 128 }),
    avatarSeed: integer("avatar_seed").notNull().default(1),
    // 0 = off, 1 = essential, 2 = all
    notifyLevel: integer("notify_level").notNull().default(2),
    soundEnabled: boolean("sound_enabled").notNull().default(true),
    role: varchar("role", { length: 16 }).notNull().default("player"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("users_email_idx").on(t.email),
    uniqueIndex("users_username_idx").on(t.username),
  ],
);

/* =========================== SESSIONS =========================== */
export const sessions = pgTable(
  "sessions",
  {
    token: varchar("token", { length: 96 }).primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  },
  (t) => [index("sessions_user_idx").on(t.userId)],
);

/* ============================ ROUNDS ============================
   One row per BTC/USDT 1H candle. `roundNumber` = epoch hour index,
   so it is globally unique and reproducible without a scheduler.
================================================================= */
export const rounds = pgTable(
  "rounds",
  {
    id: serial("id").primaryKey(),
    roundNumber: integer("round_number").notNull(),
    openTime: timestamp("open_time", { withTimezone: true }).notNull(),
    closeTime: timestamp("close_time", { withTimezone: true }).notNull(),
    ticketPrice: numeric("ticket_price", { precision: 12, scale: 2 }).notNull().default("10"),
    // live / settled
    status: varchar("status", { length: 12 }).notNull().default("live"),
    // final candle values (null while live)
    openPrice: numeric("open_price", { precision: 14, scale: 2 }),
    highPrice: numeric("high_price", { precision: 14, scale: 2 }),
    lowPrice: numeric("low_price", { precision: 14, scale: 2 }),
    closePrice: numeric("close_price", { precision: 14, scale: 2 }),
    // derived: last two digits of each value, e.g. "42","78","31"
    dOpen: varchar("d_open", { length: 2 }),
    dHigh: varchar("d_high", { length: 2 }),
    dClose: varchar("d_close", { length: 2 }),
    // GREEN / RED / WHITE (WHITE = doji, open === close)
    candleColor: varchar("candle_color", { length: 8 }),
    source: varchar("source", { length: 16 }).notNull().default("simulated"),
    settledAt: timestamp("settled_at", { withTimezone: true }),
  },
  (t) => [uniqueIndex("rounds_number_idx").on(t.roundNumber)],
);

/* =========================== TICKETS =========================== */
export const tickets = pgTable(
  "tickets",
  {
    id: serial("id").primaryKey(),
    code: varchar("code", { length: 24 }).notNull(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    roundId: integer("round_id")
      .notNull()
      .references(() => rounds.id, { onDelete: "cascade" }),
    pOpen: varchar("p_open", { length: 2 }).notNull(),
    pHigh: varchar("p_high", { length: 2 }).notNull(),
    pClose: varchar("p_close", { length: 2 }).notNull(),
    pColor: varchar("p_color", { length: 8 }).notNull(),
    price: numeric("price", { precision: 12, scale: 2 }).notNull(),
    // active / won / lost / refunded
    status: varchar("status", { length: 12 }).notNull().default("active"),
    matches: integer("matches").notNull().default(0),
    payout: numeric("payout", { precision: 18, scale: 2 }).notNull().default("0"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    settledAt: timestamp("settled_at", { withTimezone: true }),
  },
  (t) => [
    uniqueIndex("tickets_code_idx").on(t.code),
    index("tickets_user_idx").on(t.userId),
    index("tickets_round_idx").on(t.roundId),
  ],
);

/* ======================== TRANSACTIONS ======================== */
export const transactions = pgTable(
  "transactions",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    // deposit / withdraw / ticket / payout / refund
    kind: varchar("kind", { length: 12 }).notNull(),
    amount: numeric("amount", { precision: 18, scale: 2 }).notNull(),
    // pending / completed / failed
    status: varchar("status", { length: 12 }).notNull().default("completed"),
    reference: varchar("reference", { length: 40 }).notNull(),
    note: text("note"),
    balanceAfter: numeric("balance_after", { precision: 18, scale: 2 }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("tx_user_idx").on(t.userId)],
);

/* ======================= NOTIFICATIONS ======================= */
export const notifications = pgTable(
  "notifications",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    // info / win / loss / wallet / system
    kind: varchar("kind", { length: 12 }).notNull().default("info"),
    title: varchar("title", { length: 160 }).notNull(),
    body: text("body").notNull(),
    href: varchar("href", { length: 160 }),
    isRead: boolean("is_read").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("notif_user_idx").on(t.userId)],
);

export type User = typeof users.$inferSelect;
export type Round = typeof rounds.$inferSelect;
export type Ticket = typeof tickets.$inferSelect;
export type Transaction = typeof transactions.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
