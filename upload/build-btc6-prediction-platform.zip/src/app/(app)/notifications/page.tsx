import type { Metadata } from "next";
import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { settleDueRounds } from "@/lib/rounds";
import { faDate } from "@/lib/utils";
import { PageHeading, Card, Empty, ButtonLink } from "@/components/ui";
import Reveal from "@/components/reveal";
import MarkAllRead from "@/components/mark-all-read";
import { Bell, Trophy, Wallet, Info, TrendingDown, ChevronLeft } from "lucide-react";

export const metadata: Metadata = { title: "اعلان‌ها" };
export const dynamic = "force-dynamic";

const KIND: Record<string, { icon: typeof Bell; cls: string; label: string }> = {
  win: { icon: Trophy, cls: "border-win/40 bg-win/12 text-win", label: "برد" },
  loss: { icon: TrendingDown, cls: "border-loss/35 bg-loss/10 text-loss", label: "بدون برد" },
  wallet: { icon: Wallet, cls: "border-orange/35 bg-orange/10 text-orange-soft", label: "کیف پول" },
  system: { icon: Info, cls: "border-cyan/30 bg-cyan/10 text-cyan-hot", label: "سیستم" },
  info: { icon: Bell, cls: "border-cyan/30 bg-cyan/10 text-cyan-hot", label: "اطلاع" },
};

export default async function NotificationsPage() {
  const user = await requireUser();
  await settleDueRounds().catch(() => 0);

  const rows = await db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, user.id))
    .orderBy(desc(notifications.id))
    .limit(40);

  const unread = rows.filter((r) => !r.isRead).length;

  return (
    <>
      <PageHeading
        kicker="NOTIFICATIONS"
        title="اعلان‌ها"
        desc="نتیجه بلیط‌ها، تراکنش‌های کیف پول و پیام‌های سیستمی."
        action={unread > 0 ? <MarkAllRead count={unread} /> : undefined}
      />

      {rows.length === 0 ? (
        <Card>
          <Empty
            icon={<Bell size={22} />}
            title="اعلانی نداری"
            body="پس از خرید بلیط یا انجام تراکنش، اطلاع‌رسانی‌ها اینجا نمایش داده می‌شوند."
            action={
              <ButtonLink href="/play" size="md" className="mt-2">
                ورود به بازی
              </ButtonLink>
            }
          />
        </Card>
      ) : (
        <div className="space-y-3">
          {rows.map((n, i) => {
            const k = KIND[n.kind] ?? KIND.info;
            return (
              <Reveal key={n.id} delay={Math.min(i * 0.04, 0.3)}>
                <Link href={n.href ?? "#"} className="block">
                  <Card
                    className={`flex items-start gap-4 p-4 transition-colors ${
                      n.isRead ? "" : "border-cyan/30"
                    }`}
                  >
                    <span className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl border ${k.cls}`}>
                      <k.icon size={17} />
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2.5">
                        <p className="text-[13.5px] font-bold text-ink">{n.title}</p>
                        {!n.isRead && (
                          <span className="rounded-full bg-cyan/20 px-2 py-0.5 font-mono text-[9px] font-bold text-cyan-hot">
                            NEW
                          </span>
                        )}
                        <span className="font-mono text-[9px] tracking-[0.16em] text-ink-dim">{k.label}</span>
                      </div>
                      <p className="mt-1.5 text-[12.5px] leading-relaxed text-ink-soft">{n.body}</p>
                      <p className="mt-2 font-mono text-[9.5px] text-ink-dim/70">{faDate(n.createdAt)}</p>
                    </div>
                    {n.href && <ChevronLeft size={15} className="mt-2 shrink-0 text-ink-dim" />}
                  </Card>
                </Link>
              </Reveal>
            );
          })}
        </div>
      )}
    </>
  );
}
