import type { Metadata } from "next";
import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { transactions } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { STATUS_FA, TX_FA } from "@/lib/game";
import { money, faDate } from "@/lib/utils";
import { PageHeading, Card, CardTitle, StatusBadge, ButtonLink, Table, Th, Td, Empty } from "@/components/ui";
import Reveal from "@/components/reveal";
import { ArrowDownToLine, ArrowUpFromLine, History, Wallet, ChevronLeft, TrendingUp } from "lucide-react";

export const metadata: Metadata = { title: "کیف پول" };
export const dynamic = "force-dynamic";

export default async function WalletPage() {
  const user = await requireUser();
  const txs = await db
    .select()
    .from(transactions)
    .where(eq(transactions.userId, user.id))
    .orderBy(desc(transactions.id))
    .limit(8);

  const nums = txs.map((t) => Number(t.amount) * (t.kind === "withdraw" || t.kind === "ticket" ? -1 : 1));
  const inSum = nums.filter((n) => n > 0).reduce((a, b) => a + b, 0);
  const outSum = Math.abs(nums.filter((n) => n < 0).reduce((a, b) => a + b, 0));

  return (
    <>
      <PageHeading
        kicker="WALLET"
        title="کیف پول"
        desc="مدیریت موجودی، واریز، برداشت و تاریخچه تراکنش‌ها."
        action={
          <div className="flex flex-wrap gap-3">
            <ButtonLink href="/wallet/deposit" size="lg">
              <ArrowDownToLine size={16} />
              واریز
            </ButtonLink>
            <ButtonLink href="/wallet/withdraw" variant="outline" size="lg">
              <ArrowUpFromLine size={16} />
              برداشت
            </ButtonLink>
          </div>
        }
      />

      <div className="grid gap-5 lg:grid-cols-[1fr_1.3fr]">
        <Reveal>
          <Card glow="orange" className="h-full">
            <div className="flex items-start justify-between">
              <span className="grid h-11 w-11 place-items-center rounded-xl border border-orange/30 bg-orange/10 text-orange-soft">
                <Wallet size={19} />
              </span>
              <StatusBadge status="completed" label={STATUS_FA.completed} />
            </div>
            <p className="mt-6 font-mono text-[9.5px] tracking-[0.22em] text-ink-dim">TOTAL BALANCE</p>
            <p className="mt-2 font-num text-[38px] font-bold leading-none text-ink" dir="ltr">
              {money(user.balance)}
            </p>
            <p className="mt-2 font-mono text-[11px] tracking-[0.2em] text-orange-soft">USDT · TRC20</p>

            <div className="mt-6 grid grid-cols-2 gap-3 border-t border-hairline pt-5">
              <div>
                <p className="font-mono text-[9px] tracking-[0.2em] text-ink-dim">TOTAL IN</p>
                <p className="mt-1 font-num text-[16px] font-bold text-win" dir="ltr">
                  +{money(inSum)}
                </p>
              </div>
              <div>
                <p className="font-mono text-[9px] tracking-[0.2em] text-ink-dim">TOTAL OUT</p>
                <p className="mt-1 font-num text-[16px] font-bold text-loss" dir="ltr">
                  −{money(outSum)}
                </p>
              </div>
            </div>

            <div className="mt-5 space-y-2.5 border-t border-hairline pt-5">
              {[
                ["حداقل واریز", "۱۰ USDT"],
                ["حداقل برداشت", "۲۰ USDT"],
                ["کارمزد برداشت", "۱ USDT"],
                ["زمان پردازش", "< ۱۵ دقیقه"],
              ].map(([k, v]) => (
                <div key={k} className="flex items-center justify-between">
                  <span className="text-[12px] text-ink-dim">{k}</span>
                  <span className="font-num text-[12px] font-bold text-ink-soft" dir="ltr">
                    {v}
                  </span>
                </div>
              ))}
            </div>
          </Card>
        </Reveal>

        <Reveal delay={0.08}>
          <Card className="h-full">
            <CardTitle
              kicker="RECENT ACTIVITY"
              icon={<History size={16} />}
              action={
                <Link href="/wallet/transactions" className="flex items-center gap-1 font-mono text-[10px] text-cyan-hot hover:text-ink">
                  همه <ChevronLeft size={12} />
                </Link>
              }
            >
              تراکنش‌های اخیر
            </CardTitle>
            {txs.length === 0 ? (
              <Empty icon={<TrendingUp size={20} />} title="تراکنشی ثبت نشده" body="پس از اولین واریز یا خرید بلیط، اینجا نمایش داده می‌شود." />
            ) : (
              <Table>
                <thead>
                  <tr>
                    <Th>نوع</Th>
                    <Th>مبلغ</Th>
                    <Th>وضعیت</Th>
                    <Th className="text-left">زمان</Th>
                  </tr>
                </thead>
                <tbody>
                  {txs.map((t) => {
                    const negative = t.kind === "withdraw" || t.kind === "ticket";
                    return (
                      <tr key={t.id} className="transition-colors hover:bg-cyan/5">
                        <Td className="font-semibold text-ink">{TX_FA[t.kind] ?? t.kind}</Td>
                        <Td>
                          <span
                            className={`font-num text-[13px] font-bold ${negative ? "text-loss" : "text-win"}`}
                            dir="ltr"
                          >
                            {negative ? "−" : "+"}
                            {money(t.amount)}
                          </span>
                        </Td>
                        <Td>
                          <StatusBadge status={t.status} label={STATUS_FA[t.status] ?? t.status} dot={false} />
                        </Td>
                        <Td className="text-left font-mono text-[10.5px] text-ink-dim">
                          {faDate(t.createdAt)}
                        </Td>
                      </tr>
                    );
                  })}
                </tbody>
              </Table>
            )}
          </Card>
        </Reveal>
      </div>
    </>
  );
}
