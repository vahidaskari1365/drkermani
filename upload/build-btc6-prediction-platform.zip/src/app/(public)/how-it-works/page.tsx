import type { Metadata } from "next";
import Reveal, { DocHero } from "@/components/reveal";
import { ButtonLink, Card, CardTitle } from "@/components/ui";
import { Clock, Layers, Trophy, Activity, ArrowLeft, Ticket, Wallet } from "lucide-react";

export const metadata: Metadata = { title: "چطور کار می‌کند" };

const STEPS = [
  {
    n: "۰۱",
    icon: Clock,
    title: "کندل یک‌ساعته را رصد کن",
    body: "BTC6 روی کندل‌های ۱ ساعته BTC/USDT کار می‌کند. هر کندل دقیقاً در ابتدای ساعت باز می‌شود و در پایان ساعت بسته می‌شود. در صفحه بازی، قیمت لحظه‌ای، سقف و کف فعلی و زمان باقی‌مانده تا بسته‌شدن کندل نمایش داده می‌شود.",
    points: ["نماد: BTC/USDT", "بازه: ۱ ساعت (1H)", "منبع داده: بازار جهانی"],
  },
  {
    n: "۰۲",
    icon: Layers,
    title: "شش رقم و یک رنگ پیش‌بینی کن",
    body: "برای هرکدام از OPEN و HIGH و CLOSE، دو رقم آخر قیمت را انتخاب می‌کنی (۰۰ تا ۹۹). بعد رنگ کندل را از بین سبز (بسته‌شدن بالاتر از بازشدن)، قرمز (بسته‌شدن پایین‌تر) و سفید (دودوجی — برابری دقیق) انتخاب می‌کنی.",
    points: ["OPEN: دو رقم", "HIGH: دو رقم", "CLOSE: دو رقم", "COLOR: GREEN / RED / WHITE"],
  },
  {
    n: "۰۳",
    icon: Ticket,
    title: "بلیط دیجیتال بگیر",
    body: "با تأیید پیش‌بینی، مبلغ بلیط از کیف پول کسر و یک بلیط دیجیتال BTC6 با شناسه یکتا صادر می‌شود. پیش‌بینی پس از ثبت قابل تغییر نیست — این بخشی از شفافیت بازی است.",
    points: ["قیمت هر بلیط: ۱۰ USDT", "یک بلیط فعال برای هر کشش", "شناسه یکتای بلیط"],
  },
  {
    n: "۰۴",
    icon: Trophy,
    title: "نتیجه را ببین",
    body: "با بسته‌شدن کندل، دو رقم آخر OPEN و HIGH و CLOSE واقعی و رنگ کندل استخراج می‌شود، تعداد ارقام درستِ بلیط محاسبه می‌شود و جایزه بر اساس جدول جوایز به‌صورت خودکار به کیف پول واریز می‌شود.",
    points: ["محاسبه خودکار و بی‌واسطه", "واریز فوری جایزه", "تاریخچه کامل قابل بررسی"],
  },
];

export default function HowItWorksPage() {
  return (
    <>
      <DocHero
        kicker="PROTOCOL / 01"
        title="بازی BTC6 چطور کار می‌کند؟"
        desc="چهار مرحله ساده: رصد کندل، پیش‌بینی شش رقم و یک رنگ، دریافت بلیط دیجیتال و مشاهده نتیجه شفاف."
      />

      <section className="py-16 sm:py-24">
        <div className="mx-auto w-full max-w-[1240px] px-4 sm:px-6">
          <div className="space-y-5">
            {STEPS.map((s, i) => (
              <Reveal key={s.n} delay={i * 0.08}>
                <Card className="grid gap-6 p-6 md:grid-cols-[auto_1.6fr_1fr] md:items-center">
                  <div className="flex items-center gap-4 md:flex-col md:items-start">
                    <span className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl border border-cyan/25 bg-cyan/10 text-cyan-hot">
                      <s.icon size={24} />
                    </span>
                    <span className="font-num text-[42px] font-black leading-none text-cyan/12">{s.n}</span>
                  </div>
                  <div>
                    <h2 className="text-[19px] font-extrabold text-ink">{s.title}</h2>
                    <p className="mt-3 text-[13.5px] leading-[2] text-ink-soft">{s.body}</p>
                  </div>
                  <ul className="space-y-2 md:border-r md:border-hairline md:pr-6">
                    {s.points.map((p) => (
                      <li key={p} className="flex items-center gap-2 font-mono text-[11px] tracking-wide text-cyan/90">
                        <span className="h-1 w-1 rounded-full bg-cyan-hot" />
                        {p}
                      </li>
                    ))}
                  </ul>
                </Card>
              </Reveal>
            ))}
          </div>

          <Reveal delay={0.1}>
            <Card className="mt-8 p-6" glow="cyan">
              <CardTitle kicker="EXAMPLE" icon={<Activity size={16} />}>
                یک مثال واقعی
              </CardTitle>
              <div className="grid gap-5 md:grid-cols-3">
                {[
                  { h: "پیش‌بینی تو", v: "OPEN 42 · HIGH 78 · CLOSE 31 · GREEN" },
                  { h: "نتیجه کندل", v: "OPEN 42 · HIGH 71 · CLOSE 35 · GREEN" },
                  { h: "ارقام درست", v: "OPEN ۲ رقم + HIGH ۱ رقم + CLOSE ۱ رقم = ۴ رقم + رنگ درست" },
                ].map((b) => (
                  <div key={b.h} className="clip-notch border border-hairline bg-void/40 p-4">
                    <p className="font-mono text-[9px] tracking-[0.2em] text-ink-dim">{b.h}</p>
                    <p className="mt-2 font-num text-[13px] font-bold leading-relaxed text-ink" dir="ltr">
                      {b.v}
                    </p>
                  </div>
                ))}
              </div>
              <p className="mt-5 border-t border-hairline pt-4 text-[13px] leading-[2] text-ink-soft">
                این بلیط ۴ رقم درست و رنگ درست دارد → طبق جدول جوایز در سطح «چهاررقمی» قرار می‌گیرد و
                ۱۲ برابر مبلغ بلیط (۱۲۰ USDT) جایزه می‌گیرد.
              </p>
            </Card>
          </Reveal>

          <div className="mt-10 flex flex-wrap gap-3">
            <ButtonLink href="/play" size="lg">
              <Wallet size={16} />
              شروع بازی
            </ButtonLink>
            <ButtonLink href="/rules" variant="outline" size="lg">
              قوانین کامل
              <ArrowLeft size={15} />
            </ButtonLink>
          </div>
        </div>
      </section>
    </>
  );
}
