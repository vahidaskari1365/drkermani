import type { Metadata } from "next";
import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { tickets, rounds } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { getCurrentRound, getChartSeries, getRecentSettled, settleDueRounds } from "@/lib/rounds";
import { TICKET_PRICE } from "@/lib/game";
import PlayConsole from "@/components/play/play-console";

export const metadata: Metadata = { title: "بازی و خرید بلیط" };
export const dynamic = "force-dynamic";

export default async function PlayPage() {
  const user = await requireUser();
  await settleDueRounds().catch(() => 0);

  const [state, chart, settled] = await Promise.all([
    getCurrentRound(),
    getChartSeries(48),
    getRecentSettled(8),
  ]);

  const rows = await db
    .select({
      id: tickets.id,
      code: tickets.code,
      pOpen: tickets.pOpen,
      pHigh: tickets.pHigh,
      pClose: tickets.pClose,
      pColor: tickets.pColor,
      price: tickets.price,
      status: tickets.status,
      payout: tickets.payout,
      roundNumber: rounds.roundNumber,
      dOpen: rounds.dOpen,
      dHigh: rounds.dHigh,
      dClose: rounds.dClose,
      candleColor: rounds.candleColor,
    })
    .from(tickets)
    .innerJoin(rounds, eq(rounds.id, tickets.roundId))
    .where(and(eq(tickets.userId, user.id), eq(tickets.roundId, state.round.id)))
    .orderBy(desc(tickets.id))
    .limit(1);

  const t = rows[0];
  const activeTicket = t
    ? {
        id: t.id,
        code: t.code,
        roundNumber: t.roundNumber,
        open: t.pOpen,
        high: t.pHigh,
        close: t.pClose,
        color: t.pColor,
        price: t.price,
        status: t.status,
        payout: t.payout,
        result:
          t.status === "active"
            ? null
            : { open: t.dOpen ?? "", high: t.dHigh ?? "", close: t.dClose ?? "", color: t.candleColor ?? "" },
      }
    : null;

  return (
    <PlayConsole
      roundNumber={state.roundNumber}
      closeTime={state.closeTime}
      openTime={state.openTime}
      candles={chart.candles}
      price={state.candle.close}
      ticketPrice={Number(state.round.ticketPrice) || TICKET_PRICE}
      balance={user.balance}
      activeTicket={activeTicket}
      lastDraws={settled.map((r) => ({
        roundNumber: r.roundNumber,
        dOpen: r.dOpen ?? "--",
        dHigh: r.dHigh ?? "--",
        dClose: r.dClose ?? "--",
        candleColor: r.candleColor,
      }))}
    />
  );
}
