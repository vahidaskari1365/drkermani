import Link from "next/link";
import { ButtonLink } from "@/components/ui";
import { Home, Play, SearchX } from "lucide-react";

export default function NotFound() {
  return (
    <div className="relative flex min-h-[100svh] items-center justify-center overflow-hidden px-4">
      <div className="pointer-events-none absolute inset-0 grid-floor opacity-30 [mask-image:radial-gradient(50%_50%_at_50%_50%,#000,transparent_75%)]" />
      <div className="relative max-w-lg text-center">
        <p className="font-disp text-[clamp(5rem,18vw,10rem)] font-black leading-none text-cyan/12" dir="ltr">
          404
        </p>
        <div className="clip-notch mx-auto mb-6 inline-flex items-center gap-2.5 border border-hairline bg-deep/60 px-4 py-2">
          <SearchX size={15} className="text-cyan-hot" />
          <span className="font-mono text-[10px] tracking-[0.24em] text-cyan-hot">SIGNAL NOT FOUND</span>
        </div>
        <h1 className="text-[24px] font-extrabold text-ink">این صفحه در شبکه BTC6 پیدا نشد</h1>
        <p className="mx-auto mt-4 max-w-md text-[13.5px] leading-[2] text-ink-soft">
          ممکن است آدرس تغییر کرده باشد یا بلیط مورد نظر متعلق به حساب دیگری باشد. از مسیرهای زیر ادامه بده.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <ButtonLink href="/" size="lg">
            <Home size={16} />
            صفحه اصلی
          </ButtonLink>
          <ButtonLink href="/play" variant="outline" size="lg">
            <Play size={16} />
            بازی BTC6
          </ButtonLink>
        </div>
        <div className="mt-10 flex flex-wrap justify-center gap-x-6 gap-y-2 font-mono text-[10px] tracking-[0.18em] text-ink-dim">
          {[["/how-it-works", "چطور کار می‌کند"], ["/rules", "قوانین"], ["/faq", "سوالات متداول"], ["/terms", "شرایط استفاده"]].map(
            ([href, label]) => (
              <Link key={href} href={href} className="transition-colors hover:text-cyan-hot">
                {label}
              </Link>
            ),
          )}
        </div>
      </div>
    </div>
  );
}
