import type { ReactNode } from "react";
import { redirect } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { currentUser } from "@/lib/auth";
import AppShell from "@/components/shell/app-shell";

export const dynamic = "force-dynamic";

export default async function AppLayout({ children }: { children: ReactNode }) {
  const user = await currentUser().catch(() => null);
  if (!user) redirect("/login");

  let unread = 0;
  try {
    const rows = await db
      .select({ id: notifications.id })
      .from(notifications)
      .where(and(eq(notifications.userId, user.id), eq(notifications.isRead, false)));
    unread = rows.length;
  } catch {
    unread = 0;
  }

  return (
    <AppShell
      user={{
        id: user.id,
        username: user.username,
        email: user.email,
        balance: user.balance,
        avatarSeed: user.avatarSeed,
      }}
      unread={unread}
    >
      {children}
    </AppShell>
  );
}
