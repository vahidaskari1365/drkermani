import type { Metadata } from "next";
import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { tickets, rounds } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { settleDueRounds } from "@/lib/rounds";
import { STATUS_FA } from "@/lib/game";
import { money, faDate } from "@/lib/utils";
import { PageHeading, Card, StatusBadge, Empty, ButtonLink, Table, Th, Td } from "@/components/ui";
import Reveal from "@/components/reveal";
import TicketsFilter from "@/components/tickets-filter";
import { Ticket, ChevronLeft } from "lucide-react";

export const metadata: Metadata = { title: "بلیط‌های من" };
export const dynamic = "force-dynamic";

export default async function TicketsPage({
  searchParams,
}: {
  searchParams: Promise<{ filter?: string }>;
}) {
  const user = await requireUser();
  const { filter } = await searchParams;
  await settleDueRounds().catch(() => 0);

  const rows = await db
    .select({
      id: tickets.id,
      code: tickets.code,
      pOpen: tickets.pOpen,
      pHigh: tickets.pHigh,
      pClose: tickets.pClose,
      pColor: tickets.pColor,
      price: tickets.price,
      status: tickets.status,
      payout: tickets.payout,
      matches: tickets.matches,
      createdAt: tickets.createdAt,
      roundNumber: rounds.roundNumber,
      closeTime: rounds.closeTime,
      dOpen: rounds.dOpen,
      dHigh: rounds.dHigh,
      dClose: rounds.dClose,
      candleColor: rounds.candleColor,
    })
    .from(tickets)
    .innerJoin(rounds, eq(rounds.id, tickets.roundId))
    .where(eq(tickets.userId, user.id))
    .orderBy(desc(tickets.id))
    .limit(60);

  const shown = filter && filter !== "all" ? rows.filter((r) => r.status === filter) : rows;
  const counts = {
    all: rows.length,
    active: rows.filter((r) => r.status === "active").length,
    won: rows.filter((r) => r.status === "won").length,
    lost: rows.filter((r) => r.status === "lost").length,
  };

  return (
    <>
      <PageHeading
        kicker="MY TICKETS"
        title="بلیط‌های من"
        desc="تمام بلیط‌های دیجیتال صادرشده، وضعیت و نتیجه هرکدام."
        action={
          <ButtonLink href="/play" size="lg">
            <Ticket size={16} />
            بلیط جدید
          </ButtonLink>
        }
      />

      <Reveal>
        <TicketsFilter
          base="/tickets"
          current={filter ?? "all"}
          items={[
            { key: "all", label: "همه", count: counts.all },
            { key: "active", label: "فعال", count: counts.active },
            { key: "won", label: "برنده", count: counts.won },
            { key: "lost", label: "بازنده", count: counts.lost },
          ]}
        />
      </Reveal>

      <Reveal delay={0.06}>
        <Card className="mt-4 p-4 sm:p-5">
          {shown.length === 0 ? (
            <Empty
              icon={<Ticket size={22} />}
              title="بلیطی پیدا نشد"
              body="با انتخاب شش رقم و یک رنگ برای کشش بعدی، اولین بلیط دیجیتالت را بگیر."
              action={
                <ButtonLink href="/play" size="md" className="mt-2">
                  ورود به بازی
                </ButtonLink>
              }
            />
          ) : (
            <Table>
              <thead>
                <tr>
                  <Th>شناسه بلیط</Th>
                  <Th>کشش</Th>
                  <Th>پیش‌بینی</Th>
                  <Th>وضعیت</Th>
                  <Th className="text-left">جایزه</Th>
                  <Th className="text-left">جزئیات</Th>
                </tr>
              </thead>
              <tbody>
                {shown.map((t) => (
                  <tr key={t.id} className="transition-colors hover:bg-cyan/5">
                    <Td>
                      <span className="font-mono text-[11px] text-ink" dir="ltr">#{t.code}</span>
                      <span className="mt-1 block font-mono text-[9px] text-ink-dim">
                        {faDate(t.createdAt)}
                      </span>
                    </Td>
                    <Td className="font-num text-[12px] text-ink-soft">
                      <span dir="ltr">#{t.roundNumber}</span>
                    </Td>
                    <Td>
                      <span className="font-num text-[13px] font-bold text-cyan-hot" dir="ltr">
                        {t.pOpen}·{t.pHigh}·{t.pClose}
                      </span>
                      <span
                        className={`mt-1 block font-mono text-[9.5px] ${
                          t.pColor === "GREEN" ? "text-win" : t.pColor === "RED" ? "text-loss" : "text-ink-soft"
                        }`}
                        dir="ltr"
                      >
                        {t.pColor}
                      </span>
                    </Td>
                    <Td>
                      <StatusBadge status={t.status} label={STATUS_FA[t.status] ?? t.status} />
                    </Td>
                    <Td className="text-left">
                      <span
                        className={`font-num text-[13px] font-bold ${
                          t.status === "won" ? "text-win" : "text-loss/60"
                        }`}
                        dir="ltr"
                      >
                        {t.status === "won" ? `+${money(t.payout)}` : "0.00"}
                      </span>
                    </Td>
                    <Td className="text-left">
                      <Link
                        href={`/tickets/${t.id}`}
                        className="inline-flex items-center gap-1 font-mono text-[10.5px] text-cyan-hot hover:text-ink"
                      >
                        مشاهده
                        <ChevronLeft size={12} />
                      </Link>
                    </Td>
                  </tr>
                ))}
              </tbody>
            </Table>
          )}
        </Card>
      </Reveal>
    </>
  );
}
