"use client";

import { useEffect, useRef, type ReactNode } from "react";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Modal({
  open,
  onClose,
  title,
  kicker,
  children,
  footer,
  size = "md",
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  kicker?: string;
  children: ReactNode;
  footer?: ReactNode;
  size?: "sm" | "md" | "lg";
}) {
  const panel = useRef<HTMLDivElement>(null);
  const restoreTo = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (!open) return;
    restoreTo.current = document.activeElement as HTMLElement | null;
    const t = window.setTimeout(() => {
      const first = panel.current?.querySelector<HTMLElement>(
        "button, [href], input, select, textarea, [tabindex]:not([tabindex='-1'])",
      );
      (first ?? panel.current)?.focus();
    }, 30);
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.stopPropagation();
        onClose();
      }
      if (e.key === "Tab" && panel.current) {
        const items = Array.from(
          panel.current.querySelectorAll<HTMLElement>(
            "button:not([disabled]), [href], input:not([disabled]), select, textarea, [tabindex]:not([tabindex='-1'])",
          ),
        ).filter((el) => el.offsetParent !== null);
        if (!items.length) return;
        const first = items[0];
        const last = items[items.length - 1];
        if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        } else if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        }
      }
    };
    document.addEventListener("keydown", onKey);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.clearTimeout(t);
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prevOverflow;
      restoreTo.current?.focus?.();
    };
  }, [open, onClose]);

  if (!open) return null;

  const widths = { sm: "max-w-sm", md: "max-w-md", lg: "max-w-2xl" };

  return (
    <div className="fixed inset-0 z-[80] flex items-end justify-center p-4 sm:items-center">
      <button
        aria-label="بستن پنجره"
        onClick={onClose}
        className="absolute inset-0 cursor-default bg-void/85 backdrop-blur-sm"
        tabIndex={-1}
      />
      <div
        ref={panel}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        tabIndex={-1}
        className={cn(
          "surface clip-cyber relative w-full animate-[riseIn_0.35s_cubic-bezier(0.16,1,0.3,1)] p-6 outline-none",
          widths[size],
        )}
      >
        <span className="absolute inset-x-0 top-0 h-px shimmer-line" />
        <div className="mb-5 flex items-start justify-between gap-4">
          <div>
            {kicker && (
              <div className="mb-1.5 font-mono text-[9.5px] tracking-[0.3em] text-cyan/80">{kicker}</div>
            )}
            <h2 className="text-[17px] font-extrabold text-ink">{title}</h2>
          </div>
          <button
            onClick={onClose}
            aria-label="بستن"
            className="grid h-8 w-8 place-items-center rounded-lg border border-hairline text-ink-dim transition-colors hover:border-loss/50 hover:text-loss"
          >
            <X size={15} />
          </button>
        </div>
        <div className="text-[13px] leading-relaxed text-ink-soft">{children}</div>
        {footer && <div className="mt-6 flex flex-wrap gap-3">{footer}</div>}
      </div>
    </div>
  );
}
