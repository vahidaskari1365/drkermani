import type { Metadata } from "next";
import { requireUser } from "@/lib/auth";
import { PageHeading, Alert } from "@/components/ui";
import Reveal from "@/components/reveal";
import { DepositForm } from "@/components/wallet-forms";
import { ShieldCheck } from "lucide-react";

export const metadata: Metadata = { title: "واریز" };
export const dynamic = "force-dynamic";

export default async function DepositPage() {
  const user = await requireUser();
  return (
    <>
      <PageHeading kicker="WALLET / DEPOSIT" title="واریز به کیف پول" desc="با تتر روی شبکه TRC20 کیف پول خود را شارژ کن." />
      <Reveal>
        <DepositForm balance={user.balance} />
      </Reveal>
      <Reveal delay={0.08}>
        <div className="mt-5">
          <Alert tone="info" title="نکته امنیتی">
            <span className="flex items-start gap-2">
              <ShieldCheck size={14} className="mt-0.5 shrink-0" />
              آدرس واریز را همیشه از همین صفحه کپی کن و فقط از شبکه TRC20 استفاده کن. واریز روی شبکه‌های
              دیگر قابل بازیابی نیست.
            </span>
          </Alert>
        </div>
      </Reveal>
    </>
  );
}
