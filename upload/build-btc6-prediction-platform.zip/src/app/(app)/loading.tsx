import { Skeleton } from "@/components/ui";

export default function AppLoading() {
  return (
    <div className="space-y-5">
      <div className="flex items-end justify-between gap-4">
        <div className="space-y-3">
          <Skeleton className="h-2.5 w-28" />
          <Skeleton className="h-8 w-56" />
          <Skeleton className="h-3 w-72" />
        </div>
        <Skeleton className="h-11 w-32" />
      </div>

      <Skeleton className="h-64 w-full rounded-[18px]" />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-28 rounded-[18px]" />
        ))}
      </div>

      <div className="grid gap-5 lg:grid-cols-[1.35fr_1fr]">
        <Skeleton className="h-72 rounded-[18px]" />
        <Skeleton className="h-72 rounded-[18px]" />
      </div>

      <div className="flex items-center justify-center gap-2 pt-4">
        <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-cyan-hot" />
        <span className="font-mono text-[10px] tracking-[0.24em] text-ink-dim">
          SYNCING WITH BTC/USDT FEED…
        </span>
      </div>
    </div>
  );
}
