"use client";

import { useRef, type ReactNode } from "react";
import { motion, useInView } from "framer-motion";

export default function Reveal({
  children,
  delay = 0,
  y = 26,
  className,
}: {
  children: ReactNode;
  delay?: number;
  y?: number;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-10% 0px -10% 0px" });
  return (
    <motion.div
      ref={ref}
      className={className}
      initial={{ opacity: 0, y, filter: "blur(5px)" }}
      animate={inView ? { opacity: 1, y: 0, filter: "blur(0px)" } : {}}
      transition={{ duration: 0.8, delay, ease: [0.16, 1, 0.3, 1] }}
    >
      {children}
    </motion.div>
  );
}

export function DocHero({
  kicker,
  title,
  desc,
}: {
  kicker: string;
  title: string;
  desc?: string;
}) {
  return (
    <header className="relative overflow-hidden border-b border-hairline py-20 sm:py-28">
      <div className="pointer-events-none absolute inset-0 grid-floor opacity-35 [mask-image:radial-gradient(60%_60%_at_50%_30%,#000,transparent_75%)]" />
      <div className="relative mx-auto w-full max-w-[1240px] px-4 sm:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          <div className="mb-3 flex items-center gap-2 font-mono text-[10px] tracking-[0.3em] text-cyan/80">
            <span className="h-px w-6 bg-cyan/50" />
            {kicker}
          </div>
          <h1 className="max-w-3xl text-[clamp(2rem,5.4vw,3.4rem)] font-black leading-[1.15] text-ink">
            {title}
          </h1>
          {desc && <p className="mt-5 max-w-2xl text-[14px] leading-[2] text-ink-soft">{desc}</p>}
        </motion.div>
      </div>
    </header>
  );
}
