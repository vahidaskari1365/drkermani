"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  LayoutDashboard, Ticket, Play, Wallet, User, Bell, History,
  ScrollText, LogOut, ChevronDown, ShieldCheck, Menu, X, ArrowLeftRight,
} from "lucide-react";
import { Btc6Logo } from "@/components/logo";
import { StatusBadge, ButtonLink } from "@/components/ui";
import { cn, money } from "@/lib/utils";
import { useMarket, useCountdown } from "@/lib/useLive";

export type ShellUser = {
  id: number;
  username: string;
  email: string;
  balance: string;
  avatarSeed: number;
};

const NAV = [
  { href: "/dashboard", label: "مرکز کنترل", icon: LayoutDashboard },
  { href: "/play", label: "بازی و بلیط", icon: Play, primary: true },
  { href: "/tickets", label: "بلیط‌های من", icon: Ticket },
  { href: "/wallet", label: "کیف پول", icon: Wallet },
  { href: "/wallet/transactions", label: "تاریخچه تراکنش", icon: History },
  { href: "/notifications", label: "اعلان‌ها", icon: Bell },
  { href: "/profile", label: "پروفایل", icon: User },
];

const BOTTOM = [
  { href: "/dashboard", label: "خانه", icon: LayoutDashboard },
  { href: "/tickets", label: "بلیط‌ها", icon: Ticket },
  { href: "/play", label: "بازی", icon: Play, primary: true },
  { href: "/wallet", label: "کیف پول", icon: Wallet },
  { href: "/profile", label: "پروفایل", icon: User },
];

function NavLink({
  href,
  label,
  icon: Icon,
  active,
  badge,
}: {
  href: string;
  label: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  active: boolean;
  badge?: number;
}) {
  return (
    <Link
      href={href}
      aria-current={active ? "page" : undefined}
      className={cn(
        "group relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] font-semibold transition-all",
        active
          ? "bg-cyan/12 text-cyan-hot"
          : "text-ink-dim hover:bg-raised/60 hover:text-ink-soft",
      )}
    >
      <span
        className={cn(
          "absolute right-0 top-1/2 h-6 w-[3px] -translate-y-1/2 rounded-full bg-cyan-hot transition-all",
          active ? "opacity-100 shadow-[0_0_12px_2px_rgba(94,233,255,0.6)]" : "opacity-0",
        )}
      />
      <Icon size={17} />
      <span className="flex-1">{label}</span>
      {!!badge && badge > 0 && (
        <span className="rounded-full bg-orange/20 px-1.5 py-0.5 font-mono text-[10px] font-bold text-orange-soft">
          {badge}
        </span>
      )}
    </Link>
  );
}

export default function AppShell({
  user,
  unread,
  children,
}: {
  user: ShellUser;
  unread: number;
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const [menuOpen, setMenuOpen] = useState(false);
  const [drawer, setDrawer] = useState(false);
  const { market } = useMarket();
  const cd = useCountdown(market?.closeTime);
  const isPlay = pathname === "/play";

  const logout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/");
    router.refresh();
  };

  return (
    <div className="min-h-dvh">
      {/* ============ SIDEBAR (desktop) ============ */}
      <aside className="fixed inset-y-0 right-0 z-40 hidden w-[248px] flex-col border-l border-hairline bg-abyss/70 backdrop-blur-xl lg:flex">
        <div className="flex h-16 items-center px-5">
          <Link href="/dashboard" aria-label="BTC6">
            <Btc6Logo />
          </Link>
        </div>
        <div className="hairline-x mx-5" />
        <nav aria-label="ناوبری اصلی" className="flex-1 space-y-1 overflow-y-auto p-3">
          <p className="px-3 pb-2 pt-3 font-mono text-[9px] tracking-[0.3em] text-ink-dim/70">
            PLAYER · MENU
          </p>
          {NAV.map((n) => (
            <NavLink
              key={n.href}
              {...n}
              active={pathname === n.href}
              badge={n.href === "/notifications" ? unread : undefined}
            />
          ))}
          <p className="px-3 pb-2 pt-5 font-mono text-[9px] tracking-[0.3em] text-ink-dim/70">SYSTEM</p>
          <NavLink href="/rules" label="قوانین بازی" icon={ScrollText} active={false} />
          <NavLink href="/terms" label="قوانین و حریم خصوصی" icon={ShieldCheck} active={false} />
          <button
            onClick={logout}
            className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] font-semibold text-ink-dim transition-all hover:bg-loss/10 hover:text-loss"
          >
            <LogOut size={17} />
            خروج از حساب
          </button>
        </nav>

        <div className="p-3">
          <div className="clip-notch border border-hairline bg-deep/70 p-3.5">
            <p className="font-mono text-[9px] tracking-[0.26em] text-ink-dim">NEXT DRAW</p>
            <p className="mt-1 font-num text-2xl font-bold text-cyan-hot text-glow-cyan" dir="ltr">
              {cd.hours}:{cd.minutes}:{cd.seconds}
            </p>
            <div className="mt-2.5 h-1 overflow-hidden rounded-full bg-raised">
              <div
                className="h-full rounded-full bg-gradient-to-l from-cyan-hot to-cyan transition-all duration-1000"
                style={{ width: `${Math.round((market?.progress ?? 0) * 100)}%` }}
              />
            </div>
            <p className="mt-2 font-mono text-[9.5px] text-ink-dim">
              ROUND #{market?.roundNumber ?? "—"}
            </p>
          </div>
        </div>
      </aside>

      {/* ============ TOP BAR ============ */}
      <header className="sticky top-0 z-30 border-b border-hairline bg-abyss/80 backdrop-blur-xl lg:pr-[248px]">
        <div className="flex h-16 items-center gap-3 px-4 sm:px-6">
          <button
            onClick={() => setDrawer(true)}
            className="grid h-9 w-9 place-items-center rounded-lg border border-hairline text-ink-soft lg:hidden"
            aria-label="منوی اصلی"
          >
            <Menu size={17} />
          </button>
          <Link href="/dashboard" className="lg:hidden" aria-label="BTC6">
            <Btc6Logo compact />
          </Link>

          {/* live market ticker */}
          <div className="hidden items-center gap-4 rounded-xl border border-hairline bg-deep/60 px-4 py-2 md:flex">
            <span className="font-mono text-[10px] tracking-[0.2em] text-ink-dim">BTC/USDT</span>
            <span className="font-num text-[15px] font-bold text-ink" dir="ltr">
              {market ? money(market.price) : "—"}
            </span>
            <span
              className={cn(
                "font-num text-[11.5px] font-bold",
                (market?.changePct ?? 0) >= 0 ? "text-win" : "text-loss",
              )}
              dir="ltr"
            >
              {market ? `${market.changePct >= 0 ? "+" : ""}${market.changePct.toFixed(2)}%` : "—"}
            </span>
            <span className="h-4 w-px bg-hairline" />
            <StatusBadge status="live" label="۱H LIVE" />
          </div>

          <div className="flex-1" />

          <Link
            href="/wallet"
            className="clip-notch group flex items-center gap-2.5 border border-hairline bg-deep/70 px-3.5 py-2 transition-colors hover:border-cyan/40"
          >
            <span className="font-mono text-[9px] tracking-[0.2em] text-ink-dim">BAL</span>
            <span className="font-num text-[13.5px] font-bold text-ink" dir="ltr">
              {money(user.balance)}
            </span>
            <span className="font-mono text-[9.5px] text-cyan-hot">USDT</span>
          </Link>

          <Link
            href="/notifications"
            className="relative grid h-9 w-9 place-items-center rounded-lg border border-hairline text-ink-soft transition-colors hover:border-cyan/40 hover:text-cyan-hot"
            aria-label={`اعلان‌ها${unread ? `، ${unread} خوانده‌نشده` : ""}`}
          >
            <Bell size={16} />
            {unread > 0 && (
              <span className="absolute -right-1 -top-1 grid h-4 min-w-4 place-items-center rounded-full bg-orange px-1 font-mono text-[9px] font-bold text-[#241300]">
                {unread}
              </span>
            )}
          </Link>

          <div className="relative">
            <button
              onClick={() => setMenuOpen((v) => !v)}
              aria-expanded={menuOpen}
              aria-haspopup="menu"
              className="flex items-center gap-2 rounded-xl border border-hairline bg-deep/70 px-2.5 py-1.5 transition-colors hover:border-cyan/40"
            >
              <span className="grid h-7 w-7 place-items-center rounded-lg bg-gradient-to-br from-cyan-hot to-cyan-deep font-disp text-[12px] font-bold text-void">
                {user.username.slice(0, 1).toUpperCase()}
              </span>
              <span className="hidden text-[12.5px] font-semibold text-ink sm:block">{user.username}</span>
              <ChevronDown size={13} className="text-ink-dim" />
            </button>
            {menuOpen && (
              <>
                <button className="fixed inset-0 z-10 cursor-default" aria-hidden tabIndex={-1} onClick={() => setMenuOpen(false)} />
                <div
                  role="menu"
                  className="surface clip-cyber absolute left-0 top-12 z-20 w-52 p-2 animate-[riseIn_0.2s_ease-out]"
                >
                  <div className="border-b border-hairline px-3 py-2.5">
                    <p className="text-[13px] font-bold text-ink">{user.username}</p>
                    <p className="font-mono text-[10px] text-ink-dim">{user.email}</p>
                  </div>
                  <Link
                    href="/profile"
                    role="menuitem"
                    onClick={() => setMenuOpen(false)}
                    className="flex items-center gap-2.5 rounded-lg px-3 py-2 text-[12.5px] text-ink-soft hover:bg-cyan/10 hover:text-cyan-hot"
                  >
                    <User size={15} />
                    پروفایل و تنظیمات
                  </Link>
                  <Link
                    href="/wallet/deposit"
                    role="menuitem"
                    onClick={() => setMenuOpen(false)}
                    className="flex items-center gap-2.5 rounded-lg px-3 py-2 text-[12.5px] text-ink-soft hover:bg-cyan/10 hover:text-cyan-hot"
                  >
                    <ArrowLeftRight size={15} />
                    واریز و برداشت
                  </Link>
                  <button
                    role="menuitem"
                    onClick={logout}
                    className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-[12.5px] text-loss/90 hover:bg-loss/10"
                  >
                    <LogOut size={15} />
                    خروج
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </header>

      {/* ============ MAIN ============ */}
      <main className="lg:pr-[248px]">
        <div className="mx-auto w-full max-w-[1180px] px-4 pb-28 pt-6 sm:px-6 lg:pb-12">
          {!isPlay && (
            <div className="pointer-events-none fixed bottom-24 left-6 z-20 hidden xl:block">
              <div className="clip-notch flex items-center gap-2 border border-hairline bg-abyss/80 px-3 py-2 font-mono text-[9.5px] tracking-[0.2em] text-ink-dim backdrop-blur">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-win" />
                FEED · {market?.source === "binance" ? "BINANCE" : "BTC6 SIM"}
              </div>
            </div>
          )}
          {children}
        </div>
      </main>

      {/* ============ BOTTOM NAV (mobile) ============ */}
      <nav
        aria-label="ناوبری موبایل"
        className="fixed inset-x-0 bottom-0 z-40 border-t border-hairline bg-abyss/92 pb-[env(safe-area-inset-bottom)] backdrop-blur-xl lg:hidden"
      >
        <ul className="flex items-stretch">
          {BOTTOM.map((item) => {
            const active = pathname === item.href;
            if (item.primary) {
              return (
                <li key={item.href} className="flex-1">
                  <Link
                    href={item.href}
                    className="-mt-5 flex flex-col items-center gap-1"
                    aria-current={active ? "page" : undefined}
                  >
                    <span
                      className={cn(
                        "grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-b from-cyan-hot to-cyan text-void shadow-[0_0_26px_-6px_rgba(34,211,238,0.9)]",
                        active && "ring-2 ring-cyan-hot/60",
                      )}
                    >
                      <item.icon size={21} />
                    </span>
                    <span className={cn("text-[10px] font-bold", active ? "text-cyan-hot" : "text-ink-dim")}>
                      {item.label}
                    </span>
                  </Link>
                </li>
              );
            }
            return (
              <li key={item.href} className="flex-1">
                <Link
                  href={item.href}
                  aria-current={active ? "page" : undefined}
                  className={cn(
                    "flex flex-col items-center gap-1.5 py-2.5 transition-colors",
                    active ? "text-cyan-hot" : "text-ink-dim",
                  )}
                >
                  <item.icon size={19} />
                  <span className="text-[9.5px] font-semibold">{item.label}</span>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* ============ MOBILE DRAWER ============ */}
      {drawer && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <button
            aria-label="بستن منو"
            className="absolute inset-0 bg-void/80 backdrop-blur-sm"
            onClick={() => setDrawer(false)}
          />
          <div className="absolute inset-y-0 right-0 flex w-[80%] max-w-xs flex-col border-l border-hairline bg-abyss p-4 animate-[riseIn_0.25s_ease-out]">
            <div className="mb-4 flex items-center justify-between">
              <Btc6Logo />
              <button
                onClick={() => setDrawer(false)}
                aria-label="بستن"
                className="grid h-9 w-9 place-items-center rounded-lg border border-hairline text-ink-dim"
              >
                <X size={16} />
              </button>
            </div>
            <div className="hairline-x mb-3" />
            <nav className="flex-1 space-y-1 overflow-y-auto">
              {NAV.map((n) => (
                <Link
                  key={n.href}
                  href={n.href}
                  onClick={() => setDrawer(false)}
                  className={cn(
                    "flex items-center gap-3 rounded-xl px-3 py-3 text-[13.5px] font-semibold",
                    pathname === n.href ? "bg-cyan/12 text-cyan-hot" : "text-ink-soft",
                  )}
                >
                  <n.icon size={18} />
                  {n.label}
                </Link>
              ))}
            </nav>
            <ButtonLink href="/play" size="lg" className="w-full" onClick={() => setDrawer(false)}>
              ورود به بازی BTC6
            </ButtonLink>
          </div>
        </div>
      )}
    </div>
  );
}
