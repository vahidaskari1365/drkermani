"use client";

import { motion } from "framer-motion";
import { cn, money } from "@/lib/utils";
import { COLOR_FA } from "@/lib/game";

export type TicketData = {
  code: string;
  roundNumber: number;
  open: string;
  high: string;
  close: string;
  color: string;
  price: string | number;
  status: string;
  payout?: string | number | null;
  matches?: number | null;
  closeTime?: string | null;
  result?: { open: string; high: string; close: string; color: string } | null;
};

const colorChip: Record<string, string> = {
  GREEN: "border-win/50 bg-win/15 text-win",
  RED: "border-loss/50 bg-loss/15 text-loss",
  WHITE: "border-ink/30 bg-ink/10 text-ink",
};

function Digits({ value, result, tone }: { value: string; result?: string; tone?: "win" | "loss" }) {
  return (
    <div className="flex gap-1.5" dir="ltr">
      {[0, 1].map((i) => {
        const hit = result ? result[i] === value[i] : null;
        return (
          <span
            key={i}
            className={cn(
              "grid h-11 w-9 place-items-center rounded-md border font-num text-[19px] font-bold transition-colors",
              hit === null
                ? "border-cyan/30 bg-cyan/8 text-cyan-hot"
                : hit
                  ? "border-win/60 bg-win/18 text-win shadow-[0_0_18px_-4px_rgba(22,227,154,0.8)]"
                  : "border-loss/35 bg-loss/10 text-loss/70",
              tone === "win" && hit === null && "border-win/40 text-win",
            )}
          >
            {value[i] ?? "–"}
          </span>
        );
      })}
    </div>
  );
}

export default function DigitalTicket({
  ticket,
  variant = "full",
  className,
}: {
  ticket: TicketData;
  variant?: "full" | "compact";
  className?: string;
}) {
  const won = ticket.status === "won";
  const lost = ticket.status === "lost";
  const settled = won || lost;

  return (
    <motion.div
      initial={{ opacity: 0, y: 22, rotateX: 8 }}
      animate={{ opacity: 1, y: 0, rotateX: 0 }}
      transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
      className={cn("relative w-full", className)}
      style={{ perspective: 1200 }}
    >
      <div
        className={cn(
          "clip-cyber relative overflow-hidden border bg-[linear-gradient(135deg,#0b1425_0%,#070d18_55%,#0b1120_100%)]",
          won ? "border-win/50 glow-win" : lost ? "border-loss/25" : "border-cyan/25 glow-cyan",
        )}
      >
        {/* holographic sweep */}
        <motion.span
          aria-hidden
          className="pointer-events-none absolute inset-0 bg-[linear-gradient(105deg,transparent_35%,rgba(94,233,255,0.14)_48%,rgba(247,147,26,0.08)_55%,transparent_70%)] bg-[length:250%_100%]"
          animate={{ backgroundPosition: ["200% 0%", "-60% 0%"] }}
          transition={{ duration: 5.5, repeat: Infinity, ease: "linear" }}
        />
        {/* perforation rail */}
        <span aria-hidden className="absolute inset-y-0 left-[74px] w-px bg-[repeating-linear-gradient(180deg,transparent_0_6px,rgba(94,233,255,0.28)_6px_12px)]" />

        {/* header */}
        <div className="flex items-center justify-between border-b border-hairline bg-void/40 px-4 py-2.5">
          <div className="flex items-center gap-2.5" dir="ltr">
            <span className="font-disp text-[13px] font-bold tracking-[0.18em] text-ink">
              BTC<span className="text-cyan-hot">6</span>
            </span>
            <span className="font-mono text-[9px] tracking-[0.24em] text-ink-dim">// TICKET</span>
          </div>
          <span className="font-mono text-[9.5px] tracking-[0.18em] text-ink-dim" dir="ltr">
            #{ticket.code}
          </span>
        </div>

        <div className="flex">
          {/* stub */}
          <div className="flex w-[74px] shrink-0 flex-col items-center justify-center gap-1 border-l border-hairline bg-void/25 py-4">
            <span className="font-mono text-[8px] tracking-[0.2em] text-ink-dim">DRAW</span>
            <span className="font-num text-[15px] font-bold text-cyan-hot" dir="ltr">
              #{ticket.roundNumber}
            </span>
            <svg width="30" height="42" aria-hidden className="mt-1 opacity-70">
              {Array.from({ length: 14 }).map((_, i) => (
                <rect
                  key={i}
                  x={i % 2 === 0 ? 0 : 16}
                  y={i * 3}
                  width={i % 3 === 0 ? 14 : 8}
                  height="1.6"
                  fill={i % 4 === 0 ? "#f7931a" : "rgba(94,233,255,0.7)"}
                />
              ))}
            </svg>
          </div>

          {/* body */}
          <div className="min-w-0 flex-1 p-4">
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
              {(
                [
                  ["OPEN", ticket.open, ticket.result?.open],
                  ["HIGH", ticket.high, ticket.result?.high],
                  ["CLOSE", ticket.close, ticket.result?.close],
                ] as const
              ).map(([label, val, res]) => (
                <div key={label}>
                  <p className="mb-2 font-mono text-[9px] tracking-[0.24em] text-ink-dim">{label}</p>
                  <Digits value={val} result={res} />
                </div>
              ))}
              <div>
                <p className="mb-2 font-mono text-[9px] tracking-[0.24em] text-ink-dim">COLOR</p>
                <div
                  className={cn(
                    "flex h-11 items-center justify-center gap-1.5 rounded-md border font-mono text-[11px] font-bold tracking-wider",
                    colorChip[ticket.color] ?? colorChip.WHITE,
                  )}
                  dir="ltr"
                >
                  <span className="h-2 w-2 rounded-full bg-current" />
                  {ticket.color}
                </div>
                {ticket.result && ticket.result.color !== ticket.color && (
                  <p className="mt-1.5 font-mono text-[9px] text-loss/70" dir="ltr">
                    → {ticket.result.color}
                  </p>
                )}
              </div>
            </div>

            <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-hairline pt-3.5">
              <div className="flex items-center gap-4">
                <div>
                  <p className="font-mono text-[8.5px] tracking-[0.22em] text-ink-dim">TICKET</p>
                  <p className="font-num text-[14px] font-bold text-orange-soft" dir="ltr">
                    {money(ticket.price)} <span className="text-[9px]">USDT</span>
                  </p>
                </div>
                {settled && (
                  <div>
                    <p className="font-mono text-[8.5px] tracking-[0.22em] text-ink-dim">PRIZE</p>
                    <p
                      className={cn(
                        "font-num text-[14px] font-bold",
                        won ? "text-win" : "text-loss/70",
                      )}
                      dir="ltr"
                    >
                      {won ? money(ticket.payout ?? 0) : "0.00"} <span className="text-[9px]">USDT</span>
                    </p>
                  </div>
                )}
              </div>
              <span
                className={cn(
                  "clip-notch border px-3 py-1.5 font-mono text-[10px] font-bold tracking-[0.2em]",
                  won
                    ? "border-win/50 bg-win/15 text-win"
                    : lost
                      ? "border-loss/40 bg-loss/12 text-loss"
                      : "border-cyan/40 bg-cyan/12 text-cyan-hot animate-pulse-ring",
                )}
                dir="ltr"
              >
                {won ? "★ WINNER" : lost ? "NO WIN" : "ACTIVE"}
              </span>
            </div>

            {variant === "full" && (
              <p className="mt-3 font-mono text-[9px] leading-relaxed tracking-[0.14em] text-ink-dim/80">
                {settled
                  ? `کاندل پایانی: ${ticket.result?.open ?? "?"} / ${ticket.result?.high ?? "?"} / ${ticket.result?.close ?? "?"} · رنگ ${COLOR_FA[ticket.result?.color ?? ""] ?? "—"}`
                  : "پیش‌بینی شما قفل شد و تا پایان کندل یک‌ساعته معتبر است."}
              </p>
            )}
          </div>
        </div>

        {won && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 1, 0.65, 1] }}
            transition={{ duration: 2.2, repeat: Infinity, repeatType: "reverse" }}
            className="pointer-events-none absolute inset-0 bg-[radial-gradient(80%_60%_at_50%_0%,rgba(22,227,154,0.16),transparent_70%)]"
          />
        )}
      </div>
    </motion.div>
  );
}
