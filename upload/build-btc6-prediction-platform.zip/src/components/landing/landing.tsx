"use client";

import { useRef } from "react";
import Link from "next/link";
import { motion, useScroll, useTransform, useSpring, useInView } from "framer-motion";
import { useEffect, useRef as R, useState as S } from "react";
import {
  Ticket, Zap, ChevronDown, ShieldCheck, Clock, Gauge, Wallet,
  Trophy, Layers, ArrowLeft, Activity, Lock, Sparkles,
} from "lucide-react";
import { ButtonLink } from "@/components/ui";
import CandleChart from "@/components/game/candle-chart";
import DigitalTicket from "@/components/game/digital-ticket";
import { PRIZE_TIERS } from "@/lib/game";
import { money } from "@/lib/utils";
import { useMarket, useCountdown } from "@/lib/useLive";
import type { Candle } from "@/lib/market";

/* ---------------------------- reveal wrapper ---------------------------- */
function Reveal({
  children,
  delay = 0,
  y = 30,
  className,
}: {
  children: React.ReactNode;
  delay?: number;
  y?: number;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-12% 0px -12% 0px" });
  return (
    <motion.div
      ref={ref}
      className={className}
      initial={{ opacity: 0, y, filter: "blur(6px)" }}
      animate={inView ? { opacity: 1, y: 0, filter: "blur(0px)" } : {}}
      transition={{ duration: 0.85, delay, ease: [0.16, 1, 0.3, 1] }}
    >
      {children}
    </motion.div>
  );
}

function Counter({ to, suffix = "", decimals = 0 }: { to: number; suffix?: string; decimals?: number }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });
  const [v, setV] = S(0);
  useEffect(() => {
    if (!inView) return;
    let raf = 0;
    const t0 = performance.now();
    const step = (t: number) => {
      const p = Math.min(1, (t - t0) / 1500);
      setV(to * (1 - Math.pow(1 - p, 3)));
      if (p < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [inView, to]);
  return (
    <span ref={ref} dir="ltr" className="font-num">
      {v.toLocaleString("en-US", { maximumFractionDigits: decimals, minimumFractionDigits: decimals })}
      {suffix}
    </span>
  );
}

/* ============================== HERO ============================== */
function Hero({
  candles,
  loggedIn,
  ticker,
}: {
  candles: Candle[];
  loggedIn: boolean;
  ticker: string[];
}) {
  const wrap = R<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: wrap, offset: ["start start", "end start"] });
  const sp = useSpring(scrollYProgress, { stiffness: 90, damping: 24, mass: 0.4 });

  const titleY = useTransform(sp, [0, 1], [0, -120]);
  const titleOpacity = useTransform(sp, [0, 0.7], [1, 0]);
  const chartY = useTransform(sp, [0, 1], [0, 140]);
  const chartScale = useTransform(sp, [0, 1], [1, 1.14]);
  const gridY = useTransform(sp, [0, 1], [0, -80]);

  const { market } = useMarket();
  const cd = useCountdown(market?.closeTime);

  const words = ["شش", "رقم", "و", "یک", "رنگ"];

  return (
    <section ref={wrap} className="relative min-h-[100svh] overflow-hidden pt-16">
      {/* parallax grid band */}
      <motion.div style={{ y: gridY }} className="pointer-events-none absolute inset-0 -z-[1]">
        <div className="absolute inset-x-0 top-1/2 h-[420px] -translate-y-1/2 grid-floor opacity-60 [mask-image:radial-gradient(60%_60%_at_50%_50%,#000_20%,transparent_75%)]" />
      </motion.div>

      {/* ambient candles behind everything */}
      <motion.div
        style={{ y: chartY, scale: chartScale }}
        className="pointer-events-none absolute inset-x-0 top-24 -z-[1] opacity-[0.35] blur-[1px]"
      >
        <CandleChart candles={candles} height={300} animate={false} />
      </motion.div>

      <div className="mx-auto grid w-full max-w-[1240px] items-center gap-10 px-4 pb-24 pt-14 sm:px-6 lg:grid-cols-[1.08fr_0.92fr] lg:pt-24">
        {/* ---------- copy ---------- */}
        <motion.div style={{ y: titleY, opacity: titleOpacity }}>
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7 }}
            className="clip-notch mb-7 inline-flex items-center gap-2.5 border border-cyan/25 bg-cyan/8 px-3.5 py-2"
          >
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-cyan-hot" />
            <span className="font-mono text-[10px] tracking-[0.24em] text-cyan-hot">
              BTC/USDT · 1H CANDLE · LIVE
            </span>
          </motion.div>

          <h1 className="text-[clamp(2.4rem,7vw,4.6rem)] font-black leading-[1.05] tracking-tight text-ink">
            {words.map((w, i) => (
              <motion.span
                key={w + i}
                initial={{ opacity: 0, y: 46, filter: "blur(10px)" }}
                animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                transition={{ duration: 0.9, delay: 0.15 + i * 0.09, ease: [0.16, 1, 0.3, 1] }}
                className="ml-[0.28em] inline-block"
              >
                {w}
              </motion.span>
            ))}
            <motion.span
              initial={{ opacity: 0, scale: 0.85 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.9, delay: 0.7 }}
              className="mt-3 block bg-gradient-to-l from-cyan-hot via-cyan to-orange-soft bg-clip-text text-[clamp(2.6rem,8vw,5.4rem)] font-black leading-none text-transparent"
            >
              آینده‌ی کندل بعدی
            </motion.span>
          </h1>

          <motion.p
            initial={{ opacity: 0, y: 22 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.85 }}
            className="mt-6 max-w-xl text-[14.5px] leading-[2] text-ink-soft"
          >
            در BTC6 دو رقم آخر <span className="font-mono text-cyan-hot">OPEN</span> و{" "}
            <span className="font-mono text-cyan-hot">HIGH</span> و{" "}
            <span className="font-mono text-cyan-hot">CLOSE</span> کندل یک‌ساعته بیت‌کوین را پیش‌بینی کن،
            رنگ کندل را انتخاب کن و یک بلیط دیجیتال بگیر. نتیجه با بسته‌شدن کندل، شفاف و قابل‌راستی‌آزمایی
            مشخص می‌شود.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 22 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 1 }}
            className="mt-9 flex flex-wrap items-center gap-3"
          >
            <ButtonLink href={loggedIn ? "/play" : "/register"} size="xl">
              <Zap size={17} />
              ورود به BTC6
            </ButtonLink>
            <ButtonLink href="/how-it-works" variant="outline" size="xl">
              چطور کار می‌کند
              <ArrowLeft size={16} />
            </ButtonLink>
          </motion.div>

          <motion.dl
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 1.2 }}
            className="mt-12 grid max-w-lg grid-cols-3 gap-4 border-t border-hairline pt-6"
          >
            {[
              ["بیشترین جایزه", "×۱۰۰۰", Trophy],
              ["مدت هر کشش", "۶۰ دقیقه", Clock],
              ["قیمت هر بلیط", "۱۰ USDT", Ticket],
            ].map(([label, value, Icon]) => {
              const I = Icon as typeof Clock;
              return (
                <div key={label as string}>
                  <dt className="mb-1.5 flex items-center gap-1.5 font-mono text-[9px] tracking-[0.16em] text-ink-dim">
                    <I size={12} className="text-cyan/70" />
                    {label as string}
                  </dt>
                  <dd className="font-num text-[17px] font-bold text-ink">{value as string}</dd>
                </div>
              );
            })}
          </motion.dl>
        </motion.div>

        {/* ---------- live console ---------- */}
        <motion.div
          initial={{ opacity: 0, x: -40, rotateY: 14 }}
          animate={{ opacity: 1, x: 0, rotateY: 0 }}
          transition={{ duration: 1.1, delay: 0.45, ease: [0.16, 1, 0.3, 1] }}
          style={{ perspective: 1200 }}
          className="relative"
        >
          <div className="surface clip-cyber relative overflow-hidden p-5 glow-cyan">
            <div className="mb-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="h-2 w-2 animate-pulse rounded-full bg-win" />
                <span className="font-mono text-[10px] tracking-[0.2em] text-ink-soft">BTC/USDT · 1H</span>
              </div>
              <span className="font-mono text-[9.5px] tracking-[0.18em] text-ink-dim" dir="ltr">
                ROUND #{market?.roundNumber ?? "—"}
              </span>
            </div>

            <div className="mb-4 flex items-end justify-between gap-3">
              <div>
                <p className="font-mono text-[9px] tracking-[0.22em] text-ink-dim">LIVE PRICE</p>
                <p className="font-num text-[30px] font-bold leading-tight text-ink text-glow-cyan" dir="ltr">
                  {market ? money(market.price) : "—"}
                </p>
              </div>
              <p
                className={`font-num text-[13px] font-bold ${(market?.changePct ?? 0) >= 0 ? "text-win" : "text-loss"}`}
                dir="ltr"
              >
                {market ? `${market.changePct >= 0 ? "▲" : "▼"} ${Math.abs(market.changePct).toFixed(2)}%` : "—"}
              </p>
            </div>

            <div className="clip-notch mb-4 border border-hairline bg-void/50 p-3">
              <CandleChart candles={candles.slice(-30)} height={140} />
            </div>

            <div className="grid grid-cols-3 gap-2.5">
              {[
                ["OPEN", market ? money(market.open) : "—"],
                ["HIGH", market ? money(market.high) : "—"],
                ["LOW", market ? money(market.low) : "—"],
              ].map(([l, v]) => (
                <div key={l} className="clip-notch border border-hairline bg-void/40 px-3 py-2.5">
                  <p className="font-mono text-[8.5px] tracking-[0.2em] text-ink-dim">{l}</p>
                  <p className="mt-1 font-num text-[13px] font-bold text-ink-soft" dir="ltr">
                    {v}
                  </p>
                </div>
              ))}
            </div>

            <div className="mt-4 flex items-center justify-between border-t border-hairline pt-4">
              <div>
                <p className="font-mono text-[9px] tracking-[0.22em] text-ink-dim">CANDLE CLOSES IN</p>
                <p className="font-num text-[24px] font-bold text-cyan-hot" dir="ltr">
                  {cd.hours}:{cd.minutes}:{cd.seconds}
                </p>
              </div>
              <div className="relative h-16 w-16">
                <svg viewBox="0 0 40 40" className="h-16 w-16 -rotate-90">
                  <circle cx="20" cy="20" r="17" fill="none" stroke="rgba(94,233,255,0.12)" strokeWidth="2.5" />
                  <circle
                    cx="20"
                    cy="20"
                    r="17"
                    fill="none"
                    stroke="#5fe9ff"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    strokeDasharray={`${Math.round((market?.progress ?? 0) * 107)} 107`}
                  />
                </svg>
                <span className="absolute inset-0 grid place-items-center font-num text-[11px] font-bold text-cyan-hot">
                  {Math.round((market?.progress ?? 0) * 100)}%
                </span>
              </div>
            </div>
          </div>

          <motion.div
            animate={{ y: [0, -10, 0] }}
            transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
            className="clip-notch absolute -bottom-6 -left-4 hidden items-center gap-3 border border-orange/30 bg-abyss/95 px-4 py-3 backdrop-blur sm:flex"
          >
            <Sparkles size={16} className="text-orange-soft" />
            <div>
              <p className="font-mono text-[8.5px] tracking-[0.2em] text-ink-dim">LAST DRAW</p>
              <p className="font-num text-[13px] font-bold text-ink" dir="ltr">
                {ticker[0]?.replace("|", " · ") ?? "42 · 78 · 31 · GREEN"}
              </p>
            </div>
          </motion.div>
        </motion.div>
      </div>

      <motion.div
        style={{ opacity: titleOpacity }}
        className="absolute inset-x-0 bottom-6 flex flex-col items-center gap-2"
      >
        <span className="font-mono text-[9px] tracking-[0.3em] text-ink-dim">SCROLL</span>
        <motion.span animate={{ y: [0, 7, 0] }} transition={{ duration: 1.8, repeat: Infinity }}>
          <ChevronDown size={15} className="text-cyan/70" />
        </motion.span>
      </motion.div>
    </section>
  );
}

/* ========================= TICKER STRIP ========================= */
function TickerStrip({ items }: { items: string[] }) {
  const doubled = [...items, ...items];
  return (
    <div className="relative overflow-hidden border-y border-hairline bg-abyss/60 py-3">
      <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-24 bg-gradient-to-l from-void to-transparent" />
      <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-24 bg-gradient-to-r from-void to-transparent" />
      <div className="flex w-max animate-ticker gap-8" dir="ltr">
        {doubled.map((it, i) => {
          const [digits, color] = it.split("|");
          const c = color === "GREEN" ? "text-win" : color === "RED" ? "text-loss" : "text-ink-soft";
          return (
            <span key={i} className="flex shrink-0 items-center gap-2 font-mono text-[11px] tracking-[0.14em]">
              <span className="text-ink-dim">DRAW</span>
              <span className="text-cyan-hot">{digits}</span>
              <span className={`h-1.5 w-1.5 rounded-full bg-current ${c}`} />
            </span>
          );
        })}
      </div>
    </div>
  );
}

/* =================== STICKY ANATOMY (scroll story) =================== */
const STEPS = [
  { key: "open", label: "OPEN", fa: "دو رقم آخر قیمت بازشدن کندل", hint: "کندل ساعت X با چه قیمتی باز می‌شود؟" },
  { key: "high", label: "HIGH", fa: "دو رقم آخر بالاترین قیمت کندل", hint: "سقف قیمت در این یک ساعت چقدر است؟" },
  { key: "close", label: "CLOSE", fa: "دو رقم آخر قیمت بسته‌شدن کندل", hint: "کندل با چه قیمتی بسته می‌شود؟" },
  { key: "color", label: "COLOR", fa: "رنگ کندل را انتخاب کن", hint: "سبز، قرمز یا سفید (دودوجی)" },
];

function Anatomy() {
  const wrap = R<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: wrap, offset: ["start start", "end end"] });
  const sp = useSpring(scrollYProgress, { stiffness: 110, damping: 30 });
  const [step, setStep] = S(0);

  useEffect(() => {
    const unsub = sp.on("change", (v) => {
      setStep(Math.min(STEPS.length, Math.max(0, Math.floor(v * (STEPS.length + 0.999)))));
    });
    return () => unsub();
  }, [sp]);

  const values: Record<string, string[]> = {
    open: ["4", "2"],
    high: ["7", "8"],
    close: ["3", "1"],
  };

  const activeKey = STEPS[Math.min(step, STEPS.length - 1)].key;

  const box = (key: string, i: number, digits: string[]) => (
    <div key={key} className="min-w-0">
      <p className="mb-2.5 font-mono text-[9.5px] tracking-[0.26em] text-ink-dim">{key.toUpperCase()}</p>
      <div className="flex gap-2.5">
        {digits.map((d, idx) => {
          const active = step >= STEPS.findIndex((s) => s.key === key) + 1 && activeKey === key;
          const filled = step > STEPS.findIndex((s) => s.key === key) || activeKey === key;
          return (
            <motion.span
              key={idx}
              animate={{
                borderColor: active ? "rgba(94,233,255,0.85)" : "rgba(94,233,255,0.16)",
                boxShadow: active ? "0 0 30px -6px rgba(34,211,238,0.85)" : "0 0 0 rgba(0,0,0,0)",
                backgroundColor: active ? "rgba(34,211,238,0.14)" : "rgba(7,12,23,0.8)",
                scale: active ? 1.05 : 1,
              }}
              transition={{ duration: 0.5 }}
              className="grid h-16 w-13 place-items-center rounded-xl border font-num text-[28px] font-bold text-cyan-hot sm:h-20 sm:w-16 sm:text-[34px]"
            >
              {filled || activeKey === key ? d : "·"}
            </motion.span>
          );
        })}
      </div>
    </div>
  );

  const colors = [
    { key: "GREEN", label: "سبز", cls: "border-win bg-win/15 text-win" },
    { key: "RED", label: "قرمز", cls: "border-loss bg-loss/15 text-loss" },
    { key: "WHITE", label: "سفید", cls: "border-ink/40 bg-ink/10 text-ink" },
  ];

  return (
    <section ref={wrap} className="relative h-[420vh]">
      <div className="sticky top-0 flex h-[100svh] items-center overflow-hidden">
        <div className="mx-auto w-full max-w-[1240px] px-4 sm:px-6">
          <div className="grid items-center gap-12 lg:grid-cols-[0.85fr_1.15fr]">
            <div>
              <div className="mb-4 flex items-center gap-2 font-mono text-[10px] tracking-[0.3em] text-cyan/80">
                <span className="h-px w-6 bg-cyan/50" />
                ANATOMY OF A TICKET
              </div>
              <h2 className="text-[clamp(1.9rem,4.6vw,3rem)] font-black leading-tight text-ink">
                یک بلیط BTC6
                <br />
                <span className="text-cyan-hot text-glow-cyan">چطور ساخته می‌شود؟</span>
              </h2>

              <div className="mt-8 space-y-3">
                {STEPS.map((s, i) => {
                  const done = step > i;
                  const active = step === i;
                  return (
                    <motion.div
                      key={s.key}
                      animate={{
                        opacity: done || active ? 1 : 0.32,
                        x: active ? -8 : 0,
                        borderColor: active ? "rgba(94,233,255,0.4)" : "rgba(94,233,255,0.1)",
                      }}
                      transition={{ duration: 0.45 }}
                      className="clip-notch flex items-center gap-4 border bg-deep/50 px-4 py-3.5"
                    >
                      <span
                        className={`grid h-8 w-8 shrink-0 place-items-center rounded-lg font-num text-[12px] font-bold ${
                          done ? "bg-win/20 text-win" : active ? "bg-cyan/20 text-cyan-hot" : "bg-raised text-ink-dim"
                        }`}
                      >
                        {done ? "✓" : i + 1}
                      </span>
                      <div className="min-w-0">
                        <p className="font-mono text-[10px] tracking-[0.22em] text-cyan/80">{s.label}</p>
                        <p className="text-[13.5px] font-bold text-ink">{s.fa}</p>
                        <p className="mt-0.5 text-[11.5px] text-ink-dim">{s.hint}</p>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>

            {/* live ticket builder */}
            <div className="relative">
              <motion.div
                animate={{ rotateY: step > 0 ? 0 : 8, y: 0 }}
                transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
                className="surface clip-cyber relative overflow-hidden p-6"
              >
                <div className="mb-5 flex items-center justify-between border-b border-hairline pb-3.5">
                  <span className="font-disp text-[14px] font-bold tracking-[0.18em] text-ink" dir="ltr">
                    BTC<span className="text-cyan-hot">6</span> <span className="text-ink-dim">// BUILDER</span>
                  </span>
                  <span className="font-mono text-[9.5px] tracking-[0.18em] text-ink-dim" dir="ltr">
                    BTC6-8F3K2Q
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  {box("open", 0, values.open)}
                  {box("high", 1, values.high)}
                  {box("close", 2, values.close)}
                </div>

                <p className="mb-2.5 mt-6 font-mono text-[9.5px] tracking-[0.26em] text-ink-dim">COLOR</p>
                <div className="grid grid-cols-3 gap-2.5">
                  {colors.map((c, i) => {
                    const active = activeKey === "color" && step === 3 && i === 0;
                    return (
                      <motion.div
                        key={c.key}
                        animate={{
                          borderColor: active ? "rgba(22,227,154,0.8)" : "rgba(94,233,255,0.14)",
                          scale: active ? 1.03 : 1,
                        }}
                        className={`flex h-14 items-center justify-center gap-2 rounded-xl border font-mono text-[11px] font-bold tracking-wider ${c.cls}`}
                        dir="ltr"
                      >
                        <span className="h-2 w-2 rounded-full bg-current" />
                        {c.key}
                      </motion.div>
                    );
                  })}
                </div>

                <div className="mt-6 flex items-center justify-between border-t border-hairline pt-4">
                  <span className="font-mono text-[9px] tracking-[0.2em] text-ink-dim">TICKET</span>
                  <span className="font-num text-[18px] font-bold text-orange-soft" dir="ltr">
                    10.00 <span className="text-[10px]">USDT</span>
                  </span>
                  <motion.span
                    animate={{
                      opacity: step >= 4 ? 1 : 0.35,
                      boxShadow:
                        step >= 4 ? "0 0 26px -6px rgba(34,211,238,0.9)" : "0 0 0 rgba(0,0,0,0)",
                    }}
                    className="clip-notch border border-cyan/45 bg-cyan/14 px-3.5 py-2 font-mono text-[10px] font-bold tracking-[0.2em] text-cyan-hot"
                  >
                    CONFIRMED
                  </motion.span>
                </div>

                {/* progress rail */}
                <div className="mt-6 flex gap-1.5">
                  {STEPS.map((s, i) => (
                    <div key={s.key} className="h-1 flex-1 overflow-hidden rounded-full bg-raised">
                      <motion.div
                        animate={{ width: step > i ? "100%" : step === i ? "55%" : "0%" }}
                        transition={{ duration: 0.5 }}
                        className="h-full bg-gradient-to-l from-cyan-hot to-cyan"
                      />
                    </div>
                  ))}
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ========================= HOW IT WORKS ========================= */
const HOW = [
  {
    icon: Clock,
    n: "۰۱",
    title: "کندل را ببین",
    body: "کندل یک‌ساعته BTC/USDT به‌صورت زنده روی صفحه بازی نمایش داده می‌شود؛ قیمت لحظه‌ای، سقف، کف و زمان باقی‌مانده.",
  },
  {
    icon: Layers,
    n: "۰۲",
    title: "شش رقم و یک رنگ",
    body: "برای OPEN و HIGH و CLOSE هر کدام دو رقم (۰۰ تا ۹۹) انتخاب می‌کنی و رنگ کندل را از بین سبز، قرمز و سفید مشخص می‌کنی.",
  },
  {
    icon: Trophy,
    n: "۰۳",
    title: "بلیط بگیر و نتیجه را ببین",
    body: "پیش‌بینی ثبت می‌شود و بلیط دیجیتال BTC6 صادر می‌شود. با بسته‌شدن کندل، نتیجه به‌صورت خودکار و شفاف محاسبه می‌شود.",
  },
];

function HowItWorks() {
  return (
    <section className="relative py-24 sm:py-32">
      <div className="mx-auto w-full max-w-[1240px] px-4 sm:px-6">
        <Reveal>
          <div className="mb-14 max-w-2xl">
            <div className="mb-3 flex items-center gap-2 font-mono text-[10px] tracking-[0.3em] text-cyan/80">
              <span className="h-px w-6 bg-cyan/50" />
              PROTOCOL
            </div>
            <h2 className="text-[clamp(1.9rem,4.6vw,3rem)] font-black leading-tight text-ink">
              سه مرحله تا <span className="text-cyan-hot">کشش بعدی</span>
            </h2>
          </div>
        </Reveal>

        <div className="grid gap-5 md:grid-cols-3">
          {HOW.map((h, i) => (
            <Reveal key={h.n} delay={i * 0.12}>
              <article className="surface clip-cyber group relative h-full overflow-hidden p-6">
                <span className="pointer-events-none absolute -left-2 -top-5 font-num text-[86px] font-black text-cyan/8 transition-colors duration-500 group-hover:text-cyan/16">
                  {h.n}
                </span>
                <span className="relative grid h-12 w-12 place-items-center rounded-xl border border-cyan/25 bg-cyan/10 text-cyan-hot transition-all duration-500 group-hover:shadow-[0_0_26px_-6px_rgba(34,211,238,0.85)]">
                  <h.icon size={21} />
                </span>
                <h3 className="relative mt-5 text-[17px] font-extrabold text-ink">{h.title}</h3>
                <p className="relative mt-3 text-[13px] leading-[2] text-ink-soft">{h.body}</p>
                <span className="absolute inset-x-0 bottom-0 h-px shimmer-line opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ========================= PRIZE TABLE ========================= */
function Prizes() {
  return (
    <section className="relative py-24 sm:py-28">
      <div className="mx-auto w-full max-w-[1240px] px-4 sm:px-6">
        <div className="grid gap-12 lg:grid-cols-[0.9fr_1.1fr]">
          <Reveal>
            <div>
              <div className="mb-3 flex items-center gap-2 font-mono text-[10px] tracking-[0.3em] text-orange/90">
                <span className="h-px w-6 bg-orange/60" />
                PAYOUT MATRIX
              </div>
              <h2 className="text-[clamp(1.8rem,4.2vw,2.7rem)] font-black leading-tight text-ink">
                جدول جایزه‌ها
              </h2>
              <p className="mt-5 text-[13.5px] leading-[2] text-ink-soft">
                هر رقم در جایگاه خودش بررسی می‌شود. مثلاً اگر برای OPEN عدد <span className="font-mono text-cyan-hot">42</span> را
                انتخاب کنی و OPEN واقعی <span className="font-mono text-cyan-hot">47</span> باشد، یک رقم درست داری.
                رنگ کندل هم جایزه را تقویت می‌کند.
              </p>
              <div className="mt-7 grid grid-cols-2 gap-4">
                <div className="clip-notch border border-hairline bg-deep/50 p-4">
                  <p className="font-mono text-[9px] tracking-[0.2em] text-ink-dim">TICKET PRICE</p>
                  <p className="mt-1 font-num text-[22px] font-bold text-orange-soft" dir="ltr">
                    10 <span className="text-[10px]">USDT</span>
                  </p>
                </div>
                <div className="clip-notch border border-hairline bg-deep/50 p-4">
                  <p className="font-mono text-[9px] tracking-[0.2em] text-ink-dim">MAX PRIZE</p>
                  <p className="mt-1 font-num text-[22px] font-bold text-win" dir="ltr">
                    10,000 <span className="text-[10px]">USDT</span>
                  </p>
                </div>
              </div>
              <ButtonLink href="/rules" variant="outline" size="lg" className="mt-7">
                مطالعه کامل قوانین
                <ArrowLeft size={15} />
              </ButtonLink>
            </div>
          </Reveal>

          <div className="surface clip-cyber overflow-hidden p-2">
            <div className="overflow-hidden">
              <table className="w-full text-right">
                <thead>
                  <tr>
                    <th className="border-b border-hairline px-4 pb-3 pt-3 font-mono text-[9.5px] tracking-[0.18em] text-ink-dim">
                      TIER
                    </th>
                    <th className="border-b border-hairline px-4 pb-3 pt-3 font-mono text-[9.5px] tracking-[0.18em] text-ink-dim">
                      شرط
                    </th>
                    <th className="border-b border-hairline px-4 pb-3 pt-3 text-left font-mono text-[9.5px] tracking-[0.18em] text-ink-dim">
                      جایزه
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {PRIZE_TIERS.map((t, i) => (
                    <Reveal key={t.key} delay={i * 0.06} y={14}>
                      <tr className="group transition-colors hover:bg-cyan/6">
                        <td className="border-b border-hairline/60 px-4 py-4 text-[13px] font-bold text-ink">
                          {t.label}
                        </td>
                        <td className="border-b border-hairline/60 px-4 py-4 text-[12.5px] text-ink-soft">
                          {t.digits}
                          {t.color ? " + رنگ درست" : ""}
                        </td>
                        <td
                          className={`border-b border-hairline/60 px-4 py-4 text-left font-num text-[15px] font-bold ${
                            i === 0 ? "text-win" : i === 1 ? "text-cyan-hot" : "text-ink"
                          }`}
                          dir="ltr"
                        >
                          ×{t.multiplier}
                        </td>
                      </tr>
                    </Reveal>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ========================= TICKET SHOWCASE ========================= */
function TicketShowcase() {
  const wrap = R<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: wrap, offset: ["start end", "end start"] });
  const sp = useSpring(scrollYProgress, { stiffness: 80, damping: 22 });
  const rotate = useTransform(sp, [0, 0.5, 1], [10, 0, -8]);
  const y = useTransform(sp, [0, 1], [70, -70]);

  return (
    <section ref={wrap} className="relative py-24 sm:py-32">
      <div className="mx-auto w-full max-w-[1240px] px-4 sm:px-6">
        <Reveal className="mb-12 text-center">
          <div className="mb-3 font-mono text-[10px] tracking-[0.3em] text-cyan/80">THE ARTIFACT</div>
          <h2 className="text-[clamp(1.9rem,4.6vw,3rem)] font-black leading-tight text-ink">
            بلیط دیجیتال <span className="text-orange-soft text-glow-orange">BTC6</span>
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-[13.5px] leading-[2] text-ink-soft">
            هر پیش‌بینی به یک بلیط دیجیتال تبدیل می‌شود؛ قابل نگهداری، قابل بررسی و قابل نمایش. این بلیط
            رسید بانکی نیست — یک قطعه از آینده بازار است.
          </p>
        </Reveal>

        <motion.div style={{ rotate, y, perspective: 1400 }} className="mx-auto max-w-3xl">
          <DigitalTicket
            ticket={{
              code: "BTC6-8F3K2Q",
              roundNumber: 482193,
              open: "42",
              high: "78",
              close: "31",
              color: "GREEN",
              price: 10,
              status: "won",
              payout: 10000,
              matches: 6,
              result: { open: "42", high: "78", close: "31", color: "GREEN" },
            }}
          />
        </motion.div>

        <Reveal delay={0.15}>
          <div className="mx-auto mt-10 grid max-w-3xl gap-3 sm:grid-cols-3">
            {[
              [Lock, "قفل پیش‌بینی", "پس از ثبت، پیش‌بینی غیرقابل تغییر است."],
              [Activity, "نتیجه شفاف", "نتیجه مستقیماً از کندل واقعی استخراج می‌شود."],
              [Wallet, "پرداخت خودکار", "جایزه بلافاصله به کیف پول واریز می‌شود."],
            ].map(([Icon, t, b]) => {
              const I = Icon as typeof Lock;
              return (
                <div key={t as string} className="clip-notch border border-hairline bg-deep/45 p-4">
                  <I size={17} className="text-cyan-hot" />
                  <p className="mt-3 text-[13px] font-bold text-ink">{t as string}</p>
                  <p className="mt-1.5 text-[11.5px] leading-relaxed text-ink-dim">{b as string}</p>
                </div>
              );
            })}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ========================= TRUST + FINAL CTA ========================= */
function Trust() {
  return (
    <section className="relative py-20">
      <div className="mx-auto w-full max-w-[1240px] px-4 sm:px-6">
        <Reveal>
          <div className="grid gap-6 border-y border-hairline py-10 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { icon: Gauge, k: <Counter to={482193} />, l: "کشش‌های انجام‌شده" },
              { icon: Ticket, k: <Counter to={1284550} />, l: "بلیط صادرشده" },
              { icon: Trophy, k: <><Counter to={9420} /> USDT</>, l: "بیشترین جایزه یک بلیط" },
              { icon: ShieldCheck, k: <><Counter to={99.98} decimals={2} />%</>, l: "پایداری سرویس" },
            ].map((s, i) => (
              <div key={i} className="flex flex-col gap-2">
                <s.icon size={17} className="text-cyan/70" />
                <p className="font-num text-[24px] font-bold text-ink">{s.k}</p>
                <p className="text-[12px] text-ink-dim">{s.l}</p>
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function FinalCTA({ loggedIn }: { loggedIn: boolean }) {
  return (
    <section className="relative overflow-hidden py-28 sm:py-36">
      <div className="pointer-events-none absolute inset-0 grid-floor opacity-40 [mask-image:radial-gradient(50%_50%_at_50%_50%,#000,transparent_75%)]" />
      <motion.div
        animate={{ opacity: [0.35, 0.6, 0.35] }}
        transition={{ duration: 6, repeat: Infinity }}
        className="pointer-events-none absolute left-1/2 top-1/2 h-[420px] w-[420px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[radial-gradient(circle,rgba(34,211,238,0.18),transparent_65%)] blur-2xl"
      />
      <div className="relative mx-auto max-w-3xl px-4 text-center sm:px-6">
        <Reveal>
          <h2 className="text-[clamp(2rem,6vw,3.6rem)] font-black leading-[1.15] text-ink">
            کندل بعدی
            <br />
            <span className="bg-gradient-to-l from-cyan-hot to-orange-soft bg-clip-text text-transparent">
              دارد شروع می‌شود
            </span>
          </h2>
          <p className="mx-auto mt-6 max-w-lg text-[14px] leading-[2] text-ink-soft">
            هر ساعت یک فرصت تازه. شش رقم، یک رنگ، یک بلیط دیجیتال. آماده‌ای؟
          </p>
          <div className="mt-10 flex flex-wrap justify-center gap-3">
            <ButtonLink href={loggedIn ? "/play" : "/register"} size="xl">
              <Zap size={17} />
              ورود به BTC6
            </ButtonLink>
            <ButtonLink href="/faq" variant="ghost" size="xl">
              سوال داری؟
            </ButtonLink>
          </div>
          <p className="mt-8 font-mono text-[9.5px] tracking-[0.24em] text-ink-dim/70">
            ۱۸+ · بازی مهارتی پیش‌بینی · بدون نصب
          </p>
        </Reveal>
      </div>
    </section>
  );
}

/* ============================== ROOT ============================== */
export default function Landing({
  candles,
  ticker,
  loggedIn,
}: {
  candles: Candle[];
  ticker: string[];
  loggedIn: boolean;
}) {
  return (
    <>
      <Hero candles={candles} loggedIn={loggedIn} ticker={ticker} />
      <TickerStrip items={ticker} />
      <Anatomy />
      <HowItWorks />
      <Prizes />
      <TicketShowcase />
      <Trust />
      <FinalCTA loggedIn={loggedIn} />
      <div className="flex justify-center pb-16">
        <Link
          href="/how-it-works"
          className="font-mono text-[10px] tracking-[0.24em] text-ink-dim transition-colors hover:text-cyan-hot"
        >
          → مستندات کامل بازی
        </Link>
      </div>
    </>
  );
}
