import "server-only";
import { and, eq, lte, desc, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { rounds, tickets, transactions, notifications, users, type Round } from "@/db/schema";
import { getFeed, candleForRound, roundNumberFromTime, HOUR, type Candle, type FeedSource } from "@/lib/market";
import { TICKET_PRICE, lastTwo, candleColor, digitScore, multiplierFor } from "@/lib/game";
import { ticketCode, txReference } from "@/lib/utils";

export type RoundState = {
  round: Round;
  roundNumber: number;
  openTime: string;
  closeTime: string;
  candle: { open: number; high: number; low: number; close: number };
  source: FeedSource;
  progress: number;
  dOpen: string;
  dHigh: string;
  dClose: string;
};

function toState(round: Round, candle: Candle, source: FeedSource): RoundState {
  const now = Date.now();
  const start = new Date(round.openTime).getTime();
  const end = new Date(round.closeTime).getTime();
  return {
    round,
    roundNumber: round.roundNumber,
    openTime: new Date(round.openTime).toISOString(),
    closeTime: new Date(round.closeTime).toISOString(),
    candle: {
      open: candle.open,
      high: candle.high,
      low: candle.low,
      close: candle.close,
    },
    source,
    progress: Math.min(1, Math.max(0, (now - start) / (end - start))),
    dOpen: lastTwo(candle.open),
    dHigh: lastTwo(candle.high),
    dClose: lastTwo(candle.close),
  };
}

/** Insert any missing round rows for the given epoch-hour indices. */
async function ensureRounds(numbers: number[]): Promise<Map<number, Round>> {
  if (!numbers.length) return new Map();
  const existing = await db.select().from(rounds).where(inArray(rounds.roundNumber, numbers));
  const map = new Map<number, Round>();
  for (const r of existing) map.set(r.roundNumber, r);
  const missing = numbers.filter((n) => !map.has(n));
  if (!missing.length) return map;

  const feed = await getFeed(80);
  for (const n of missing) {
    const isPast = n < feed.currentRound;
    const hit = feed.closed.find((c) => roundNumberFromTime(c.openTime) === n);
    const candle = hit ?? (await candleForRound(n)).candle;
    const settled = isPast && !!hit;
    const inserted = await db
      .insert(rounds)
      .values({
        roundNumber: n,
        openTime: new Date(n * HOUR),
        closeTime: new Date((n + 1) * HOUR),
        ticketPrice: String(TICKET_PRICE),
        status: settled ? "settled" : "live",
        openPrice: settled ? String(candle.open) : null,
        highPrice: settled ? String(candle.high) : null,
        lowPrice: settled ? String(candle.low) : null,
        closePrice: settled ? String(candle.close) : null,
        dOpen: settled ? lastTwo(candle.open) : null,
        dHigh: settled ? lastTwo(candle.high) : null,
        dClose: settled ? lastTwo(candle.close) : null,
        candleColor: settled ? candleColor(candle.open, candle.close) : null,
        source: feed.source,
        settledAt: settled ? new Date((n + 1) * HOUR) : null,
      })
      .onConflictDoNothing()
      .returning();
    if (inserted[0]) map.set(n, inserted[0]);
  }
  return map;
}

export async function getCurrentRound(): Promise<RoundState> {
  const feed = await getFeed(1);
  const map = await ensureRounds([feed.currentRound]);
  const round = map.get(feed.currentRound)!;
  return toState(round, feed.live, feed.source);
}

export async function getRecentSettled(limit = 12): Promise<Round[]> {
  const feed = await getFeed(limit);
  const numbers = Array.from({ length: limit }, (_, i) => feed.currentRound - 1 - i);
  await ensureRounds(numbers);
  const rows = await db
    .select()
    .from(rounds)
    .where(inArray(rounds.roundNumber, numbers))
    .orderBy(desc(rounds.roundNumber));
  return rows.filter((r) => r.status === "settled").slice(0, limit);
}

export async function getRoundStateByNumber(n: number): Promise<RoundState | null> {
  const map = await ensureRounds([n]);
  const round = map.get(n);
  if (!round) return null;
  const { candle, source } = await candleForRound(n);
  return toState(round, candle, source);
}

export async function getChartSeries(limit = 48): Promise<{ candles: Candle[]; source: FeedSource }> {
  const feed = await getFeed(limit);
  return { candles: [...feed.closed.slice(-(limit - 1)), feed.live], source: feed.source };
}

/* ===================== SETTLEMENT ENGINE ===================== */

export async function settleDueRounds(): Promise<number> {
  const due = await db
    .select()
    .from(rounds)
    .where(and(eq(rounds.status, "live"), lte(rounds.closeTime, new Date())))
    .limit(4);
  let settledCount = 0;

  for (const round of due) {
    const { candle, source } = await candleForRound(round.roundNumber);
    const dOpen = lastTwo(candle.open);
    const dHigh = lastTwo(candle.high);
    const dClose = lastTwo(candle.close);
    const color = candleColor(candle.open, candle.close);

    await db
      .update(rounds)
      .set({
        status: "settled",
        openPrice: String(candle.open),
        highPrice: String(candle.high),
        lowPrice: String(candle.low),
        closePrice: String(candle.close),
        dOpen,
        dHigh,
        dClose,
        candleColor: color,
        source,
        settledAt: new Date(),
      })
      .where(eq(rounds.id, round.id));

    const openTickets = await db
      .select()
      .from(tickets)
      .where(and(eq(tickets.roundId, round.id), eq(tickets.status, "active")));

    for (const t of openTickets) {
      const score =
        digitScore(t.pOpen, dOpen) + digitScore(t.pHigh, dHigh) + digitScore(t.pClose, dClose);
      const colorMatch = t.pColor === color;
      const { multiplier } = multiplierFor(score, colorMatch);
      const payout = Math.round(Number(t.price) * multiplier * 100) / 100;
      const status = payout > 0 ? "won" : "lost";

      await db
        .update(tickets)
        .set({ status, matches: score, payout: String(payout), settledAt: new Date() })
        .where(eq(tickets.id, t.id));

      if (payout > 0) {
        const updated = await db
          .update(users)
          .set({ balance: sql`${users.balance} + ${payout}` })
          .where(eq(users.id, t.userId))
          .returning({ balance: users.balance });
        await db.insert(transactions).values({
          userId: t.userId,
          kind: "payout",
          amount: String(payout),
          status: "completed",
          reference: txReference("payout", t.id),
          note: `جایزه بلیط ${t.code}`,
          balanceAfter: updated[0]?.balance ?? null,
        });
        await db.insert(notifications).values({
          userId: t.userId,
          kind: "win",
          title: `برنده شدی! ${payout} USDT`,
          body: `بلیط ${t.code} با ${score} رقم درست و رنگ ${t.pColor === color ? "درست" : "نادرست"} برنده شد.`,
          href: `/tickets/${t.id}`,
        });
      } else {
        await db.insert(notifications).values({
          userId: t.userId,
          kind: "loss",
          title: `بلیط ${t.code} برنده نشد`,
          body: `کاندل پایانی ${dOpen} / ${dHigh} / ${dClose} و رنگ ${color} بود.`,
          href: `/tickets/${t.id}`,
        });
      }
    }
    settledCount += 1;
  }
  return settledCount;
}

export function newTicketCode(userId: number): string {
  return ticketCode(userId * 7919 + Date.now() % 100000);
}
