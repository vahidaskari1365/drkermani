import type { Metadata } from "next";
import { redirect } from "next/navigation";
import AuthForm from "@/components/auth-form";
import { currentUser } from "@/lib/auth";

export const metadata: Metadata = { title: "ثبت‌نام" };
export const dynamic = "force-dynamic";

export default async function RegisterPage() {
  const user = await currentUser().catch(() => null);
  if (user) redirect("/play");
  return <AuthForm mode="register" />;
}
