"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { ArrowDownToLine, ArrowUpFromLine, Copy, Check, AlertCircle, QrCode } from "lucide-react";
import { Button, Field, Input, Alert, Card, CardTitle } from "@/components/ui";
import { money } from "@/lib/utils";

const DEPOSIT_ADDRESS = "TQn9Y2khDD95J42FQtQTdwVVRZq5DemoBTC6";

function Presets({
  onPick,
  options,
}: {
  onPick: (v: number) => void;
  options: number[];
}) {
  return (
    <div className="flex flex-wrap gap-2">
      {options.map((v) => (
        <button
          key={v}
          type="button"
          onClick={() => onPick(v)}
          className="clip-notch border border-hairline bg-raised/60 px-3.5 py-2 font-num text-[12.5px] font-bold text-ink-soft transition-all hover:border-cyan/45 hover:bg-cyan/10 hover:text-cyan-hot"
        >
          {v.toLocaleString("en-US")}
        </button>
      ))}
    </div>
  );
}

export function DepositForm({ balance }: { balance: string }) {
  const router = useRouter();
  const [amount, setAmount] = useState("50");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [done, setDone] = useState(false);
  const [copied, setCopied] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/wallet", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action: "deposit", amount: Number(amount) }),
      });
      const json = (await res.json()) as { error?: string };
      if (!res.ok) {
        setError(json.error ?? "واریز ناموفق بود.");
        return;
      }
      setDone(true);
      router.refresh();
    } catch {
      setError("ارتباط با سرور برقرار نشد.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="grid gap-5 lg:grid-cols-[1.15fr_1fr]">
      <Card>
        <CardTitle kicker="DEPOSIT · USDT TRC20" icon={<ArrowDownToLine size={16} />}>
          واریز به کیف پول
        </CardTitle>
        <form onSubmit={submit} className="space-y-5">
          {error && (
            <div role="alert" className="clip-notch flex items-start gap-2.5 border border-loss/40 bg-loss/10 px-3.5 py-3 text-[12px] text-loss">
              <AlertCircle size={15} className="mt-0.5 shrink-0" />
              {error}
            </div>
          )}
          {done && (
            <Alert tone="success" title="واریز تأیید شد">
              موجودی کیف پول شما به‌روزرسانی شد.
            </Alert>
          )}
          <Field label="مبلغ واریز (USDT)" hint="حداقل ۱۰ USDT" htmlFor="amount">
            <Input
              id="amount"
              inputMode="decimal"
              required
              dir="ltr"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="50"
            />
          </Field>
          <Presets options={[10, 50, 100, 500, 1000]} onPick={(v) => setAmount(String(v))} />
          <div className="flex items-center justify-between border-t border-hairline pt-4">
            <span className="text-[12.5px] text-ink-dim">موجودی فعلی</span>
            <span className="font-num text-[14px] font-bold text-ink" dir="ltr">
              {money(balance)} USDT
            </span>
          </div>
          <Button type="submit" size="lg" loading={loading} disabled={loading} className="w-full">
            <ArrowDownToLine size={16} />
            تأیید واریز
          </Button>
        </form>
      </Card>

      <Card>
        <CardTitle kicker="WALLET ADDRESS" icon={<QrCode size={16} />}>
          آدرس واریز
        </CardTitle>
        <div className="grid place-items-center rounded-xl border border-hairline bg-void/50 p-5">
          <div className="grid grid-cols-8 gap-[3px]">
            {Array.from({ length: 64 }, (_, i) => {
              const on = (i * 7 + (i % 5) * 3) % 3 !== 0;
              return (
                <span key={i} className={`h-2.5 w-2.5 rounded-[1px] ${on ? "bg-cyan-hot" : "bg-raised/60"}`} />
              );
            })}
          </div>
        </div>
        <p className="mt-4 text-[12px] leading-relaxed text-ink-dim">
          تنها این آدرس را برای واریز تتر روی شبکه TRC20 استفاده کن. واریز روی شبکه‌های دیگر قابل بازیابی
          نیست.
        </p>
        <div className="mt-4 clip-notch flex items-center gap-2 border border-hairline bg-void/50 p-3">
          <code className="min-w-0 flex-1 truncate font-mono text-[11px] text-cyan-hot" dir="ltr">
            {DEPOSIT_ADDRESS}
          </code>
          <button
            onClick={() => {
              void navigator.clipboard?.writeText(DEPOSIT_ADDRESS);
              setCopied(true);
              window.setTimeout(() => setCopied(false), 1600);
            }}
            className="grid h-8 w-8 shrink-0 place-items-center rounded-lg border border-hairline text-ink-dim hover:border-cyan/40 hover:text-cyan-hot"
            aria-label="کپی آدرس"
          >
            {copied ? <Check size={14} className="text-win" /> : <Copy size={14} />}
          </button>
        </div>
      </Card>
    </div>
  );
}

export function WithdrawForm({ balance, address }: { balance: string; address: string | null }) {
  const router = useRouter();
  const [addr, setAddr] = useState(address ?? "");
  const [amount, setAmount] = useState("20");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [done, setDone] = useState(false);

  const available = Number(balance);
  const amt = Number(amount) || 0;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setDone(false);
    setLoading(true);
    try {
      const res = await fetch("/api/wallet", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action: "withdraw", amount: amt, address: addr }),
      });
      const json = (await res.json()) as { error?: string };
      if (!res.ok) {
        setError(json.error ?? "برداشت ناموفق بود.");
        return;
      }
      setDone(true);
      router.refresh();
    } catch {
      setError("ارتباط با سرور برقرار نشد.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <Card>
      <CardTitle kicker="WITHDRAW · USDT TRC20" icon={<ArrowUpFromLine size={16} />}>
        برداشت از کیف پول
      </CardTitle>
      <form onSubmit={submit} className="space-y-5">
        {error && (
          <div role="alert" className="clip-notch flex items-start gap-2.5 border border-loss/40 bg-loss/10 px-3.5 py-3 text-[12px] text-loss">
            <AlertCircle size={15} className="mt-0.5 shrink-0" />
            {error}
          </div>
        )}
        {done && (
          <Alert tone="success" title="درخواست برداشت ثبت شد">
            درخواست شما در صف پردازش شبکه قرار گرفت.
          </Alert>
        )}

        <div className="clip-notch flex items-center justify-between border border-cyan/25 bg-cyan/8 px-4 py-3">
          <span className="font-mono text-[10px] tracking-[0.18em] text-cyan/85">AVAILABLE</span>
          <span className="font-num text-[17px] font-bold text-cyan-hot" dir="ltr">
            {money(available)} USDT
          </span>
        </div>

        <Field label="آدرس کیف پول مقصد (TRC20)" htmlFor="addr">
          <Input
            id="addr"
            required
            dir="ltr"
            value={addr}
            onChange={(e) => setAddr(e.target.value)}
            placeholder="T…"
          />
        </Field>

        <Field label="مبلغ برداشت (USDT)" hint="حداقل ۲۰ USDT" htmlFor="wamount">
          <Input
            id="wamount"
            inputMode="decimal"
            required
            dir="ltr"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="20"
          />
        </Field>

        <Presets options={[20, 100, 500]} onPick={(v) => setAmount(String(v))} />

        <div className="space-y-2.5 border-t border-hairline pt-4">
          {[
            ["مبلغ برداشت", `${money(amt)} USDT`],
            ["کارمزد شبکه", "1.00 USDT"],
            ["دریافتی تقریبی", `${money(Math.max(0, amt - 1))} USDT`],
          ].map(([k, v]) => (
            <div key={k} className="flex items-center justify-between">
              <span className="text-[12.5px] text-ink-dim">{k}</span>
              <span className="font-num text-[13px] font-bold text-ink" dir="ltr">
                {v}
              </span>
            </div>
          ))}
        </div>

        <Button
          type="submit"
          variant="danger"
          size="lg"
          loading={loading}
          disabled={loading || amt > available}
          className="w-full"
        >
          <ArrowUpFromLine size={16} />
          تأیید برداشت
        </Button>
        <p className="text-[11.5px] leading-relaxed text-ink-dim">
          مطمئن شو آدرس مقصد صحیح است؛ تراکنش‌های بلاکچینی قابل بازگشت نیستند.
        </p>
      </form>
    </Card>
  );
}
