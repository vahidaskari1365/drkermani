/* ============================================================
   BTC6 // MARKET FEED
   BTC/USDT 1H candles. Primary source: Binance public REST.
   Fallback: deterministic on-device simulation so the game never
   goes dark (sandbox / offline / rate-limit safe).
   ============================================================ */

export const HOUR = 3_600_000;

export type Candle = {
  openTime: number;
  open: number;
  high: number;
  low: number;
  close: number;
};

export type FeedSource = "binance" | "simulated";

const BINANCE_URL = "https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=1h";

export const roundNumberFromTime = (t: number) => Math.floor(t / HOUR);
export const openTimeOfRound = (round: number) => round * HOUR;

/* ---------------- deterministic PRNG (mulberry32) ---------------- */
function hash32(n: number): number {
  let x = n | 0;
  x = (x ^ 61) ^ (x >>> 16);
  x = x + (x << 3);
  x = x ^ (x >>> 4);
  x = Math.imul(x, 0x27d4eb2d);
  x = x ^ (x >>> 15);
  return x >>> 0;
}

function mulberry32(a: number) {
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Plausible BTC price for a given epoch-hour. Smooth across rounds. */
function basePrice(round: number): number {
  const rnd = mulberry32(hash32(round));
  let p = 84000;
  for (let i = 0; i < 6; i++) p += (rnd() - 0.5) * 2600;
  // slow macro drift chained from a fixed origin
  p += Math.sin(round / 37) * 4200 + Math.cos(round / 11) * 1500;
  return Math.max(12000, p);
}

export function simulatedCandle(round: number): Candle {
  const openTime = openTimeOfRound(round);
  const rnd = mulberry32(hash32(round + 977));
  const open = basePrice(round);
  const close = basePrice(round + 1) + (rnd() - 0.5) * 900;
  const span = 180 + rnd() * 1400;
  const high = Math.max(open, close) + span * (0.35 + rnd() * 0.65);
  const low = Math.min(open, close) - span * rnd() * 0.7;
  const round2 = (v: number) => Math.round(v * 100) / 100;
  return {
    openTime,
    open: round2(open),
    high: round2(high),
    low: round2(Math.max(1, low)),
    close: round2(close),
  };
}

/** Progressive reveal of an in-progress candle. */
export function liveView(c: Candle, now: number): Candle {
  const elapsed = Math.min(1, Math.max(0.02, (now - c.openTime) / HOUR));
  const mid = c.open + (c.close - c.open) * elapsed;
  const high = c.high * elapsed + Math.max(c.open, mid) * (1 - elapsed);
  const low = c.low * elapsed + Math.min(c.open, mid) * (1 - elapsed);
  const round2 = (v: number) => Math.round(v * 100) / 100;
  return {
    openTime: c.openTime,
    open: c.open,
    high: round2(Math.max(high, c.open, mid)),
    low: round2(Math.min(low, c.open, mid)),
    close: round2(mid),
  };
}

/* ------------------------- Binance ------------------------- */
type CacheEntry = { at: number; candles: Candle[]; source: FeedSource };
const globalCache = globalThis as typeof globalThis & { __btc6Feed?: CacheEntry };

async function fetchBinance(limit: number): Promise<Candle[] | null> {
  try {
    const res = await fetch(`${BINANCE_URL}&limit=${limit}`, {
      cache: "no-store",
      signal: AbortSignal.timeout(2500),
      headers: { accept: "application/json" },
    });
    if (!res.ok) return null;
    const raw = (await res.json()) as unknown;
    if (!Array.isArray(raw) || raw.length === 0) return null;
    const out: Candle[] = [];
    for (const row of raw) {
      if (!Array.isArray(row) || row.length < 5) continue;
      out.push({
        openTime: Number(row[0]),
        open: Number(row[1]),
        high: Number(row[2]),
        low: Number(row[3]),
        close: Number(row[4]),
      });
    }
    return out.length ? out : null;
  } catch {
    return null;
  }
}

/**
 * Returns the last `limit` closed candles (excluding the currently forming
 * one when `includeLive` is false) plus the live candle.
 */
export async function getFeed(limit = 40): Promise<{
  source: FeedSource;
  closed: Candle[];
  live: Candle;
  currentRound: number;
}> {
  const now = Date.now();
  const currentRound = roundNumberFromTime(now);
  const cached = globalCache.__btc6Feed;
  if (cached && now - cached.at < 30_000 && cached.candles.length) {
    const closedRounds = cached.candles.filter((c) => c.openTime < currentRound * HOUR);
    const liveRaw = cached.candles.find((c) => c.openTime === currentRound * HOUR);
    return {
      source: cached.source,
      closed: closedRounds.slice(-limit),
      live: liveRaw
        ? liveView(liveRaw, now)
        : liveView(simulatedCandle(currentRound), now),
      currentRound,
    };
  }

  const binance = await fetchBinance(limit + 2);
  if (binance) {
    globalCache.__btc6Feed = { at: now, candles: binance, source: "binance" };
    const closed = binance.filter((c) => c.openTime < currentRound * HOUR).slice(-limit);
    const liveRaw = binance.find((c) => c.openTime === currentRound * HOUR);
    return {
      source: "binance",
      closed,
      live: liveRaw ? liveView(liveRaw, now) : liveView(simulatedCandle(currentRound), now),
      currentRound,
    };
  }

  const sim: Candle[] = [];
  for (let r = currentRound - limit; r <= currentRound; r++) sim.push(simulatedCandle(r));
  globalCache.__btc6Feed = { at: now, candles: sim, source: "simulated" };
  return {
    source: "simulated",
    closed: sim.slice(0, -1),
    live: liveView(sim[sim.length - 1], now),
    currentRound,
  };
}

/** Authoritative candle for a finished round. */
export async function candleForRound(round: number): Promise<{ source: FeedSource; candle: Candle }> {
  const feed = await getFeed(80);
  const hit = feed.closed.find((c) => roundNumberFromTime(c.openTime) === round);
  if (hit) return { source: feed.source, candle: hit };
  return { source: "simulated", candle: simulatedCandle(round) };
}
