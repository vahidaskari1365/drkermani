import { currentUser } from "@/lib/auth";
import { getChartSeries, getRecentSettled } from "@/lib/rounds";
import { SiteFooter, SiteHeader } from "@/components/site-chrome";
import Landing from "@/components/landing/landing";

export const dynamic = "force-dynamic";

export default async function Home() {
  const [user, chart, settled] = await Promise.all([
    currentUser().catch(() => null),
    getChartSeries(48).catch(() => ({ candles: [], source: "simulated" as const })),
    getRecentSettled(12).catch(() => []),
  ]);

  const ticker = settled.length
    ? settled.map(
        (r) => `${r.dOpen ?? "--"}·${r.dHigh ?? "--"}·${r.dClose ?? "--"}|${r.candleColor ?? "WHITE"}`,
      )
    : ["42·78·31|GREEN", "19·63·05|RED", "88·12·44|GREEN", "07·51·29|WHITE", "63·90·72|RED"];

  return (
    <>
      <SiteHeader loggedIn={!!user} />
      <main>
        <Landing candles={chart.candles} ticker={ticker} loggedIn={!!user} />
      </main>
      <SiteFooter />
    </>
  );
}
