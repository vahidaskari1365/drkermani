/* ============================================================
   BTC6 // GAME RULES & PRIZE ENGINE
   ============================================================ */

export const TICKET_PRICE = 10;
export const CURRENCY = "USDT";

export type ColorPick = "GREEN" | "RED" | "WHITE";
export const COLOR_OPTIONS: ColorPick[] = ["GREEN", "RED", "WHITE"];

export function lastTwo(price: number): string {
  const s = Math.abs(Math.round(price * 100) / 100).toFixed(2);
  return s.slice(s.length - 2);
}

export function candleColor(open: number, close: number): ColorPick {
  if (close > open) return "GREEN";
  if (close < open) return "RED";
  return "WHITE";
}

/** positional digit matches for one pair, e.g. "42" vs "47" → 1 */
export function digitScore(pred: string, actual: string): number {
  let n = 0;
  for (let i = 0; i < 2; i++) if (pred[i] === actual[i]) n += 1;
  return n;
}

export type PrizeTier = {
  key: string;
  label: string;
  digits: string;
  color: boolean;
  multiplier: number;
};

export const PRIZE_TIERS: PrizeTier[] = [
  { key: "grand", label: "جایزه بزرگ BTC6", digits: "۶ رقم", color: true, multiplier: 1000 },
  { key: "six", label: "شش‌رقمی کامل", digits: "۶ رقم", color: false, multiplier: 200 },
  { key: "five", label: "پنج‌رقمی", digits: "۵ رقم", color: false, multiplier: 50 },
  { key: "four", label: "چهاررقمی", digits: "۴ رقم", color: false, multiplier: 12 },
  { key: "three", label: "سه‌رقمی", digits: "۳ رقم", color: false, multiplier: 3 },
  { key: "two", label: "دو‌رقمی + رنگ", digits: "۲ رقم", color: true, multiplier: 1.5 },
  { key: "color", label: "فقط رنگ کندل", digits: "۰ رقم", color: true, multiplier: 0.5 },
];

export function multiplierFor(score: number, colorMatch: boolean): { multiplier: number; tier: PrizeTier | null } {
  const t =
    score >= 6 && colorMatch
      ? PRIZE_TIERS[0]
      : score >= 6
        ? PRIZE_TIERS[1]
        : score >= 5
          ? PRIZE_TIERS[2]
          : score >= 4
            ? PRIZE_TIERS[3]
            : score >= 3
              ? PRIZE_TIERS[4]
              : score >= 2 && colorMatch
                ? PRIZE_TIERS[5]
                : colorMatch
                  ? PRIZE_TIERS[6]
                  : null;
  return { multiplier: t ? t.multiplier : 0, tier: t };
}

export const COLOR_FA: Record<string, string> = {
  GREEN: "سبز",
  RED: "قرمز",
  WHITE: "سفید",
};

export const STATUS_FA: Record<string, string> = {
  active: "در انتظار کشش",
  won: "برنده",
  lost: "بازنده",
  refunded: "بازگشت وجه",
  live: "در حال تشکیل",
  settled: "کشش‌شده",
  pending: "در حال بررسی",
  completed: "انجام‌شده",
  failed: "ناموفق",
};

export const TX_FA: Record<string, string> = {
  deposit: "واریز",
  withdraw: "برداشت",
  ticket: "خرید بلیط",
  payout: "پرداخت جایزه",
  refund: "بازگشت وجه",
};
